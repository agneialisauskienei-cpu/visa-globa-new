"use client"

import { useEffect, useMemo, useState } from "react"
import {
  AlertTriangle,
  BadgeCheck,
  BriefcaseBusiness,
  CalendarDays,
  ClipboardCheck,
  FileText,
  GraduationCap,
  PackageCheck,
  Plus,
  RefreshCw,
  Search,
  ShieldCheck,
  Umbrella,
  UserPlus,
  Users,
  X,
  Edit3,
} from "lucide-react"
import { supabase } from "@/lib/supabase"
import ScheduleBlock from "./components/Schedule/ScheduleBlock"
import { getCurrentOrganizationId } from "@/lib/current-organization"
import CredentialForm from "./components/CredentialForm"


type Employee = {
  user_id: string
  email?: string | null
  first_name?: string | null
  last_name?: string | null
  full_name?: string | null
  role?: string | null
  legacy_role?: string | null
  position?: string | null
  department?: string | null
  staff_type?: string | null
  professional_license_number?: string | null
  professional_license_valid_until?: string | null
  occupational_health_valid_until?: string | null
  is_active?: boolean | null
}

type Credential = {
  id: string
  employee_id: string
  type: string
  number: string | null
  issuer: string | null
  issued_at: string | null
  expires_at: string | null
  note: string | null
}

type Training = {
  id: string
  employee_id: string
  title: string
  category: string | null
  hours: number | null
  provider: string | null
  completed_at: string | null
  expires_at: string | null
  certificate_no: string | null
  mandatory: boolean | null
}

type TrainingCatalog = {
  id: string
  name: string
  category: string
  mandatory: boolean | number | null
  valid_for_months: number | null
  hours: number | null
  applies_to: string | null
  reminder_30: boolean | number | null
  reminder_7: boolean | number | null
}

type TrainingRequirement = {
  id: string
  position: string
  training_id: string
  required: boolean | number | null
}

type TrainingComplianceRow = {
  employee: Employee
  training: TrainingCatalog
  status: "valid" | "missing" | "expired" | "expiring"
  completed_at: string | null
  expires_at: string | null
  hours: number
  verified_by: string | null
}

type VacationRequest = {
  id: string
  employee_id: string
  type: string | null
  start_date: string
  end_date: string
  status: string
  requested_days: number | null
  note: string | null
  created_at: string | null
}

type Candidate = {
  id: string
  first_name: string
  last_name: string
  email: string | null
  phone: string | null
  desired_role: string | null
  status: string | null
  experience: string | null
  created_at: string | null
}

type ScheduleEntry = {
  id: string
  employee_id: string
  date: string
  start_datetime: string | null
  end_datetime: string | null
  status: string | null
  note: string | null
}

type DocumentRequirement = {
  id: string
  role: string
  document_type: string
  required: boolean | number | null
  collect_copy_allowed: boolean | number | null
  retention_note: string | null
  sort_order: number | null
}

type DocumentVerification = {
  id: string
  employee_id: string
  document_type: string
  evidence_mode: string | null
  reference_no_masked: string | null
  issuer: string | null
  valid_from: string | null
  valid_until: string | null
  result: string | null
  verified_by: string
  verified_at: string | null
  no_copy_stored: boolean | number | null
  legal_basis: string | null
  note: string | null
}

type AuditLog = {
  id: string
  actor: string | null
  action: string
  entity_type: string
  entity_id: string | null
  details: string | null
  created_at: string | null
}

type PersonnelInventoryItem = {
  id: string
  organization_id?: string | null
  name: string
  category: string | null
  serial_no?: string | null
  size: string | null
  condition?: string | null
  status?: string | null
  employee_id?: string | null
  note?: string | null
  created_at?: string | null
}

type PersonnelInventoryAssignment = {
  id: string
  employee_id: string
  item_id: string
  assigned_at: string
  returned_at: string | null
  condition_out: string | null
  condition_in: string | null
  note: string | null
}

type TabKey = "overview" | "employees" | "schedule" | "vacations" | "docs" | "documentChecks" | "trainings" | "inventory" | "candidates"

const tabs: Array<{ key: TabKey; label: string; icon: any }> = [
  { key: "overview", label: "Apžvalga", icon: ShieldCheck },
  { key: "employees", label: "Darbuotojai", icon: Users },
  { key: "schedule", label: "Grafikas", icon: CalendarDays },
  { key: "vacations", label: "Atostogos", icon: Umbrella },
  { key: "docs", label: "Pažymos / licencijos", icon: FileText },
  { key: "documentChecks", label: "Dokumentų patikrinimai", icon: BadgeCheck },
  { key: "trainings", label: "Mokymai", icon: GraduationCap },
  { key: "inventory", label: "Daiktai", icon: PackageCheck },
  { key: "candidates", label: "Kandidatai", icon: UserPlus },
]

function today() {
  return toDateInput(new Date())
}

function addDays(date: Date, days: number) {
  const next = new Date(date)
  next.setDate(next.getDate() + days)
  return next
}

function daysBetween(start: string, end: string) {
  if (!start || !end) return 0
  const a = new Date(`${start}T00:00:00`)
  const b = new Date(`${end}T00:00:00`)
  return Math.max(0, Math.floor((b.getTime() - a.getTime()) / 86400000) + 1)
}

function fmt(value?: string | null) {
  if (!value) return "—"
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  return date.toLocaleDateString("lt-LT")
}

function formatDate(value?: string | null) {
  return fmt(value)
}

function employeeName(employee?: Employee | null) {
  if (!employee) return "Darbuotojas"
  const full = String(employee.full_name || "").trim()
  const combined = [employee.first_name, employee.last_name].filter(Boolean).join(" ").trim()
  return full || combined || employee.email || "Darbuotojas"
}

function employeeRole(employee?: Employee | null) {
  return employee?.position || employee?.role || employee?.legacy_role || "—"
}

function isExpiring(value?: string | null) {
  if (!value) return false
  const date = new Date(`${value}T00:00:00`)
  const limit = addDays(new Date(), 45)
  return date <= limit
}

type DocsFilter = "all" | "valid" | "expiring" | "expired" | "missing"

function getCredentialStatus(expiresAt?: string | null): "valid" | "expiring" | "expired" {
  if (!expiresAt) return "valid"
  const date = new Date(`${expiresAt}T00:00:00`)
  const now = new Date()
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate())
  const expiringLimit = addDays(todayStart, 30)

  if (date < todayStart) return "expired"
  if (date <= expiringLimit) return "expiring"
  return "valid"
}

function documentStatusText(status: "valid" | "expiring" | "expired" | "missing") {
  if (status === "valid") return "Galioja"
  if (status === "expiring") return "Baigiasi"
  if (status === "expired") return "Pasibaigė"
  return "Trūksta"
}

function normalizeDocumentType(value?: string | null) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/[ą]/g, "a")
    .replace(/[č]/g, "c")
    .replace(/[ęė]/g, "e")
    .replace(/[į]/g, "i")
    .replace(/[š]/g, "s")
    .replace(/[ųū]/g, "u")
    .replace(/[ž]/g, "z")
    .replace(/\s+/g, " ")
}

function documentTypesMatch(a?: string | null, b?: string | null) {
  const left = normalizeDocumentType(a)
  const right = normalizeDocumentType(b)
  if (!left || !right) return false
  return left === right || left.includes(right) || right.includes(left)
}

function formatDocumentFilter(filter: DocsFilter) {
  if (filter === "valid") return "Galioja"
  if (filter === "expiring") return "Baigiasi"
  if (filter === "expired") return "Pasibaigė"
  if (filter === "missing") return "Trūksta"
  return "Visi"
}

function vacationStatusText(status?: string | null) {
  if (status === "submitted") return "Pateikta"
  if (status === "approved") return "Patvirtinta"
  if (status === "rejected") return "Atmesta"
  if (status === "cancelled") return "Atšaukta"
  if (status === "draft") return "Juodraštis"
  return status || "—"
}

function maskReferenceNo(value: string) {
  const clean = String(value || "").replace(/\s+/g, "")
  if (!clean) return ""
  return `****${clean.slice(-4)}`
}

function hasSensitiveWords(value: string) {
  const text = String(value || "").toLowerCase()
  const blocked = ["diagnoz", "liga", "teist", "relig", "polit", "partija", "profesinė sąjunga", "profsąjunga", "orientacija", "sveikatos istorija"]
  return blocked.some((word) => text.includes(word))
}

function verificationStatusLabel(status: string) {
  if (status === "ok") return "Patikrinta"
  if (status === "expiring") return "Greitai baigsis"
  if (status === "expired") return "Pasibaigė"
  if (status === "missing") return "Trūksta"
  return status
}

function calculateTrainingExpiry(completedAt: string, validMonths?: number | null) {
  if (!completedAt || !validMonths) return ""
  const date = new Date(`${completedAt}T00:00:00`)
  date.setMonth(date.getMonth() + Number(validMonths))
  return date.toISOString().slice(0, 10)
}

function isUuid(value?: string | null) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(value || ""))
}

function trainingStatusLabel(status: string) {
  if (status === "valid") return "Galioja"
  if (status === "expiring") return "Greitai baigsis"
  if (status === "expired") return "Pasibaigė"
  if (status === "missing") return "Trūksta"
  return status
}

function trainingStatusStyle(status: string) {
  if (status === "valid") return styles.statusGood
  if (status === "expiring") return styles.statusWarn
  if (status === "expired") return styles.statusBad
  if (status === "missing") return styles.statusBad
  return styles.badge
}

function normalizePosition(value?: string | null) {
  return String(value || "").trim().toLowerCase()
}

function normalizeTrainingKey(value?: string | null) {
  return String(value || "")
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim()
}

function requirementMatchesEmployee(position: string, employee: Employee) {
  const req = normalizePosition(position)
  if (!req || req === "visi" || req === "all") return true

  const employeeText = [
    employee.position,
    employee.role,
    employee.legacy_role,
    employee.staff_type,
    employee.department,
  ]
    .filter(Boolean)
    .join(" ")
    .toLowerCase()

  if (req.includes("slaug")) return employeeText.includes("slaug")
  if (req.includes("social")) return employeeText.includes("social")
  if (req.includes("virtuv") || req.includes("maist")) return employeeText.includes("virtuv") || employeeText.includes("maist")
  if (req.includes("ūk") || req.includes("uk") || req.includes("techn")) return employeeText.includes("ūk") || employeeText.includes("uk") || employeeText.includes("techn")
  if (req.includes("admin")) return employeeText.includes("admin")

  return employeeText.includes(req)
}

function employeeMap(employees: Employee[]) {
  return new Map(employees.map((employee) => [employee.user_id, employee]))
}

function toDateInput(date: Date) {
  return new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 10)
}

function addMonths(date: Date, amount: number) {
  return new Date(date.getFullYear(), date.getMonth() + amount, 1)
}

function monthDays(date: Date) {
  const start = new Date(date.getFullYear(), date.getMonth(), 1)
  const end = new Date(date.getFullYear(), date.getMonth() + 1, 0)
  const days: Date[] = []

  for (const d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
    days.push(new Date(d))
  }

  return days
}

function monthLabel(date: Date) {
  return new Intl.DateTimeFormat("lt-LT", { year: "numeric", month: "long" }).format(date)
}

function scheduleStatusLabel(status?: string | null) {
  const raw = String(status || "").toUpperCase()
  const map: Record<string, string> = {
    WORK: "Darbas",
    VACATION: "Atostogos",
    SICK: "Liga",
    OFF: "Poilsis",
    TRAINING: "Mokymai",
    BUSINESS_TRIP: "Komandiruotė",
    UNPAID: "Nemokamos atostogos",
    MATERNITY_DAY: "Mamadienis",
    FATHER_DAY: "Tėvadienis",
    APPROVED: "Patvirtinta",
    SUBMITTED: "Pateikta",
    PENDING: "Laukia patvirtinimo",
    REJECTED: "Atmesta",
    CANCELLED: "Atšaukta",
  }
  return map[raw] || status || "—"
}

function dateOnlyAddDays(dateString: string, amount: number) {
  const [year, month, day] = dateString.split("-").map(Number)
  const date = new Date(year, month - 1, day + amount)
  return toDateInput(date)
}

function timePartFromDateTime(value?: string | null) {
  if (!value) return ""
  const normalized = String(value).replace("T", " ")
  const time = normalized.slice(11, 16)
  return /^\d{2}:\d{2}$/.test(time) ? time : ""
}

function scheduleTableStart(entry: ScheduleEntry) {
  if (entry.status && entry.status !== "WORK") return "Visa diena"
  return timePartFromDateTime(entry.start_datetime) || "—"
}

function scheduleTableEnd(entry: ScheduleEntry) {
  if (entry.status && entry.status !== "WORK") return "Visa diena"

  const startDate = entry.start_datetime?.slice(0, 10) || entry.date
  const endDate = entry.end_datetime?.slice(0, 10) || entry.date
  const end = timePartFromDateTime(entry.end_datetime)

  if (end === "00:00" && endDate > startDate) return "24:00"
  return end || "—"
}

function scheduleCode(entry?: ScheduleEntry | null) {
  if (!entry) return ""
  if (entry.status === "VACATION") return "A"
  if (entry.status === "SICK") return "L"
  if (entry.status === "OFF") return "P"
  if (entry.status === "WORK") {
    const startDate = entry.start_datetime?.slice(0, 10) || entry.date
    const endDate = entry.end_datetime?.slice(0, 10) || entry.date
    const start = entry.start_datetime?.slice(11, 16)
    let end = entry.end_datetime?.slice(11, 16)

    if (start && end) {
      if (end === "00:00" && endDate > startDate) end = "24:00"
      return `${start}-${end}`
    }

    return "D"
  }

  return entry.status || ""
}

function scheduleDateTimeMs(value?: string | null) {
  if (!value) return null
  const date = new Date(value)
  const time = date.getTime()
  return Number.isNaN(time) ? null : time
}

function scheduleHours(entry: ScheduleEntry) {
  if (entry.status !== "WORK" || !entry.start_datetime || !entry.end_datetime) return 0

  const start = scheduleDateTimeMs(entry.start_datetime)
  const end = scheduleDateTimeMs(entry.end_datetime)
  if (start === null || end === null || end <= start) return 0

  return Math.max(0, (end - start) / 3600000)
}

function scheduleInterval(entry: ScheduleEntry) {
  if (entry.status !== "WORK" || !entry.start_datetime || !entry.end_datetime) return null
  const start = scheduleDateTimeMs(entry.start_datetime)
  const end = scheduleDateTimeMs(entry.end_datetime)
  if (start === null || end === null || end <= start) return null
  return { start, end, hours: (end - start) / 3600000, date: entry.date }
}

function normalizeScheduleCode(value: unknown) {
  const raw = String(value ?? "").trim().toUpperCase()

  if (!raw) return { status: "", start: null as string | null, end: null as string | null, error: "" }
  if (["A", "ATOSTOGOS", "VACATION"].includes(raw)) return { status: "VACATION", start: "00:00", end: "23:59", error: "" }
  if (["L", "LIGA", "SICK"].includes(raw)) return { status: "SICK", start: "00:00", end: "23:59", error: "" }
  if (["P", "POILSIS", "OFF"].includes(raw)) return { status: "OFF", start: "00:00", end: "23:59", error: "" }
  if (["D", "WORK", "DARBAS"].includes(raw)) return { status: "WORK", start: "08:00", end: "16:00", error: "" }

  const match = raw.match(/^(\d{1,2})(?::?(\d{2}))?\s*[-–]\s*(\d{1,2})(?::?(\d{2}))?$/)

  if (match) {
    const shN = Number(match[1])
    const smN = Number(match[2] || "00")
    const ehN = Number(match[3])
    const emN = Number(match[4] || "00")

    if (shN > 23 || ehN > 24 || smN > 59 || emN > 59 || (ehN === 24 && emN !== 0)) {
      return { status: "", start: null as string | null, end: null as string | null, error: "Neteisingas laikas. Naudokite pvz. 07:30-19:15 arba 14-24." }
    }

    const sh = String(shN).padStart(2, "0")
    const sm = String(smN).padStart(2, "0")
    const eh = ehN === 24 ? "24" : String(ehN).padStart(2, "0")
    const em = String(emN).padStart(2, "0")
    return { status: "WORK", start: `${sh}:${sm}`, end: `${eh}:${em}`, error: "" }
  }

  return { status: "", start: null as string | null, end: null as string | null, error: "Neatpažintas įrašas. Įveskite laiką, pvz. 07:00-19:00, arba P / A / L." }
}

function longestRestInWindow(intervals: Array<{ start: number; end: number }>, windowStart: number, windowEnd: number) {
  const clipped = intervals
    .map((interval) => ({ start: Math.max(interval.start, windowStart), end: Math.min(interval.end, windowEnd) }))
    .filter((interval) => interval.end > interval.start)
    .sort((a, b) => a.start - b.start)

  if (!clipped.length) return (windowEnd - windowStart) / 3600000

  let longest = Math.max(0, (clipped[0].start - windowStart) / 3600000)
  for (let i = 1; i < clipped.length; i += 1) {
    longest = Math.max(longest, (clipped[i].start - clipped[i - 1].end) / 3600000)
  }
  longest = Math.max(longest, (windowEnd - clipped[clipped.length - 1].end) / 3600000)
  return longest
}


export default function TeamPage() {
  const [organizationId, setOrganizationId] = useState<string | null>(null)
  const [currentUserName, setCurrentUserName] = useState("HR")
  const [tab, setTab] = useState<TabKey>("overview")
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState("")
  const [query, setQuery] = useState("")
  const [docsFilter, setDocsFilter] = useState<"all" | "valid" | "expiring" | "expired" | "missing">("all")
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null)
  const [trainingDetailsEmployeeId, setTrainingDetailsEmployeeId] = useState<string | null>(null)
  const [trainingEntryEmployee, setTrainingEntryEmployee] = useState<Employee | null>(null)
  const [editForm, setEditForm] = useState({ first_name: "", last_name: "", full_name: "", email: "", position: "", department: "", professional_license_number: "", professional_license_valid_until: "", occupational_health_valid_until: "" })
  const [scheduleMonth, setScheduleMonth] = useState(() => new Date(new Date().getFullYear(), new Date().getMonth(), 1))

  const [employees, setEmployees] = useState<Employee[]>([])
  const [credentials, setCredentials] = useState<Credential[]>([])
  const [trainings, setTrainings] = useState<Training[]>([])
  const [trainingCatalog, setTrainingCatalog] = useState<TrainingCatalog[]>([])
  const [trainingRequirements, setTrainingRequirements] = useState<TrainingRequirement[]>([])
  const [vacations, setVacations] = useState<VacationRequest[]>([])
  const [candidates, setCandidates] = useState<Candidate[]>([])
  const [schedule, setSchedule] = useState<ScheduleEntry[]>([])
  const [documentRequirements, setDocumentRequirements] = useState<DocumentRequirement[]>([])
  const [documentVerifications, setDocumentVerifications] = useState<DocumentVerification[]>([])
  const [auditLog, setAuditLog] = useState<AuditLog[]>([])
  const [personnelInventory, setPersonnelInventory] = useState<PersonnelInventoryItem[]>([])
  const [personnelAssignments, setPersonnelAssignments] = useState<PersonnelInventoryAssignment[]>([])

  const [credentialForm, setCredentialForm] = useState({
    employee_id: "",
    type: "",
    number: "",
    issuer: "",
    issued_at: "",
    expires_at: "",
    note: "",
  })

  const [trainingForm, setTrainingForm] = useState({
    employee_id: "",
    title: "",
    training_id: "",
    category: "",
    hours: "1",
    provider: "",
    completed_at: today(),
    expires_at: "",
    certificate_no: "",
    verified_by: "",
  })

  const [catalogForm, setCatalogForm] = useState({
    name: "",
    category: "Visiems darbuotojams",
    mandatory: true,
    valid_for_months: "12",
    hours: "1",
    applies_to: "VISI",
  })

  const [trainingRequirementForm, setTrainingRequirementForm] = useState({
    position: "VISI",
    training_id: "",
  })

  const [vacationForm, setVacationForm] = useState({
    employee_id: "",
    start_date: today(),
    end_date: today(),
    note: "",
  })

  const [candidateForm, setCandidateForm] = useState({
    first_name: "",
    last_name: "",
    email: "",
    phone: "",
    desired_role: "",
    experience: "",
    education: "",
    licenses: "",
    consent: false,
  })

  const [scheduleForm, setScheduleForm] = useState({
    employee_id: "",
    date: today(),
    start_datetime: `${today()}T08:00`,
    end_datetime: `${today()}T16:00`,
    status: "WORK",
    note: "",
  })

  const [verificationForm, setVerificationForm] = useState({
    employee_id: "",
    document_type: "Sveikatos pažyma",
    evidence_mode: "seen_original",
    reference_no: "",
    issuer: "",
    valid_from: "",
    valid_until: "",
    verified_by: "",
    no_copy_stored: true,
    seen_confirmed: false,
    minimal_data_confirmed: false,
    note: "",
  })

  const [requirementForm, setRequirementForm] = useState({
    role: "VISI",
    document_type: "",
    validity_months: "12",
    required: true,
    retention_note: "",
  })

  const [inventoryForm, setInventoryForm] = useState({
    name: "",
    category: "",
    serial_no: "",
    size: "",
  })

  const [assignmentForm, setAssignmentForm] = useState({
    employee_id: "",
    item_id: "",
    condition_out: "",
    note: "",
  })

  useEffect(() => {
    void loadAll()
  }, [])

  async function loadAll() {
    try {
      setLoading(true)
      setMessage("")

      const {
        data: { user },
        error: userError,
      } = await supabase.auth.getUser()

      if (userError) throw userError

      if (user?.id) {
        const profileResult = await supabase
          .from("profiles")
          .select("full_name, first_name, last_name, email")
          .eq("id", user.id)
          .maybeSingle()

        if (!profileResult.error && profileResult.data) {
          const profile = profileResult.data as any
          const displayName =
            String(profile.full_name || "").trim() ||
            [profile.first_name, profile.last_name].filter(Boolean).join(" ").trim() ||
            profile.email ||
            "HR"

          setCurrentUserName(displayName)
        } else {
          setCurrentUserName("HR")
        }
      } else {
        setCurrentUserName("HR")
      }

      const orgId = await getCurrentOrganizationId()
      setOrganizationId(orgId)

      if (!orgId) {
        setMessage("Nepavyko nustatyti organizacijos.")
        return
      }

      const members = await supabase
        .from("organization_members")
        .select("user_id, role, legacy_role, position, department, staff_type, professional_license_number, professional_license_valid_until, occupational_health_valid_until, is_active")
        .eq("organization_id", orgId)
        .eq("is_active", true)

      if (members.error) throw members.error

      const memberRows = (members.data || []) as any[]
      const ids = memberRows.map((row) => row.user_id).filter(Boolean)

      let profileMap = new Map<string, any>()

      if (ids.length > 0) {
        const profiles = await supabase
          .from("profiles")
          .select("id, email, first_name, last_name, full_name")
          .in("id", ids)

        if (!profiles.error) {
          profileMap = new Map((profiles.data || []).map((profile: any) => [profile.id, profile]))
        }
      }

      const employeeRows: Employee[] = memberRows.map((member) => {
        const profile = profileMap.get(member.user_id) || {}

        return {
          ...member,
          email: profile.email || null,
          first_name: profile.first_name || null,
          last_name: profile.last_name || null,
          full_name: profile.full_name || null,
        }
      })

      setEmployees(employeeRows)

      await Promise.all([
        safeLoad("personnel_credentials", setCredentials, orgId, "expires_at"),
        safeLoad("personnel_trainings", setTrainings, orgId, "completed_at"),
        safeLoad("training_catalog", setTrainingCatalog, orgId, "name"),
        safeLoad("position_training_requirements", setTrainingRequirements, orgId, "position"),
        safeLoad("personnel_vacation_requests", setVacations, orgId, "created_at"),
        safeLoad("personnel_candidates", setCandidates, orgId, "created_at"),
        safeLoad("personnel_schedule_entries", setSchedule, orgId, "date"),
        safeLoad("document_requirements", setDocumentRequirements, orgId, "sort_order"),
        safeLoad("document_verifications", setDocumentVerifications, orgId, "verified_at"),
        safeLoad("audit_log", setAuditLog, orgId, "created_at"),
        safeLoad("personnel_inventory_items", setPersonnelInventory, orgId, "name"),
        safeLoad("personnel_inventory_assignments", setPersonnelAssignments, orgId, "assigned_at"),
      ])

      if (!credentialForm.employee_id && employeeRows[0]?.user_id) {
        const first = employeeRows[0].user_id
        setCredentialForm((prev) => ({ ...prev, employee_id: first }))
        setTrainingForm((prev) => ({ ...prev, employee_id: first }))
        setVacationForm((prev) => ({ ...prev, employee_id: first }))
        setScheduleForm((prev) => ({ ...prev, employee_id: first }))
        setVerificationForm((prev) => ({ ...prev, employee_id: first }))
        setAssignmentForm((prev) => ({ ...prev, employee_id: first }))
      }
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Nepavyko užkrauti personalo modulio.")
    } finally {
      setLoading(false)
    }
  }

  async function safeLoad(table: string, setter: (rows: any[]) => void, orgId: string, orderColumn: string) {
    let result = await supabase
      .from(table)
      .select("*")
      .eq("organization_id", orgId)
      .order(orderColumn, { ascending: false })

    if (result.error && (table === "personnel_inventory_items" || table === "personnel_inventory_assignments")) {
      result = await supabase
        .from(table)
        .select("*")
        .order(orderColumn, { ascending: false })
    }

    if (result.error) {
      if (table === "personnel_trainings") {
        setMessage(`Nepavyko nuskaityti mokymų įrašų: `)
      }
      setter([])
      return
    }

    const rows = result.data || []

    if (table === "personnel_inventory_items" || table === "personnel_inventory_assignments") {
      setter(rows.filter((row: any) => !row.organization_id || row.organization_id === orgId))
      return
    }

    setter(rows)
  }

  const map = useMemo(() => employeeMap(employees), [employees])

  const filteredEmployees = useMemo(() => {
    const q = query.trim().toLowerCase()

    return employees.filter((employee) => {
      const text = [
        employeeName(employee),
        employee.email,
        employeeRole(employee),
        employee.department,
      ]
        .filter(Boolean)
        .join(" ")
        .toLowerCase()

      return !q || text.includes(q)
    })
  }, [employees, query])

  const expiringCredentials = useMemo(() => {
    const fromMember = employees
      .flatMap((employee) => [
        employee.occupational_health_valid_until
          ? {
              employee_id: employee.user_id,
              type: "Sveikatos pažyma",
              number: "—",
              issuer: "—",
              issued_at: null,
              expires_at: employee.occupational_health_valid_until,
              note: "Iš darbuotojo kortelės",
              id: `health-${employee.user_id}`,
            }
          : null,
        employee.professional_license_valid_until
          ? {
              employee_id: employee.user_id,
              type: "Profesinė licencija",
              number: employee.professional_license_number || "—",
              issuer: "—",
              issued_at: null,
              expires_at: employee.professional_license_valid_until,
              note: "Iš darbuotojo kortelės",
              id: `license-${employee.user_id}`,
            }
          : null,
      ])
      .filter(Boolean) as Credential[]

    return [...credentials, ...fromMember]
      .filter((item) => isExpiring(item.expires_at))
      .sort((a, b) => String(a.expires_at || "").localeCompare(String(b.expires_at || "")))
      .slice(0, 10)
  }, [credentials, employees])

  const pendingVacations = vacations.filter((item) => item.status === "submitted")
  const activeSchedule = schedule.filter((item) => item.date >= today()).slice(0, 10)

  function vacationDecisionImpact(request: VacationRequest) {
    const requestDays = Array.from({ length: daysBetween(request.start_date, request.end_date) }).map((_, index) => {
      const date = new Date(`${request.start_date}T00:00:00`)
      date.setDate(date.getDate() + index)
      return toDateInput(date)
    })

    const total = employees.filter((employee) => employee.is_active !== false).length || employees.length
    const otherApproved = vacations.filter((item) =>
      item.id !== request.id &&
      item.status === "approved" &&
      item.start_date <= request.end_date &&
      item.end_date >= request.start_date
    ).length

    const minimumRemaining = Math.max(0, total - otherApproved - 1)
    const employeeScheduleConflict = schedule.some((entry) =>
      entry.employee_id === request.employee_id &&
      requestDays.includes(entry.date) &&
      entry.status === "WORK"
    )

    const warnings: string[] = []
    if (minimumRemaining <= 1) warnings.push(`Rizika: liks tik ${minimumRemaining} iš ${total} darbuotojų.`)
    if (employeeScheduleConflict) warnings.push("Patvirtinus bus pakeista suplanuota pamaina į neatvykimą.")

    return {
      label: `Liks ${minimumRemaining} iš ${total} darbuotojų`,
      warnings,
    }
  }

  const verificationSummary = useMemo(() => {
    const rows: Array<{
      employee: Employee
      document_type: string
      status: "ok" | "missing" | "expiring" | "expired"
      valid_until: string | null
      verified_by: string | null
      no_copy_stored: boolean
    }> = []

    const requirements = documentRequirements.length
      ? documentRequirements
      : [
          { id: "default-health", role: "VISI", document_type: "Sveikatos pažyma", required: true, collect_copy_allowed: false, retention_note: "Kopija nesaugoma", sort_order: 1 },
          { id: "default-license", role: "SLAUGYTOJAI", document_type: "Profesinė licencija", required: true, collect_copy_allowed: false, retention_note: "Kopija nesaugoma", sort_order: 2 },
        ]

    for (const employee of employees) {
      for (const requirement of requirements) {
        const employeeRoleText = [employeeRole(employee), employee.staff_type, employee.position].join(" ").toLowerCase()
        const role = String(requirement.role || "VISI").toLowerCase()

        if (role !== "visi" && !employeeRoleText.includes(role.replace("slaugytojai", "slaug").replace("socialiniai", "social"))) continue

        const latestVerification = [...documentVerifications]
          .filter((verification) => verification.employee_id === employee.user_id && documentTypesMatch(verification.document_type, requirement.document_type))
          .sort((a, b) => String(b.verified_at || "").localeCompare(String(a.verified_at || "")))[0]

        const latestCredential = [...credentials]
          .filter((credential) => credential.employee_id === employee.user_id && documentTypesMatch(credential.type, requirement.document_type))
          .sort((a, b) => String(b.expires_at || b.issued_at || "").localeCompare(String(a.expires_at || a.issued_at || "")))[0]

        if (!latestVerification && !latestCredential) {
          rows.push({ employee, document_type: requirement.document_type, status: "missing", valid_until: null, verified_by: null, no_copy_stored: true })
          continue
        }

        const validUntil = latestVerification?.valid_until || latestCredential?.expires_at || null
        let status: "ok" | "missing" | "expiring" | "expired" = "ok"

        if (validUntil) {
          const validUntilDate = new Date(`${validUntil}T00:00:00`)
          const now = new Date()
          const limit = addDays(now, 45)

          if (validUntilDate < now) status = "expired"
          else if (validUntilDate <= limit) status = "expiring"
        }

        rows.push({
          employee,
          document_type: requirement.document_type,
          status,
          valid_until: validUntil,
          verified_by: latestVerification?.verified_by || currentUserName,
          no_copy_stored: latestVerification ? Boolean(latestVerification.no_copy_stored) : true,
        })
      }
    }

    return rows
  }, [employees, documentRequirements, documentVerifications, credentials, currentUserName])

  const missingDocuments = verificationSummary.filter((row) => row.status === "missing").length
  const expiringVerifiedDocuments = verificationSummary.filter((row) => row.status === "expiring" || row.status === "expired").length

  const documentIssuesByEmployee = useMemo(() => {
    const result = new Map<string, { errors: string[]; warnings: string[] }>()

    for (const row of verificationSummary) {
      const current = result.get(row.employee.user_id) || { errors: [], warnings: [] }
      if (row.status === "missing") current.errors.push(`trūksta dokumento: ${row.document_type}`)
      if (row.status === "expired") current.errors.push(`pasibaigęs dokumentas: ${row.document_type}`)
      if (row.status === "expiring") current.warnings.push(`greitai baigsis dokumentas: ${row.document_type}${row.valid_until ? ` (${formatDate(row.valid_until)})` : ""}`)
      result.set(row.employee.user_id, current)
    }

    return result
  }, [verificationSummary])

  const credentialCenterRows = useMemo(() => {
    const savedRows = credentials.map((item) => ({
      kind: "credential" as const,
      id: item.id,
      employee_id: item.employee_id,
      employeeName: employeeName(map.get(item.employee_id)),
      type: item.type,
      number: item.number || "—",
      issuer: item.issuer || "—",
      issued_at: item.issued_at,
      expires_at: item.expires_at,
      note: item.note || "—",
      status: getCredentialStatus(item.expires_at),
      action: "Saugoma pažymų / licencijų registre",
    }))

    const verificationRows = verificationSummary
      .filter((item) => item.status !== "missing")
      .map((item) => {
        const latest = [...documentVerifications]
          .filter((verification) => verification.employee_id === item.employee.user_id && verification.document_type === item.document_type)
          .sort((a, b) => String(b.verified_at || "").localeCompare(String(a.verified_at || "")))[0]

        return {
          kind: "verification" as const,
          id: latest?.id || `verification-${item.employee.user_id}-${item.document_type}`,
          employee_id: item.employee.user_id,
          employeeName: employeeName(item.employee),
          type: item.document_type,
          number: latest?.reference_no_masked || "—",
          issuer: latest?.issuer || "—",
          issued_at: latest?.valid_from || null,
          expires_at: item.valid_until,
          note: latest?.note || "Patikrinimas užregistruotas sistemoje, kopija nesaugoma",
          status: item.status === "ok" ? "valid" as const : item.status,
          action: "Užregistruotas dokumento patikrinimas",
        }
      })

    const missingRows = verificationSummary
      .filter((item) => item.status === "missing")
      .map((item) => ({
        kind: "missing" as const,
        id: `missing-${item.employee.user_id}-${item.document_type}`,
        employee_id: item.employee.user_id,
        employeeName: employeeName(item.employee),
        type: item.document_type,
        number: "—",
        issuer: "—",
        issued_at: null,
        expires_at: item.valid_until,
        note: "Reikia užregistruoti patikrinimą arba pažymą",
        status: "missing" as const,
        action: "Atidaryti dokumentų patikrinimą",
      }))

    const rows = [...savedRows, ...verificationRows, ...missingRows]
    return docsFilter === "all" ? rows : rows.filter((row) => row.status === docsFilter)
  }, [credentials, documentVerifications, docsFilter, map, verificationSummary])

  const credentialStatusCounts = useMemo(() => {
    const allRows = [
      ...credentials.map((item) => ({ status: getCredentialStatus(item.expires_at) as "valid" | "expiring" | "expired" | "missing" })),
      ...verificationSummary.map((item) => ({ status: item.status === "ok" ? "valid" as const : item.status })),
    ]

    return {
      all: allRows.length,
      valid: allRows.filter((row) => row.status === "valid").length,
      expiring: allRows.filter((row) => row.status === "expiring").length,
      expired: allRows.filter((row) => row.status === "expired").length,
      missing: allRows.filter((row) => row.status === "missing").length,
    }
  }, [credentials, verificationSummary])

  const compliancePercent = credentialStatusCounts.all
    ? Math.round((credentialStatusCounts.valid / credentialStatusCounts.all) * 100)
    : 100


  const overviewDocumentRiskRows = useMemo(() => {
    return credentialCenterRows
      .filter((row) => row.status === "expired" || row.status === "expiring" || row.status === "missing")
      .slice(0, 8)
  }, [credentialCenterRows])

  function openDocs(filter: DocsFilter) {
    setDocsFilter(filter)
    setTab("docs")
  }

  const effectiveTrainingCatalog = useMemo<TrainingCatalog[]>(() => {
    if (trainingCatalog.length) return trainingCatalog

    return [
      { id: "default-work-safety", name: "Darbų sauga", category: "Visiems darbuotojams", mandatory: true, valid_for_months: 12, hours: 2, applies_to: "VISI", reminder_30: true, reminder_7: true },
      { id: "default-fire-safety", name: "Gaisrinė sauga", category: "Visiems darbuotojams", mandatory: true, valid_for_months: 12, hours: 1, applies_to: "VISI", reminder_30: true, reminder_7: true },
      { id: "default-bdar", name: "BDAR", category: "Visiems darbuotojams", mandatory: true, valid_for_months: 12, hours: 1, applies_to: "VISI", reminder_30: true, reminder_7: true },
      { id: "default-violence", name: "Smurto prevencija", category: "Visiems darbuotojams", mandatory: true, valid_for_months: 12, hours: 2, applies_to: "VISI", reminder_30: true, reminder_7: true },
      { id: "default-infection", name: "Infekcijų kontrolė", category: "Visiems darbuotojams", mandatory: true, valid_for_months: 12, hours: 2, applies_to: "VISI", reminder_30: true, reminder_7: true },
      { id: "default-first-aid", name: "Pirmoji pagalba", category: "Visiems darbuotojams", mandatory: true, valid_for_months: 24, hours: 4, applies_to: "VISI", reminder_30: true, reminder_7: true },
      { id: "default-social-160", name: "160 val. įvadiniai mokymai", category: "Socialinė sritis", mandatory: true, valid_for_months: 0, hours: 160, applies_to: "SOCIALINIAI", reminder_30: true, reminder_7: true },
      { id: "default-supervision", name: "Supervizijos / intervizijos", category: "Socialinė sritis", mandatory: true, valid_for_months: 12, hours: 8, applies_to: "SOCIALINIAI", reminder_30: true, reminder_7: true },
      { id: "default-license-support", name: "Profesinės licencijos palaikymas", category: "Sveikatos priežiūra", mandatory: true, valid_for_months: 12, hours: 4, applies_to: "SLAUGYTOJAI", reminder_30: true, reminder_7: true },
      { id: "default-hygiene", name: "Higienos mokymai", category: "Maisto blokas", mandatory: true, valid_for_months: 24, hours: 2, applies_to: "MAISTO BLOKAS", reminder_30: true, reminder_7: true },
      { id: "default-food", name: "Maisto sauga", category: "Maisto blokas", mandatory: true, valid_for_months: 12, hours: 2, applies_to: "MAISTO BLOKAS", reminder_30: true, reminder_7: true },
      { id: "default-info-security", name: "Informacijos sauga", category: "Administracija", mandatory: true, valid_for_months: 12, hours: 1, applies_to: "ADMINISTRACIJA", reminder_30: true, reminder_7: true },
    ]
  }, [trainingCatalog])

  const trainingCompliance = useMemo<TrainingComplianceRow[]>(() => {
    const rows: TrainingComplianceRow[] = []
    const now = new Date()
    const expiringLimit = addDays(now, 30)

    for (const employee of employees) {
      const requirements = effectiveTrainingCatalog.filter((training) => {
        const explicitRequirement = trainingRequirements.find((req) => req.training_id === training.id && requirementMatchesEmployee(req.position, employee))
        if (explicitRequirement) return Boolean(explicitRequirement.required)
        return requirementMatchesEmployee(training.applies_to || "VISI", employee)
      })

      for (const requiredTraining of requirements) {
        const matching = [...trainings]
          .filter((item) => {
            const sameCatalog = (item as any).training_id && (item as any).training_id === requiredTraining.id
            const currentTitle = normalizeTrainingKey(item.title)
            const requiredTitle = normalizeTrainingKey(requiredTraining.name)
            const sameName = currentTitle === requiredTitle || currentTitle.includes(requiredTitle) || requiredTitle.includes(currentTitle)
            return item.employee_id === employee.user_id && (sameCatalog || sameName)
          })
          .sort((a, b) => String(b.completed_at || "").localeCompare(String(a.completed_at || "")))[0]

        if (!matching) {
          rows.push({
            employee,
            training: requiredTraining,
            status: "missing",
            completed_at: null,
            expires_at: null,
            hours: Number(requiredTraining.hours || 0),
            verified_by: null,
          })
          continue
        }

        let expiresAt = matching.expires_at || ""
        if (!expiresAt && matching.completed_at && requiredTraining.valid_for_months) {
          expiresAt = calculateTrainingExpiry(matching.completed_at, requiredTraining.valid_for_months)
        }

        let status: TrainingComplianceRow["status"] = "valid"

        if (expiresAt) {
          const exp = new Date(`${expiresAt}T00:00:00`)
          if (exp < now) status = "expired"
          else if (exp <= expiringLimit) status = "expiring"
        }

        rows.push({
          employee,
          training: requiredTraining,
          status,
          completed_at: matching.completed_at,
          expires_at: expiresAt || null,
          hours: Number(matching.hours || requiredTraining.hours || 0),
          verified_by: (matching as any).verified_by || currentUserName,
        })
      }
    }

    return rows
  }, [currentUserName, employees, trainings, effectiveTrainingCatalog, trainingRequirements])

  const trainingMissing = trainingCompliance.filter((row) => row.status === "missing").length
  const trainingExpiring = trainingCompliance.filter((row) => row.status === "expiring" || row.status === "expired").length
  const trainingNonCompliantEmployees = new Set(trainingCompliance.filter((row) => row.status !== "valid").map((row) => row.employee.user_id)).size

  const overviewAttentionItems = useMemo(() => {
    const items: Array<{ title: string; value: string; tone: "bad" | "warn" | "good" | "muted"; action: string; onClick: () => void }> = []

    if (credentialStatusCounts.expired || credentialStatusCounts.missing) {
      items.push({
        title: "Dokumentų rizika",
        value: `${credentialStatusCounts.expired} pasibaigę · ${credentialStatusCounts.missing} trūksta`,
        tone: "bad",
        action: "Tvarkyti dokumentus",
        onClick: () => openDocs(credentialStatusCounts.expired ? "expired" : "missing"),
      })
    }

    if (credentialStatusCounts.expiring) {
      items.push({
        title: "Baigiasi terminai",
        value: `${credentialStatusCounts.expiring} dokumentai baigiasi per 30 d.`,
        tone: "warn",
        action: "Peržiūrėti",
        onClick: () => openDocs("expiring"),
      })
    }

    if (pendingVacations.length) {
      items.push({
        title: "Laukia sprendimo",
        value: `${pendingVacations.length} atostogų praš. laukia patvirtinimo`,
        tone: "warn",
        action: "Atidaryti prašymus",
        onClick: () => setTab("vacations"),
      })
    }

    if (trainingNonCompliantEmployees) {
      items.push({
        title: "Mokymų neatitikimai",
        value: `${trainingNonCompliantEmployees} darbuotojai turi neatitikimų`,
        tone: "warn",
        action: "Atidaryti mokymus",
        onClick: () => setTab("trainings"),
      })
    }

    if (!items.length) {
      items.push({
        title: "Viskas tvarkoje",
        value: "Kritinių veiksmų šiuo metu nėra",
        tone: "good",
        action: "Atidaryti grafiką",
        onClick: () => setTab("schedule"),
      })
    }

    return items
  }, [credentialStatusCounts, pendingVacations.length, trainingNonCompliantEmployees])

  const totalTrainingHours = trainings.reduce((sum, item) => sum + Number(item.hours || 0), 0)

  const trainingReminders = trainingCompliance.filter((row) => row.status === "expiring" || row.status === "expired").slice(0, 20)

  const trainingComplianceByEmployee = useMemo(() => {
    return employees.map((employee) => {
      const rows = trainingCompliance.filter((row) => row.employee.user_id === employee.user_id)
      const missing = rows.filter((row) => row.status === "missing").length
      const expiringOrExpired = rows.filter((row) => row.status === "expiring" || row.status === "expired").length
      const totalHours = rows.reduce((sum, row) => sum + Number(row.hours || 0), 0)
      const status = missing > 0 ? "missing" : expiringOrExpired > 0 ? "expiring" : "valid"

      return { employee, rows, missing, expiringOrExpired, totalHours, status }
    })
  }, [employees, trainingCompliance])

  const selectedTrainingDetails = trainingComplianceByEmployee.find((item) => item.employee.user_id === trainingDetailsEmployeeId) || null
  const editingEmployeeTrainingDetails = editingEmployee
    ? trainingComplianceByEmployee.find((item) => item.employee.user_id === editingEmployee.user_id) || null
    : null

  function openTrainingEntry(employee: Employee, row?: TrainingComplianceRow, options?: { openModal?: boolean }) {
    const catalog = row?.training
    const completed = trainingForm.completed_at || today()
    const shouldOpenModal = options?.openModal ?? true
    setMessage("")

    if (shouldOpenModal) {
      setTrainingEntryEmployee(employee)
    }

    setTrainingForm((prev) => ({
      ...prev,
      employee_id: employee.user_id,
      training_id: catalog?.id || "",
      title: catalog?.name || prev.title || "",
      category: catalog?.category || prev.category || "",
      hours: String(catalog?.hours || prev.hours || 1),
      completed_at: completed,
      expires_at: catalog?.valid_for_months ? calculateTrainingExpiry(completed, catalog.valid_for_months) : prev.expires_at,
      verified_by: prev.verified_by || currentUserName,
    }))
  }

  async function addCredential() {
    if (!organizationId) {
      setMessage("Nepavyko nustatyti organizacijos. Dokumentas neišsaugotas.")
      return
    }

    if (!credentialForm.employee_id || !credentialForm.type.trim()) {
      setMessage("Pasirink darbuotoją ir įvesk dokumento tipą.")
      return
    }

    setSaving(true)
    setMessage("")

    const payload = {
      organization_id: organizationId,
      employee_id: credentialForm.employee_id,
      type: credentialForm.type.trim(),
      number: credentialForm.number.trim() || null,
      issuer: credentialForm.issuer.trim() || null,
      issued_at: credentialForm.issued_at || null,
      expires_at: credentialForm.expires_at || null,
      note: credentialForm.note.trim() || null,
    }

    const { data, error } = await supabase
      .from("personnel_credentials")
      .insert(payload)
      .select("id, employee_id, type, number, issuer, issued_at, expires_at, note")
      .single()

    setSaving(false)

    if (error) {
      setMessage(error.message)
      return
    }

    if (data) {
      setCredentials((prev) => [data as Credential, ...prev.filter((item) => item.id !== data.id)])
    }

    setCredentialForm((prev) => ({
      ...prev,
      type: "",
      number: "",
      issuer: "",
      issued_at: "",
      expires_at: "",
      note: "",
    }))
    setDocsFilter("all")
    setMessage("Pažyma / licencija išsaugota ir įtraukta į dokumentų sąrašą.")

    void loadAll()
  }

  async function addTrainingCatalogItem() {
    if (!organizationId) return
    if (!catalogForm.name.trim()) {
      setMessage("Įvesk mokymo pavadinimą.")
      return
    }

    setSaving(true)
    setMessage("")

    const { data, error } = await supabase
      .from("training_catalog")
      .insert({
        organization_id: organizationId,
        name: catalogForm.name.trim(),
        category: catalogForm.category,
        mandatory: catalogForm.mandatory,
        valid_for_months: Number(catalogForm.valid_for_months || 0),
        hours: Number(catalogForm.hours || 0),
        applies_to: catalogForm.applies_to,
        reminder_30: true,
        reminder_7: true,
      })
      .select("id")
      .single()

    setSaving(false)

    if (error) {
      setMessage(error.message)
      return
    }

    setTrainingCatalog((prev) => [
      ...prev,
      {
        id: data.id,
        name: catalogForm.name.trim(),
        category: catalogForm.category,
        mandatory: catalogForm.mandatory,
        valid_for_months: Number(catalogForm.valid_for_months || 0),
        hours: Number(catalogForm.hours || 0),
        applies_to: catalogForm.applies_to,
        reminder_30: true,
        reminder_7: true,
      },
    ])

    setCatalogForm((prev) => ({ ...prev, name: "" }))
    setMessage("Mokymas pridėtas į katalogą.")
  }

  async function addTrainingRequirement() {
    if (!organizationId) return
    if (!trainingRequirementForm.training_id || !trainingRequirementForm.position.trim()) {
      setMessage("Pasirink mokymą ir pareigybę.")
      return
    }

    setSaving(true)
    setMessage("")

    const { error } = await supabase.from("position_training_requirements").insert({
      organization_id: organizationId,
      position: trainingRequirementForm.position.trim(),
      training_id: trainingRequirementForm.training_id,
      required: true,
    })

    setSaving(false)

    if (error) {
      setMessage(error.message)
      return
    }

    setTrainingRequirementForm((prev) => ({ ...prev, training_id: "" }))
    await loadAll()
    setMessage("Pareigybės mokymo reikalavimas pridėtas.")
  }


  async function addTraining(employeeIdOverride?: string) {
    if (!organizationId) return false

    const employeeId = employeeIdOverride || trainingForm.employee_id

    if (!employeeId || !trainingForm.title.trim()) {
      setMessage("Pasirink darbuotoją ir įvesk mokymų pavadinimą.")
      return false
    }

    setSaving(true)
    setMessage("")

    const selectedCatalog = effectiveTrainingCatalog.find((item) => item.id === trainingForm.training_id)
    const calculatedExpiry = trainingForm.expires_at || (trainingForm.completed_at && selectedCatalog?.valid_for_months ? calculateTrainingExpiry(trainingForm.completed_at, selectedCatalog.valid_for_months) : "")
    const normalizedHours = Math.max(1, Number(trainingForm.hours || selectedCatalog?.hours || 1))

    const payload: any = {
      organization_id: organizationId,
      employee_id: employeeId,
      title: selectedCatalog?.name || trainingForm.title.trim(),
      hours: normalizedHours,
      category: selectedCatalog?.category || trainingForm.category || null,
      provider: trainingForm.provider || null,
      completed_at: trainingForm.completed_at || null,
      expires_at: calculatedExpiry || null,
      certificate_no: trainingForm.certificate_no || null,
      mandatory: true,
      verified: true,
      verified_by: trainingForm.verified_by || currentUserName,
    }

    if (isUuid(trainingForm.training_id)) {
      payload.training_id = trainingForm.training_id
    }

    const { error } = await supabase.from("personnel_trainings").insert(payload)

    setSaving(false)

    if (error) {
      if (error.message.toLowerCase().includes("row-level security")) {
        setMessage("Nepakanka teisiu issaugoti mokymus. Reikia pataisyti Supabase personnel_trainings INSERT policy.")
      } else {
        setMessage(error.message)
      }
      return false
    }

    setTrainings((prev) => [
      { id: "local-" + String(Date.now()), ...payload } as Training,
      ...prev,
    ])

    setTrainingForm((prev) => ({
      ...prev,
      employee_id: employeeIdOverride ? employeeIdOverride : prev.employee_id,
      title: "",
      training_id: "",
      category: "",
      hours: "1",
      provider: "",
      completed_at: today(),
      certificate_no: "",
      expires_at: "",
      verified_by: currentUserName,
    }))
    await loadAll()
    setMessage("Mokymai išsaugoti ir priskirti darbuotojui.")
    return true
  }

  async function addVacation() {
    if (!organizationId) return
    if (!vacationForm.employee_id || !vacationForm.start_date || !vacationForm.end_date) {
      setMessage("Pasirink darbuotoją ir atostogų datas.")
      return
    }

    if (vacationForm.end_date < vacationForm.start_date) {
      setMessage("Pabaigos data negali būti ankstesnė už pradžią.")
      return
    }

    setSaving(true)
    setMessage("")

    const { error } = await supabase.from("personnel_vacation_requests").insert({
      organization_id: organizationId,
      employee_id: vacationForm.employee_id,
      type: "annual",
      start_date: vacationForm.start_date,
      end_date: vacationForm.end_date,
      status: "submitted",
      requested_days: daysBetween(vacationForm.start_date, vacationForm.end_date),
      note: vacationForm.note || null,
    })

    setSaving(false)

    if (error) {
      setMessage(error.message)
      return
    }

    setVacationForm((prev) => ({ ...prev, note: "" }))
    await loadAll()
    setMessage("Atostogų prašymas pateiktas.")
  }

  async function approveVacation(id: string) {
    setSaving(true)
    setMessage("")

    const request = vacations.find((item) => item.id === id)

    const { error } = await supabase
      .from("personnel_vacation_requests")
      .update({
        status: "approved",
        decision_at: new Date().toISOString(),
      })
      .eq("id", id)

    if (!error && request && organizationId) {
      const rows = Array.from({ length: daysBetween(request.start_date, request.end_date) }).map((_, index) => {
        const day = dateOnlyAddDays(request.start_date, index)

        return {
          organization_id: organizationId,
          employee_id: request.employee_id,
          date: day,
          start_datetime: ` 00:00:00`,
          end_datetime: ` 23:59:00`,
          status: "VACATION",
          note: "Patvirtintos atostogos",
        }
      })

      await supabase
        .from("personnel_schedule_entries")
        .delete()
        .eq("organization_id", organizationId)
        .eq("employee_id", request.employee_id)
        .gte("date", request.start_date)
        .lte("date", request.end_date)

      await supabase.from("personnel_schedule_entries").insert(rows)
    }

    setSaving(false)

    if (error) {
      setMessage(error.message)
      return
    }

    await loadAll()
    setMessage("Atostogos patvirtintos ir įrašytos į grafiką.")
  }

  async function addCandidate() {
    if (!organizationId) return

    if (!candidateForm.first_name.trim() || !candidateForm.last_name.trim()) {
      setMessage("Įvesk kandidato vardą ir pavardę.")
      return
    }

    if (!candidateForm.consent) {
      setMessage("Būtinas kandidato sutikimas dėl duomenų tvarkymo.")
      return
    }

    setSaving(true)
    setMessage("")

    const { error } = await supabase.from("personnel_candidates").insert({
      organization_id: organizationId,
      first_name: candidateForm.first_name.trim(),
      last_name: candidateForm.last_name.trim(),
      email: candidateForm.email || null,
      phone: candidateForm.phone || null,
      desired_role: candidateForm.desired_role || null,
      experience: candidateForm.experience || null,
      education: candidateForm.education || null,
      licenses: candidateForm.licenses || null,
      consent: true,
      status: "new",
    })

    setSaving(false)

    if (error) {
      setMessage(error.message)
      return
    }

    setCandidateForm({ first_name: "", last_name: "", email: "", phone: "", desired_role: "", experience: "", education: "", licenses: "", consent: false })
    await loadAll()
    setMessage("Kandidatas pridėtas.")
  }

  async function addSchedule() {
    if (!organizationId) return
    if (!scheduleForm.employee_id || !scheduleForm.date || !scheduleForm.start_datetime || !scheduleForm.end_datetime) {
      setMessage("Pasirink darbuotoją ir pamainos laikus.")
      return
    }

    if (scheduleForm.end_datetime <= scheduleForm.start_datetime) {
      setMessage("Pabaigos laikas turi būti vėlesnis už pradžios laiką.")
      return
    }

    const duration = (new Date(scheduleForm.end_datetime).getTime() - new Date(scheduleForm.start_datetime).getTime()) / 36e5

    if (duration > 12) {
      setMessage("Pamaina negali būti ilgesnė nei 12 val.")
      return
    }

    setSaving(true)
    setMessage("")

    const { error } = await supabase.from("personnel_schedule_entries").insert({
      organization_id: organizationId,
      ...scheduleForm,
      note: scheduleForm.note || null,
    })

    setSaving(false)

    if (error) {
      setMessage(error.message)
      return
    }

    await loadAll()
    setMessage("Pamaina įrašyta.")
  }



  async function writeAudit(action: string, entityType: string, entityId: string | null, details: string) {
    if (!organizationId) return

    await supabase.from("audit_log").insert({
      organization_id: organizationId,
      actor: "Administratorius",
      action,
      entity_type: entityType,
      entity_id: entityId,
      details,
    })
  }

  async function addDocumentRequirement() {
    if (!organizationId) return
    if (!requirementForm.document_type.trim()) {
      setMessage("Įvesk dokumento tipą.")
      return
    }

    setSaving(true)
    setMessage("")

    const { data, error } = await supabase
      .from("document_requirements")
      .insert({
        organization_id: organizationId,
        role: requirementForm.role,
        document_type: requirementForm.document_type.trim(),
        required: true,
        collect_copy_allowed: false,
        retention_note: requirementForm.retention_note || "Patvirtinu, kad dokumento kopija sistemoje nesaugoma.",
        sort_order: documentRequirements.length + 1,
      })
      .select("id")
      .single()

    setSaving(false)

    if (error) {
      setMessage(error.message)
      return
    }

    await writeAudit("document_requirement_created", "document_requirement", data?.id || null, requirementForm.document_type)
    setRequirementForm({ role: "VISI", document_type: "", validity_months: "12", required: true, retention_note: "" })
    await loadAll()
    setMessage("Dokumento reikalavimas pridėtas.")
  }

  async function addDocumentVerification() {
    if (!organizationId) return

    if (!verificationForm.employee_id || !verificationForm.document_type.trim()) {
      setMessage("Pasirink darbuotoją ir dokumento tipą.")
      return
    }

    if (!verificationForm.seen_confirmed || !verificationForm.no_copy_stored || !verificationForm.minimal_data_confirmed) {
      setMessage("Pažymėk visus BDAR patvirtinimus.")
      return
    }

    if (hasSensitiveWords(verificationForm.note)) {
      setMessage("Pastaboje yra perteklinių / jautrių duomenų. Įrašyk tik būtiną administracinę informaciją.")
      return
    }

    setSaving(true)
    setMessage("")

    const verificationPayload = {
      organization_id: organizationId,
      employee_id: verificationForm.employee_id,
      document_type: verificationForm.document_type.trim(),
      evidence_mode: verificationForm.evidence_mode,
      reference_no_masked: maskReferenceNo(verificationForm.reference_no),
      issuer: verificationForm.issuer || null,
      valid_from: verificationForm.valid_from || null,
      valid_until: verificationForm.valid_until || null,
      result: "verified",
      verified_by: verificationForm.verified_by || currentUserName || "Administratorius",
      no_copy_stored: true,
      legal_basis: "Darbo santykių administravimas / teisės aktų reikalavimai",
      note: verificationForm.note || null,
    }

    const { data, error } = await supabase
      .from("document_verifications")
      .insert(verificationPayload)
      .select("id")
      .single()

    setSaving(false)

    if (error) {
      setMessage(`${error.message}. Jei tai RLS klaida, paleisk pridėtą SQL migraciją.`)
      return
    }

    const optimisticRow: DocumentVerification = {
      id: data?.id || `local-${Date.now()}`,
      employee_id: verificationPayload.employee_id,
      document_type: verificationPayload.document_type,
      evidence_mode: verificationPayload.evidence_mode,
      reference_no_masked: verificationPayload.reference_no_masked,
      issuer: verificationPayload.issuer,
      valid_from: verificationPayload.valid_from,
      valid_until: verificationPayload.valid_until,
      result: verificationPayload.result,
      verified_by: verificationPayload.verified_by,
      verified_at: new Date().toISOString(),
      no_copy_stored: true,
      legal_basis: verificationPayload.legal_basis,
      note: verificationPayload.note,
    }

    setDocumentVerifications((prev) => [optimisticRow, ...prev.filter((item) => item.id !== optimisticRow.id)])
    await writeAudit("document_verified_no_copy", "document_verification", data?.id || null, `${verificationForm.document_type} / kopija nesaugoma`)
    setVerificationForm((prev) => ({ ...prev, reference_no: "", issuer: "", valid_from: "", valid_until: "", note: "", seen_confirmed: false, minimal_data_confirmed: false }))
    setDocsFilter("all")
    setMessage("Dokumento patikrinimas užregistruotas. Grafiko įspėjimai perskaičiuoti.")
  }

  async function addPersonnelInventoryItem() {
    if (!organizationId) return
    if (!inventoryForm.name.trim()) {
      setMessage("Įvesk daikto pavadinimą.")
      return
    }

    setSaving(true)
    setMessage("")

    const inventoryPayload = {
      organization_id: organizationId,
      name: inventoryForm.name.trim(),
      category: inventoryForm.category || null,
      serial_no: inventoryForm.serial_no || null,
      size: inventoryForm.size || null,
      condition: "Gera",
      status: "available",
    }

    let { error } = await supabase.from("personnel_inventory_items").insert(inventoryPayload)

    if (error && /organization_id|serial_no|status|condition|schema cache/i.test(error.message)) {
      const fallbackPayload = {
        name: inventoryForm.name.trim(),
        category: inventoryForm.category || null,
        size: inventoryForm.size || null,
        condition: "Gera",
      }
      const fallback = await supabase.from("personnel_inventory_items").insert(fallbackPayload)
      error = fallback.error
    }

    setSaving(false)

    if (error) {
      setMessage(error.message)
      return
    }

    setInventoryForm({ name: "", category: "", serial_no: "", size: "" })
    await loadAll()
    setMessage("Daiktas pridėtas.")
  }

  async function assignPersonnelInventoryItem() {
    if (!organizationId) return
    if (!assignmentForm.employee_id || !assignmentForm.item_id) {
      setMessage("Pasirink darbuotoją ir daiktą.")
      return
    }

    setSaving(true)
    setMessage("")

    const { error } = await supabase.from("personnel_inventory_assignments").insert({
      organization_id: organizationId,
      employee_id: assignmentForm.employee_id,
      item_id: assignmentForm.item_id,
      assigned_at: today(),
      condition_out: assignmentForm.condition_out || null,
      note: assignmentForm.note || null,
    })

    if (!error) {
      await supabase.from("personnel_inventory_items").update({ status: "assigned" }).eq("id", assignmentForm.item_id)
    }

    setSaving(false)

    if (error) {
      setMessage(error.message)
      return
    }

    setAssignmentForm((prev) => ({ ...prev, item_id: "", condition_out: "", note: "" }))
    await loadAll()
    setMessage("Daiktas priskirtas darbuotojui.")
  }


  const scheduleDays = useMemo(() => monthDays(scheduleMonth), [scheduleMonth])

  const scheduleMap = useMemo(() => {
    const result = new Map<string, ScheduleEntry>()

    for (const item of schedule) {
      result.set(`${item.employee_id}__${item.date}`, item)
    }

    return result
  }, [schedule])

  const scheduleGridData = useMemo(() => {
    return filteredEmployees.map((employee) => [
      `${employeeName(employee)}\n${employeeRole(employee)}`,
      ...scheduleDays.map((day) => scheduleCode(scheduleMap.get(`${employee.user_id}__${toDateInput(day)}`))),
    ])
  }, [filteredEmployees, scheduleDays, scheduleMap])

  const scheduleNestedHeaders = useMemo(() => {
    return [
      ["Darbuotojas", ...scheduleDays.map((day) => new Intl.DateTimeFormat("lt-LT", { weekday: "short" }).format(day))],
      ["Darbuotojas", ...scheduleDays.map((day) => String(day.getDate()).padStart(2, "0"))],
    ]
  }, [scheduleDays])

  const scheduleColumns = useMemo(() => {
    return [
      { data: 0, readOnly: true },
      ...scheduleDays.map(() => ({
        type: "text",
        allowInvalid: true,
      })),
    ]
  }, [scheduleDays])

  const scheduleColWidths = useMemo(() => [260, ...scheduleDays.map(() => 76)], [scheduleDays])

  const scheduleComplianceRows = useMemo(() => {
    const monthStart = toDateInput(scheduleDays[0] || scheduleMonth)
    const monthEnd = toDateInput(scheduleDays[scheduleDays.length - 1] || scheduleMonth)

    return filteredEmployees.map((employee) => {
      const employeeEntries = schedule
        .filter((entry) => entry.employee_id === employee.user_id)
        .sort((a, b) => String(a.start_datetime || a.date).localeCompare(String(b.start_datetime || b.date)))

      const monthEntries = employeeEntries.filter((entry) => entry.date >= monthStart && entry.date <= monthEnd)
      const plannedHours = monthEntries.reduce((sum, entry) => sum + scheduleHours(entry), 0)
      const intervals = employeeEntries.map(scheduleInterval).filter((value): value is { start: number; end: number; hours: number; date: string } => value !== null)

      let maxSevenDayHours = 0
      let maxSevenDayWorkDays = 0
      let minWeeklyRestHours: number | null = null

      for (const day of scheduleDays) {
        const windowStartDate = toDateInput(day)
        const windowEndDate = toDateInput(addDays(day, 6))
        const windowEntries = employeeEntries.filter((entry) => entry.date >= windowStartDate && entry.date <= windowEndDate)
        const windowHours = windowEntries.reduce((sum, entry) => sum + scheduleHours(entry), 0)
        const windowWorkDays = new Set(windowEntries.filter((entry) => scheduleHours(entry) > 0).map((entry) => entry.date)).size
        const windowStart = new Date(`${windowStartDate}T00:00:00`).getTime()
        const windowEnd = new Date(`${toDateInput(addDays(day, 7))}T00:00:00`).getTime()
        const weeklyRest = longestRestInWindow(intervals, windowStart, windowEnd)

        maxSevenDayHours = Math.max(maxSevenDayHours, windowHours)
        maxSevenDayWorkDays = Math.max(maxSevenDayWorkDays, windowWorkDays)
        minWeeklyRestHours = minWeeklyRestHours === null ? weeklyRest : Math.min(minWeeklyRestHours, weeklyRest)
      }

      let shortestRestHours: number | null = null
      const errors: string[] = []
      const warnings: string[] = []

      const documentIssue = documentIssuesByEmployee.get(employee.user_id)
      if (documentIssue?.errors.length) errors.push(...documentIssue.errors)
      if (documentIssue?.warnings.length) warnings.push(...documentIssue.warnings)

      for (let i = 0; i < intervals.length; i += 1) {
        if (intervals[i].hours > 24) errors.push(`${intervals[i].date}: pamaina ilgesnė nei 24 val.`)
        if (intervals[i].hours > 12) warnings.push(`${intervals[i].date}: pamaina ilgesnė nei 12 val. po jos reikia bent 24 val. poilsio`)
      }

      for (let i = 1; i < intervals.length; i += 1) {
        const previous = intervals[i - 1]
        const next = intervals[i]
        const restHours = (next.start - previous.end) / 3600000

        if (restHours < 0) {
          errors.push(`${next.date}: pamaina persidengia su ankstesne pamaina`)
          continue
        }

        shortestRestHours = shortestRestHours === null ? restHours : Math.min(shortestRestHours, restHours)
        if (restHours < 11) errors.push(`${next.date}: poilsis tarp pamainų ${restHours.toFixed(1)} val. (< 11 val.)`)
        if (previous.hours > 12 && restHours < 24) errors.push(`${next.date}: po ilgesnės nei 12 val. pamainos poilsis ${restHours.toFixed(1)} val. (< 24 val.)`)
      }

      if (maxSevenDayHours > 52) errors.push(`viršyta suminės apskaitos riba: ${maxSevenDayHours.toFixed(1)} val. per 7 d. (> 52 val.)`)
      else if (maxSevenDayHours > 48) warnings.push(`arti bendros 48 val. vidutinės ribos: ${maxSevenDayHours.toFixed(1)} val. per 7 d.`)

      if (maxSevenDayWorkDays > 6) errors.push(`daugiau nei 6 darbo dienos per bet kurias 7 d. (${maxSevenDayWorkDays}/7)`)
      if (minWeeklyRestHours !== null && minWeeklyRestHours < 35) errors.push(`nėra 35 val. nepertraukiamo savaitinio poilsio (${minWeeklyRestHours.toFixed(1)} val.)`)

      const averageWeeklyHours = scheduleDays.length ? plannedHours / scheduleDays.length * 7 : 0
      if (averageWeeklyHours > 48) errors.push(`mėnesio vidurkis viršija 48 val. per savaitę (${averageWeeklyHours.toFixed(1)} val.)`)

      const uniqueWarnings = Array.from(new Set([...errors, ...warnings]))

      return {
        employee,
        plannedHours,
        maxSevenDayHours,
        maxSevenDayWorkDays,
        shortestRestHours,
        minWeeklyRestHours,
        averageWeeklyHours,
        status: errors.length ? "Kritinė klaida" : warnings.length ? "Įspėjimas" : "Gerai",
        errors: Array.from(new Set(errors)),
        warnings: uniqueWarnings,
      }
    })
  }, [documentIssuesByEmployee, filteredEmployees, schedule, scheduleDays, scheduleMonth])

  const scheduleWarningRows = useMemo(() => scheduleComplianceRows.filter((row) => row.warnings.length), [scheduleComplianceRows])


  function openEmployeeEditor(employee: Employee) {
    setTrainingEntryEmployee(null)
    setTrainingDetailsEmployeeId(null)
    setEditingEmployee(employee)
    setEditForm({
      first_name: employee.first_name || "",
      last_name: employee.last_name || "",
      full_name: employee.full_name || "",
      email: employee.email || "",
      position: employee.position || "",
      department: employee.department || "",
      professional_license_number: employee.professional_license_number || "",
      professional_license_valid_until: employee.professional_license_valid_until || "",
      occupational_health_valid_until: employee.occupational_health_valid_until || "",
    })

    setCredentialForm((prev) => ({ ...prev, employee_id: employee.user_id }))
    setTrainingForm((prev) => ({
      ...prev,
      employee_id: employee.user_id,
      title: "",
      training_id: "",
      category: "",
      hours: "1",
      provider: "",
      completed_at: today(),
      expires_at: "",
      certificate_no: "",
      verified_by: currentUserName,
    }))
  }

  async function saveEmployeeEditor() {
    if (!editingEmployee || !organizationId) return

    const cleanFirstName = editForm.first_name.trim()
    const cleanLastName = editForm.last_name.trim()
    const cleanFullName = editForm.full_name.trim() || [cleanFirstName, cleanLastName].filter(Boolean).join(" ").trim()
    const profilePayload = {
      first_name: cleanFirstName || null,
      last_name: cleanLastName || null,
      full_name: cleanFullName || null,
    }
    const previousProfilePayload = {
      first_name: editingEmployee.first_name || null,
      last_name: editingEmployee.last_name || null,
      full_name: editingEmployee.full_name || null,
    }
    const memberPayload = {
      position: editForm.position.trim() || null,
      department: editForm.department.trim() || null,
      professional_license_number: editForm.professional_license_number.trim() || null,
      professional_license_valid_until: editForm.professional_license_valid_until || null,
      occupational_health_valid_until: editForm.occupational_health_valid_until || null,
    }
    const previousMemberPayload = {
      position: editingEmployee.position || null,
      department: editingEmployee.department || null,
      professional_license_number: editingEmployee.professional_license_number || null,
      professional_license_valid_until: editingEmployee.professional_license_valid_until || null,
      occupational_health_valid_until: editingEmployee.occupational_health_valid_until || null,
    }

    try {
      setSaving(true)
      setMessage("")

      const profileUpdate = await supabase.from("profiles").update(profilePayload).eq("id", editingEmployee.user_id)

      if (profileUpdate.error) {
        setMessage(profileUpdate.error.message)
        return
      }

      const memberUpdate = await supabase
        .from("organization_members")
        .update(memberPayload)
        .eq("user_id", editingEmployee.user_id)
        .eq("organization_id", organizationId)

      if (memberUpdate.error) {
        await supabase.from("profiles").update(previousProfilePayload).eq("id", editingEmployee.user_id)
        setMessage(memberUpdate.error.message)
        return
      }

      await loadAll()
      setEditingEmployee(null)
      setMessage("Darbuotojo duomenys išsaugoti.")

      if (typeof window !== "undefined") {
        window.alert("Darbuotojo duomenys išsaugoti.")
      }
    } catch (error) {
      await supabase
        .from("organization_members")
        .update(previousMemberPayload)
        .eq("user_id", editingEmployee.user_id)
        .eq("organization_id", organizationId)
      await supabase.from("profiles").update(previousProfilePayload).eq("id", editingEmployee.user_id)
      setMessage(error instanceof Error ? error.message : "Nepavyko išsaugoti darbuotojo.")
    } finally {
      setSaving(false)
    }
  }

  async function saveScheduleGridChanges(changes: Array<[number, number | string, unknown, unknown]>) {
    if (!organizationId || !changes.length) return

    setSaving(true)
    setMessage("")

    let failedMessage = ""

    try {
      for (const [rowIndex, prop, _oldValue, newValue] of changes) {
        const colIndex = typeof prop === "number" ? prop : Number(prop)
        if (!Number.isFinite(colIndex) || colIndex === 0) continue

        const employee = filteredEmployees[rowIndex]
        const day = scheduleDays[colIndex - 1]
        if (!employee || !day) continue

        const date = toDateInput(day)
        const normalized = normalizeScheduleCode(newValue)

        if (normalized.error) {
          failedMessage = normalized.error
          break
        }

        const remove = await supabase
          .from("personnel_schedule_entries")
          .delete()
          .eq("organization_id", organizationId)
          .eq("employee_id", employee.user_id)
          .eq("date", date)

        if (remove.error) {
          failedMessage = remove.error.message
          break
        }

        if (!normalized.status) continue

        const start = normalized.start ? `${date}T${normalized.start}` : null
        let end = normalized.end ? `${date}T${normalized.end}` : null

        if (start && end && end <= start) {
          const nextDay = new Date(`${date}T00:00:00`)
          nextDay.setDate(nextDay.getDate() + 1)
          end = `${toDateInput(nextDay)}T${normalized.end}`
        }

        const insert = await supabase.from("personnel_schedule_entries").insert({
          organization_id: organizationId,
          employee_id: employee.user_id,
          date,
          start_datetime: start,
          end_datetime: end,
          status: normalized.status,
        })

        if (insert.error) {
          failedMessage = insert.error.message
          break
        }
      }

      if (failedMessage) {
        const lower = failedMessage.toLowerCase()
        setMessage(
          lower.includes("row-level security") || lower.includes("security policy") || lower.includes("violates")
            ? "Grafiko nepavyko išsaugoti: Supabase RLS neleidžia rašyti į personnel_schedule_entries. Reikia pritaikyti pridėtą SQL policy failą."
            : failedMessage
        )
        return
      }

      await loadAll()
      setMessage("Grafikas atnaujintas.")
    } finally {
      setSaving(false)
    }
  }

  if (loading) return <div style={styles.page}>Kraunama...</div>

  return (
    <main style={styles.page}>
      <section style={styles.hero}>
        <div>
          <div style={styles.kicker}>
            <BriefcaseBusiness size={16} />
            Personalo modulis
          </div>
          <h1 style={styles.title}>Komanda</h1>
          <p style={styles.subtitle}>
            Darbuotojų registras, grafikai, pažymos, licencijos, mokymai, atostogos ir kandidatai vienoje vietoje.
          </p>
        </div>

        <button type="button" style={styles.secondaryButton} onClick={() => void loadAll()}>
          <RefreshCw size={16} />
          Atnaujinti
        </button>
      </section>

      {message ? <div style={message.toLowerCase().includes("klaid") || message.toLowerCase().includes("nepavyko") || message.toLowerCase().includes("invalid") || message.toLowerCase().includes("violates") || message.toLowerCase().includes("policy") || message.toLowerCase().includes("security") || message.toLowerCase().includes("rls") ? styles.error : styles.message}>{message}</div> : null}

      <section style={styles.statsGrid}>
        <Stat title="Darbuotojai" value={employees.length} icon={Users} />
        <Stat title="Laukia atostogų" value={pendingVacations.length} icon={Umbrella} danger={pendingVacations.length > 0} onClick={() => setTab("vacations")} />
        <Stat title="Baigiasi dokumentai" value={expiringCredentials.length + expiringVerifiedDocuments} icon={AlertTriangle} danger={expiringCredentials.length + expiringVerifiedDocuments > 0} onClick={() => openDocs("expiring")} />
        <Stat title="Trūksta dokumentų patikrų" value={missingDocuments} icon={BadgeCheck} danger={missingDocuments > 0} onClick={() => openDocs("missing")} />
        <Stat title="Mokymų neatitikimai" value={trainingNonCompliantEmployees} icon={GraduationCap} danger={trainingNonCompliantEmployees > 0} onClick={() => setTab("trainings")} />
        <Stat title="Artimiausi grafikai" value={activeSchedule.length} icon={CalendarDays} onClick={() => setTab("schedule")} />
      </section>

      <section style={styles.tabs}>
        {tabs.map((item) => {
          const Icon = item.icon
          return (
            <button key={item.key} type="button" style={tab === item.key ? styles.tabActive : styles.tab} onClick={() => setTab(item.key)}>
              <Icon size={16} />
              {item.label}
            </button>
          )
        })}
      </section>

      {tab === "overview" ? (
        <section style={styles.overviewStack}>
          <section style={styles.overviewHero}>
            <div>
              <p style={styles.kicker}>Veiksmų centras</p>
              <h2 style={styles.overviewTitle}>Ką reikia sutvarkyti dabar?</h2>
              <p style={styles.overviewText}>Apžvalga rodo ne tik duomenis, bet ir konkrečius veiksmus: dokumentų rizikas, laukiančius prašymus, mokymų neatitikimus ir artimiausią grafiką.</p>
            </div>
            <div style={styles.overviewScore}>
              <span style={styles.overviewScoreValue}>{compliancePercent}%</span>
              <span style={styles.overviewScoreLabel}>dokumentų atitiktis</span>
            </div>
          </section>

          <section style={styles.attentionGrid}>
            {overviewAttentionItems.map((item) => (
              <button key={`${item.title}-${item.value}`} type="button" style={item.tone === "bad" ? styles.attentionBad : item.tone === "warn" ? styles.attentionWarn : item.tone === "good" ? styles.attentionGood : styles.attentionMuted} onClick={item.onClick}>
                <span style={styles.attentionTitle}>{item.title}</span>
                <strong style={styles.attentionValue}>{item.value}</strong>
                <span style={styles.attentionAction}>{item.action} →</span>
              </button>
            ))}
          </section>

          <section style={styles.gridTwo}>
            <Card title="Dokumentų rizikos">
              <div style={styles.miniStats}>
                <button type="button" style={styles.miniStatBadButton} onClick={() => openDocs("expired")}>Pasibaigę: {credentialStatusCounts.expired}</button>
                <button type="button" style={styles.miniStatWarnButton} onClick={() => openDocs("expiring")}>Baigiasi: {credentialStatusCounts.expiring}</button>
                <button type="button" style={styles.miniStatMutedButton} onClick={() => openDocs("missing")}>Trūksta: {credentialStatusCounts.missing}</button>
              </div>
              <DataTable
                columns={["Darbuotojas", "Tipas", "Galioja iki", "Būsena", "Veiksmai"]}
                rows={overviewDocumentRiskRows.map((item) => [
                  item.employeeName,
                  item.type,
                  fmt(item.expires_at),
                  <DocumentStatusPill key={`${item.id}-status`} status={item.status as "valid" | "expiring" | "expired" | "missing"} />,
                  <button key={`${item.id}-action`} type="button" style={styles.smallActionSecondary} onClick={() => openDocs(item.status as DocsFilter)}>Tvarkyti</button>,
                ])}
                empty="Dokumentų rizikų nėra."
              />
            </Card>

            <Card title="Artimiausi grafiko įrašai">
              <div style={styles.listHeader}>
                <p style={styles.sectionHint}>Ši lentelė skirta greitam kontekstui. Pilnam planavimui atidarykite grafiko skiltį.</p>
                <button type="button" style={styles.smallAction} onClick={() => setTab("schedule")}>Atidaryti grafiką</button>
              </div>
              <DataTable
                columns={["Data", "Darbuotojas", "Laikas", "Būsena"]}
                rows={activeSchedule.map((item) => [
                  fmt(item.date),
                  employeeName(map.get(item.employee_id)),
                  scheduleTableStart(item) === "Visa diena" ? "Visa diena" : `${scheduleTableStart(item)}–${scheduleTableEnd(item)}`,
                  <ScheduleStatusPill key={`${item.id}-schedule-status`} status={item.status as "valid" | "expiring" | "expired" | "missing"} />,
                ])}
                empty="Grafiko įrašų nėra."
              />
            </Card>
          </section>
        </section>
      ) : null}

      {tab === "employees" ? (
        <Card title="Darbuotojų registras">
          <div style={styles.searchBox}>
            <Search size={18} color="#94a3b8" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Ieškoti pagal vardą, pareigas, skyrių..." style={styles.searchInput} />
          </div>

          <div style={styles.employeeGrid}>
            {filteredEmployees.map((employee) => (
              <article key={employee.user_id} style={styles.employeeCard}>
                <div style={styles.avatar}>{employeeName(employee).slice(0, 2).toUpperCase()}</div>
                <div>
                  <h3 style={styles.cardName}>{employeeName(employee)}</h3>
                  <p style={styles.cardMeta}>{employeeRole(employee)}</p>
                  <p style={styles.cardMeta}>{employee.department || "Skyrius nenurodytas"}</p>
                </div>
                <div style={styles.cardActions}>
                  <div style={styles.badge}>{employee.is_active === false ? "Neaktyvus" : "Aktyvus"}</div>
                  <button type="button" style={styles.iconButton} onClick={() => openEmployeeEditor(employee)} title="Redaguoti darbuotoją">
                    <Edit3 size={16} />
                  </button>
                </div>
              </article>
            ))}
          </div>
        </Card>
      ) : null}

      {tab === "schedule" ? (
        <ScheduleBlock
          employees={filteredEmployees}
          schedule={schedule}
          scheduleMonth={scheduleMonth}
          setScheduleMonth={setScheduleMonth}
          scheduleDays={scheduleDays}
          scheduleGridData={scheduleGridData}
          scheduleComplianceRows={scheduleComplianceRows}
          scheduleWarningRows={scheduleWarningRows}
          saving={saving}
          addMonths={addMonths}
          monthLabel={monthLabel}
          toDateInput={toDateInput}
          employeeName={employeeName}
          employeeRole={employeeRole}
          onSaveGridChanges={saveScheduleGridChanges}
        />
      ) : null}

      {tab === "vacations" ? (
        <Card title="Atostogų prašymai">
          <div style={styles.formGrid}>
            <EmployeeSelect value={vacationForm.employee_id} employees={employees} onChange={(value) => setVacationForm({ ...vacationForm, employee_id: value })} />
            <input type="date" value={vacationForm.start_date} onChange={(e) => setVacationForm({ ...vacationForm, start_date: e.target.value })} style={styles.input} />
            <input type="date" value={vacationForm.end_date} onChange={(e) => setVacationForm({ ...vacationForm, end_date: e.target.value })} style={styles.input} />
            <input value={vacationForm.note} onChange={(e) => setVacationForm({ ...vacationForm, note: e.target.value })} placeholder="Pastaba" style={styles.input} />
            <button type="button" style={styles.primaryButton} disabled={saving} onClick={() => void addVacation()}>
              <Plus size={16} />
              Pateikti
            </button>
          </div>

          <DataTable
            columns={["Darbuotojas", "Nuo", "Iki", "Dienos", "Būsena", "Veiksmai"]}
            rows={vacations.map((item) => [
              employeeName(map.get(item.employee_id)),
              fmt(item.start_date),
              fmt(item.end_date),
              item.requested_days || daysBetween(item.start_date, item.end_date),
              vacationStatusText(item.status),
              item.status === "submitted" ? (
                <div key={`${item.id}-impact`} style={styles.approvalImpact}>
                  <span style={styles.impactText}>{vacationDecisionImpact(item).label}</span>
                  {vacationDecisionImpact(item).warnings.length ? (
                    <span style={styles.impactWarning}>{vacationDecisionImpact(item).warnings[0]}</span>
                  ) : null}
                  <button type="button" style={styles.smallAction} onClick={() => void approveVacation(item.id)}>
                    Patvirtinti
                  </button>
                </div>
              ) : "—",
            ])}
            empty="Atostogų prašymų nėra."
          />
        </Card>
      ) : null}

      {tab === "docs" ? (
        <section style={styles.docsCenter}>
          <Card title="Pažymų / licencijų valdymo centras">
            <section style={styles.complianceHero}>
              <div>
                <div style={styles.kicker}>Atitikties suvestinė</div>
                <h3 style={styles.complianceScore}>{compliancePercent}%</h3>
                <p style={styles.sectionHint}>Darbuotojų dokumentų atitiktis pagal užregistruotas pažymas ir privalomus dokumentų patikrinimus.</p>
              </div>
              <div style={styles.complianceBadges}>
                <button type="button" style={docsFilter === "all" ? styles.filterPillActive : styles.filterPill} onClick={() => openDocs("all")}>Visi · {credentialStatusCounts.all}</button>
                <button type="button" style={docsFilter === "valid" ? styles.filterPillActive : styles.filterPill} onClick={() => openDocs("valid")}>Galioja · {credentialStatusCounts.valid}</button>
                <button type="button" style={docsFilter === "expiring" ? styles.filterPillActiveWarn : styles.filterPill} onClick={() => openDocs("expiring")}>Baigiasi · {credentialStatusCounts.expiring}</button>
                <button type="button" style={docsFilter === "expired" ? styles.filterPillActiveBad : styles.filterPill} onClick={() => openDocs("expired")}>Pasibaigė · {credentialStatusCounts.expired}</button>
                <button type="button" style={docsFilter === "missing" ? styles.filterPillActiveMuted : styles.filterPill} onClick={() => openDocs("missing")}>Trūksta · {credentialStatusCounts.missing}</button>
              </div>
            </section>

            {credentialStatusCounts.expiring || credentialStatusCounts.expired || credentialStatusCounts.missing ? (
              <div style={styles.warningBar}>
                <AlertTriangle size={18} />
                <span>
                  Yra dokumentų rizikų: {credentialStatusCounts.expiring} baigiasi, {credentialStatusCounts.expired} pasibaigė, {credentialStatusCounts.missing} trūksta. Tokius darbuotojus grafike verta žymėti įspėjimu.
                </span>
              </div>
            ) : (
              <div style={styles.successBar}>
                <ShieldCheck size={18} />
                <span>Dokumentų rizikų nėra. Visi registruoti dokumentai galioja.</span>
              </div>
            )}

            <div style={styles.docsLayout}>
              <section style={styles.docsFormCard}>
                <h3 style={styles.sectionTitle}>Nauja pažyma / licencija</h3>
                <p style={styles.sectionHint}>Failų kelti nereikia – saugomas tik dokumento faktas, numeris, galiojimas ir pastaba.</p>

                <div style={styles.docsFormGrid}>
                  <label style={styles.fieldLabel}>
                    <span>Darbuotojas</span>
                    <EmployeeSelect value={credentialForm.employee_id} employees={employees} onChange={(value) => setCredentialForm({ ...credentialForm, employee_id: value })} />
                  </label>
                  <label style={styles.fieldLabel}>
                    <span>Tipas</span>
                    <input
                      list="credential-type-options"
                      value={credentialForm.type}
                      onChange={(e) => setCredentialForm({ ...credentialForm, type: e.target.value })}
                      placeholder="Sveikatos pažyma / licencija"
                      style={styles.input}
                    />
                    <datalist id="credential-type-options">
                      {[...new Set(["Sveikatos pažyma", "Profesinė licencija", ...documentRequirements.map((item) => item.document_type)])].map((type) => (
                        <option key={type} value={type} />
                      ))}
                    </datalist>
                  </label>
                  <label style={styles.fieldLabel}>
                    <span>Numeris</span>
                    <input value={credentialForm.number} onChange={(e) => setCredentialForm({ ...credentialForm, number: e.target.value })} placeholder="Dokumento nr." style={styles.input} />
                  </label>
                  <label style={styles.fieldLabel}>
                    <span>Išdavė</span>
                    <input value={credentialForm.issuer} onChange={(e) => setCredentialForm({ ...credentialForm, issuer: e.target.value })} placeholder="Įstaiga / institucija" style={styles.input} />
                  </label>
                  <label style={styles.fieldLabel}>
                    <span>Galioja nuo</span>
                    <input type="date" value={credentialForm.issued_at} onChange={(e) => setCredentialForm({ ...credentialForm, issued_at: e.target.value })} style={styles.input} />
                  </label>
                  <label style={styles.fieldLabel}>
                    <span>Galioja iki</span>
                    <input type="date" value={credentialForm.expires_at} onChange={(e) => setCredentialForm({ ...credentialForm, expires_at: e.target.value })} style={styles.input} />
                  </label>
                </div>

                <label style={styles.fieldLabel}>
                  <span>Pastaba</span>
                  <input value={credentialForm.note} onChange={(e) => setCredentialForm({ ...credentialForm, note: e.target.value })} placeholder="Neprivaloma pastaba" style={styles.input} />
                </label>

                <div style={styles.stickySaveRow}>
                  <button type="button" style={styles.primaryButton} disabled={saving} onClick={() => void addCredential()}>
                    <Plus size={16} />
                    {saving ? "Saugoma..." : "Išsaugoti"}
                  </button>
                </div>
              </section>

              <section style={styles.docsListCard}>
                <div style={styles.listHeader}>
                  <div>
                    <h3 style={styles.sectionTitle}>Dokumentų sąrašas</h3>
                    <p style={styles.sectionHint}>Filtras: {formatDocumentFilter(docsFilter)}</p>
                  </div>
                  <button type="button" style={styles.secondaryButton} onClick={() => openDocs("all")}>Rodyti visus</button>
                </div>

                <DataTable
                  columns={["Darbuotojas", "Tipas", "Nr.", "Galioja iki", "Būsena", "Veiksmai"]}
                  rows={credentialCenterRows.map((item) => [
                    item.employeeName,
                    item.type,
                    item.number,
                    fmt(item.expires_at),
                    <span key={`${item.id}-status`} style={item.status === "valid" ? styles.statusGood : item.status === "expiring" ? styles.statusWarn : item.status === "expired" ? styles.statusBad : styles.statusMuted}>{documentStatusText(item.status)}</span>,
                    item.kind === "missing" ? (
                      <button key={`${item.id}-action`} type="button" style={styles.smallActionSecondary} onClick={() => setTab("documentChecks")}>Patikrinti</button>
                    ) : (
                      <span key={`${item.id}-action`}>{item.action}</span>
                    ),
                  ])}
                  empty="Dokumentų dar nėra. Pridėk pirmą pažymą arba licenciją kairėje esančioje formoje."
                />
              </section>
            </div>
          </Card>
        </section>
      ) : null}
      {tab === "trainings" ? (
        <section style={styles.gridTwo}>
          <Card title="Mokymų suvestinė">
            <section style={styles.statsGrid}>
              <Stat title="Neatitinka darbuotojų" value={trainingNonCompliantEmployees} icon={AlertTriangle} danger={trainingNonCompliantEmployees > 0} />
              <Stat title="Trūksta mokymų" value={trainingMissing} icon={ClipboardCheck} danger={trainingMissing > 0} />
              <Stat title="Baigiasi / pasibaigė" value={trainingExpiring} icon={CalendarDays} danger={trainingExpiring > 0} />
              <Stat title="Sukaupta valandų" value={totalTrainingHours} icon={GraduationCap} />
            </section>

            <DataTable
              columns={["Darbuotojas", "Mokymas", "Būsena", "Baigta", "Galioja iki", "Val.", "Patikrino", "Veiksmai"]}
              rows={trainingCompliance
                .filter((row) => row.status !== "valid")
                .map((row) => [
                  employeeName(row.employee),
                  row.training.name,
                  <span key={`${row.employee.user_id}-${row.training.id}-status`} style={trainingStatusStyle(row.status)}>{trainingStatusLabel(row.status)}</span>,
                  fmt(row.completed_at),
                  fmt(row.expires_at),
                  row.hours,
                  row.verified_by || "—",
                  <div key={`${row.employee.user_id}-${row.training.id}-actions`} style={styles.rowActions}>
                    <button type="button" style={styles.smallAction} onClick={() => setTrainingDetailsEmployeeId(row.employee.user_id)}>Peržiūrėti</button>
                    <button type="button" style={styles.smallActionSecondary} onClick={() => openTrainingEntry(row.employee, row)}>Pridėti mokymus</button>
                  </div>,
                ])}
              empty="Visi darbuotojai atitinka mokymų reikalavimus."
            />
          </Card>

          <Card title="Įvesti darbuotojo mokymus">
            <div style={styles.notice}>
              BDAR principas: pažymėjimo kopijos nesaugomos. Fiksuojamas tik mokymo faktas, data, galiojimas ir kas patikrino.
            </div>

            <div style={styles.formGrid}>
              <EmployeeSelect value={trainingForm.employee_id} employees={employees} onChange={(value) => setTrainingForm({ ...trainingForm, employee_id: value })} />
              <select value={trainingForm.training_id} onChange={(e) => {
                const selected = effectiveTrainingCatalog.find((item) => item.id === e.target.value)
                setTrainingForm({
                  ...trainingForm,
                  training_id: e.target.value,
                  title: selected?.name || "",
                  category: selected?.category || "",
                  hours: String(selected?.hours || 1),
                  expires_at: selected?.valid_for_months && trainingForm.completed_at ? calculateTrainingExpiry(trainingForm.completed_at, selected.valid_for_months) : "",
                })
              }} style={styles.input}>
                <option value="">Pasirinkti mokymą iš katalogo</option>
                {effectiveTrainingCatalog.map((item) => (
                  <option key={item.id} value={item.id}>{item.name} · {item.category}</option>
                ))}
              </select>
              <input value={trainingForm.title} onChange={(e) => setTrainingForm({ ...trainingForm, title: e.target.value })} placeholder="Mokymų pavadinimas" style={styles.input} />
              <input value={trainingForm.category} onChange={(e) => setTrainingForm({ ...trainingForm, category: e.target.value })} placeholder="Kategorija" style={styles.input} />
              <input type="number" value={trainingForm.hours} onChange={(e) => setTrainingForm({ ...trainingForm, hours: e.target.value })} placeholder="Valandos" style={styles.input} />
              <input value={trainingForm.provider} onChange={(e) => setTrainingForm({ ...trainingForm, provider: e.target.value })} placeholder="Teikėjas" style={styles.input} />
              <input type="date" value={trainingForm.completed_at} onChange={(e) => {
                const selected = effectiveTrainingCatalog.find((item) => item.id === trainingForm.training_id)
                setTrainingForm({
                  ...trainingForm,
                  completed_at: e.target.value,
                  expires_at: selected?.valid_for_months ? calculateTrainingExpiry(e.target.value, selected.valid_for_months) : trainingForm.expires_at,
                })
              }} style={styles.input} />
              <input type="date" value={trainingForm.expires_at} onChange={(e) => setTrainingForm({ ...trainingForm, expires_at: e.target.value })} style={styles.input} />
              <input value={trainingForm.verified_by} onChange={(e) => setTrainingForm({ ...trainingForm, verified_by: e.target.value })} placeholder="Patikrino" style={styles.input} />
              <input value={trainingForm.certificate_no} onChange={(e) => setTrainingForm({ ...trainingForm, certificate_no: e.target.value })} placeholder="Pažymėjimo nr. / neprivaloma" style={styles.input} />
              <button type="button" style={styles.primaryButton} disabled={saving} onClick={() => void addTraining()}>
                <Plus size={16} />
                Išsaugoti mokymus
              </button>
            </div>
          </Card>

          <Card title="Mokymų katalogas">
            <div style={styles.formGrid}>
              <input value={catalogForm.name} onChange={(e) => setCatalogForm({ ...catalogForm, name: e.target.value })} placeholder="Mokymo pavadinimas" style={styles.input} />
              <select value={catalogForm.category} onChange={(e) => setCatalogForm({ ...catalogForm, category: e.target.value })} style={styles.input}>
                <option>Visiems darbuotojams</option>
                <option>Socialinė sritis</option>
                <option>Sveikatos priežiūra</option>
                <option>Maisto blokas</option>
                <option>Ūkio / techniniai darbuotojai</option>
                <option>Administracija</option>
              </select>
              <input type="number" value={catalogForm.valid_for_months} onChange={(e) => setCatalogForm({ ...catalogForm, valid_for_months: e.target.value })} placeholder="Galioja mėn." style={styles.input} />
              <input type="number" value={catalogForm.hours} onChange={(e) => setCatalogForm({ ...catalogForm, hours: e.target.value })} placeholder="Valandos" style={styles.input} />
              <select value={catalogForm.applies_to} onChange={(e) => setCatalogForm({ ...catalogForm, applies_to: e.target.value })} style={styles.input}>
                <option value="VISI">Visi</option>
                <option value="SOCIALINIAI">Socialinė sritis</option>
                <option value="SLAUGYTOJAI">Sveikatos priežiūra</option>
                <option value="MAISTO BLOKAS">Maisto blokas</option>
                <option value="ŪKIS">Ūkio / techniniai</option>
                <option value="ADMINISTRACIJA">Administracija</option>
              </select>
              <button type="button" style={styles.primaryButton} disabled={saving} onClick={() => void addTrainingCatalogItem()}>
                <Plus size={16} />
                Pridėti į katalogą
              </button>
            </div>

            <DataTable
              columns={["Mokymas", "Kategorija", "Taikoma", "Galioja mėn.", "Val."]}
              rows={effectiveTrainingCatalog.map((item) => [
                item.name,
                item.category,
                item.applies_to || "VISI",
                item.valid_for_months || "Neribota",
                item.hours || 0,
              ])}
              empty="Mokymų katalogas tuščias."
            />
          </Card>

          <Card title="Pareigybių reikalavimų matrica">
            <div style={styles.formGrid}>
              <select value={trainingRequirementForm.position} onChange={(e) => setTrainingRequirementForm({ ...trainingRequirementForm, position: e.target.value })} style={styles.input}>
                <option value="VISI">Visi</option>
                <option value="SLAUGYTOJAI">Slaugytojai</option>
                <option value="SOCIALINIAI">Socialiniai darbuotojai</option>
                <option value="MAISTO BLOKAS">Maisto blokas</option>
                <option value="ŪKIS">Ūkio / techniniai</option>
                <option value="ADMINISTRACIJA">Administracija</option>
              </select>
              <select value={trainingRequirementForm.training_id} onChange={(e) => setTrainingRequirementForm({ ...trainingRequirementForm, training_id: e.target.value })} style={styles.input}>
                <option value="">Pasirinkti mokymą</option>
                {effectiveTrainingCatalog.map((item) => (
                  <option key={item.id} value={item.id}>{item.name}</option>
                ))}
              </select>
              <button type="button" style={styles.primaryButton} disabled={saving} onClick={() => void addTrainingRequirement()}>
                <Plus size={16} />
                Pridėti reikalavimą
              </button>
            </div>

            <DataTable
              columns={["Pareigybė", "Mokymas", "Privaloma"]}
              rows={trainingRequirements.map((item) => [
                item.position,
                effectiveTrainingCatalog.find((training) => training.id === item.training_id)?.name || item.training_id,
                item.required ? "Taip" : "Ne",
              ])}
              empty="Papildomų pareigybių reikalavimų dar nėra. Naudojami numatytieji pagal kategorijas."
            />
          </Card>

          <Card title="Priminimai">
            <DataTable
              columns={["Darbuotojas", "Mokymas", "Būsena", "Galioja iki", "Priminimai"]}
              rows={trainingReminders.map((row) => [
                employeeName(row.employee),
                row.training.name,
                trainingStatusLabel(row.status),
                fmt(row.expires_at),
                row.status === "expired" ? "Pasibaigus" : "30 d. / 7 d.",
              ])}
              empty="Priminimų nėra."
            />
          </Card>
        </section>
      ) : null}

      {tab === "documentChecks" ? (
        <section style={styles.gridTwo}>
          <Card title="BDAR saugus dokumento patikrinimas">
            <div style={styles.notice}>
              Šis blokas skirtas dokumentų patikrinimo faktui registruoti be dokumento kopijos. Sistema saugo tik: kokį dokumentą darbuotojas parodė, kada jis galioja, kas patikrino ir kad kopija sistemoje nesaugoma.
            </div>

            <div style={styles.helpBox}>
              <strong>Kokias datas pildyti?</strong>
              <span><b>Galioja nuo</b> — dokumento išdavimo arba galiojimo pradžios data, jei ji matoma dokumente.</span>
              <span><b>Galioja iki</b> — dokumento pabaigos data. Pagal ją sistema rodys priminimus ir neatitikimus.</span>
              <span>Jei dokumentas neturi pabaigos datos, lauką „Galioja iki“ galima palikti tuščią.</span>
            </div>

            <div style={styles.formGrid}>
              <EmployeeSelect value={verificationForm.employee_id} employees={employees} onChange={(value) => setVerificationForm({ ...verificationForm, employee_id: value })} />
              <select value={verificationForm.document_type} onChange={(e) => setVerificationForm({ ...verificationForm, document_type: e.target.value })} style={styles.input}>
                {[...new Set(["Sveikatos pažyma", "Profesinė licencija", ...documentRequirements.map((item) => item.document_type)])].map((item) => (
                  <option key={item} value={item}>{item}</option>
                ))}
              </select>
              <select value={verificationForm.evidence_mode} onChange={(e) => setVerificationForm({ ...verificationForm, evidence_mode: e.target.value })} style={styles.input}>
                <option value="seen_original">Matytas originalas vietoje</option>
                <option value="checked_register">Patikrinta oficialiame registre</option>
                <option value="employee_presented">Darbuotojas pateikė, kopija nesaugoma</option>
              </select>
              <label style={styles.fieldLabel}>
                <span>Dokumento nr. / paskutiniai 4 simboliai</span>
                <input value={verificationForm.reference_no} onChange={(e) => setVerificationForm({ ...verificationForm, reference_no: e.target.value })} placeholder="Pvz. 1234" style={styles.input} />
              </label>
              <label style={styles.fieldLabel}>
                <span>Kas išdavė / kur patikrinta</span>
                <input value={verificationForm.issuer} onChange={(e) => setVerificationForm({ ...verificationForm, issuer: e.target.value })} placeholder="Pvz. registras, įstaiga" style={styles.input} />
              </label>
              <label style={styles.fieldLabel}>
                <span>Galioja nuo</span>
                <input type="date" value={verificationForm.valid_from} onChange={(e) => setVerificationForm({ ...verificationForm, valid_from: e.target.value })} style={styles.input} />
              </label>
              <label style={styles.fieldLabel}>
                <span>Galioja iki</span>
                <input type="date" value={verificationForm.valid_until} onChange={(e) => setVerificationForm({ ...verificationForm, valid_until: e.target.value })} style={styles.input} />
              </label>
              <label style={styles.fieldLabel}>
                <span>Kas patikrino</span>
                <input value={verificationForm.verified_by} onChange={(e) => setVerificationForm({ ...verificationForm, verified_by: e.target.value })} placeholder="Pvz. Vardas Pavardė" style={styles.input} />
              </label>
            </div>

            <div style={styles.checkList}>
              <label style={styles.checkbox}>
                <input type="checkbox" checked={verificationForm.seen_confirmed} onChange={(e) => setVerificationForm({ ...verificationForm, seen_confirmed: e.target.checked })} />
                Patvirtinu, kad dokumentas buvo peržiūrėtas fiziškai arba oficialiame registre
              </label>
              <label style={styles.checkbox}>
                <input type="checkbox" checked={verificationForm.no_copy_stored} onChange={(e) => setVerificationForm({ ...verificationForm, no_copy_stored: e.target.checked })} />
                Patvirtinu, kad dokumento kopija sistemoje nesaugoma
              </label>
              <label style={styles.checkbox}>
                <input type="checkbox" checked={verificationForm.minimal_data_confirmed} onChange={(e) => setVerificationForm({ ...verificationForm, minimal_data_confirmed: e.target.checked })} />
                Patvirtinu, kad įrašau tik būtinus duomenis: tipą, galiojimą, patikrinimo faktą ir tikrintoją
              </label>
            </div>

            <input value={verificationForm.note} onChange={(e) => setVerificationForm({ ...verificationForm, note: e.target.value })} placeholder="Pastaba, jei būtina. Nerašyti diagnozių, asmens kodo, teistumo ar kitų perteklinių duomenų." style={styles.input} />

            <button type="button" style={styles.primaryButton} disabled={saving} onClick={() => void addDocumentVerification()}>
              <BadgeCheck size={16} />
              Registruoti patikrinimą
            </button>
          </Card>

          <Card title="Darbuotojų dokumentų reikalavimai">
            <div style={styles.helpBox}>
              <strong>Kam skirtas šis blokas?</strong>
              <span>Čia nustatai taisykles, kokius dokumentus privalo turėti skirtingos pareigybės.</span>
              <span>Pavyzdžiai: visi darbuotojai turi turėti sveikatos pažymą, slaugytojai — profesinę licenciją, virtuvė — higienos pažymėjimą.</span>
              <span>Pagal šias taisykles sistema automatiškai rodo: trūksta, galioja, greitai baigsis arba pasibaigė.</span>
            </div>

            <div style={styles.requirementGrid}>
              <label style={styles.fieldLabel}>
                <span>Taikoma kam</span>
                <select value={requirementForm.role} onChange={(e) => setRequirementForm({ ...requirementForm, role: e.target.value })} style={styles.input}>
                  <option value="VISI">Visi darbuotojai</option>
                  <option value="SLAUGYTOJAI">Slaugytojai</option>
                  <option value="SOCIALINIAI">Socialiniai darbuotojai</option>
                  <option value="MAISTO BLOKAS">Maisto blokas / virtuvė</option>
                  <option value="ADMINISTRACIJA">Administracija</option>
                  <option value="ŪKIS">Ūkio / techniniai darbuotojai</option>
                </select>
              </label>

              <label style={styles.fieldLabel}>
                <span>Dokumentas</span>
                <input value={requirementForm.document_type} onChange={(e) => setRequirementForm({ ...requirementForm, document_type: e.target.value })} placeholder="Pvz. Sveikatos pažyma" style={styles.input} />
              </label>

              <label style={styles.fieldLabel}>
                <span>Galiojimas mėnesiais</span>
                <input type="number" value={requirementForm.validity_months} onChange={(e) => setRequirementForm({ ...requirementForm, validity_months: e.target.value })} placeholder="Pvz. 12" style={styles.input} />
              </label>

              <label style={styles.checkbox}>
                <input type="checkbox" checked={requirementForm.required} onChange={(e) => setRequirementForm({ ...requirementForm, required: e.target.checked })} />
                Privalomas dokumentas
              </label>

              <label style={styles.fieldLabel}>
                <span>Pastaba darbuotojui / administratoriui</span>
                <input value={requirementForm.retention_note} onChange={(e) => setRequirementForm({ ...requirementForm, retention_note: e.target.value })} placeholder="Pvz. kopija nesaugoma, tikrinama kasmet" style={styles.input} />
              </label>

              <button type="button" style={styles.primaryButton} disabled={saving} onClick={() => void addDocumentRequirement()}>
                <Plus size={16} />
                Pridėti reikalavimą
              </button>
            </div>

            <DataTable
              columns={["Taikoma", "Dokumentas", "Privaloma", "Galiojimas", "Kopija", "Pastaba"]}
              rows={documentRequirements.map((item: any) => [
                item.role,
                item.document_type,
                item.required ? "Taip" : "Ne",
                item.validity_months ? `${item.validity_months} mėn.` : "Nenustatyta",
                item.collect_copy_allowed ? "Leidžiama" : "Nesaugoma",
                item.retention_note || "—",
              ])}
              empty="Dokumentų reikalavimų dar nėra."
            />
          </Card>

          <Card title="Automatinė dokumentų atitiktis">
            <div style={styles.miniStats}>
              <div style={styles.miniStatGood}>Galioja: {verificationSummary.filter((x) => x.status === "ok").length}</div>
              <div style={styles.miniStatWarn}>Greitai baigsis: {verificationSummary.filter((x) => x.status === "expiring").length}</div>
              <div style={styles.miniStatBad}>Trūksta / pasibaigė: {verificationSummary.filter((x) => x.status === "missing" || x.status === "expired").length}</div>
            </div>
            <DataTable
              columns={["Darbuotojas", "Dokumentas", "Būsena", "Galioja iki", "Tikrino", "Kopija"]}
              rows={verificationSummary.map((item) => [
                employeeName(item.employee),
                item.document_type,
                <span key={`${item.employee.user_id}-${item.document_type}`} style={item.status === "ok" ? styles.statusGood : item.status === "expiring" ? styles.statusWarn : styles.statusBad}>{verificationStatusLabel(item.status)}</span>,
                fmt(item.valid_until),
                item.verified_by || "—",
                item.no_copy_stored ? "Nesaugoma" : "Rizika",
              ])}
              empty="Atitikties įrašų nėra."
            />
          </Card>

          <Card title="Patikrinimų ir audito registras">
            <DataTable
              columns={["Darbuotojas", "Dokumentas", "Maskuotas nr.", "Galioja iki", "Tikrino", "Kada", "Pastaba"]}
              rows={documentVerifications.map((item) => [
                employeeName(map.get(item.employee_id)),
                item.document_type,
                item.reference_no_masked || "—",
                fmt(item.valid_until),
                item.verified_by,
                fmt(item.verified_at),
                item.note || "—",
              ])}
              empty="Patikrinimų dar nėra."
            />

            <DataTable
              columns={["Laikas", "Vartotojas", "Veiksmai", "Objektas", "Detalės"]}
              rows={auditLog.slice(0, 20).map((item) => [
                fmt(item.created_at),
                item.actor || "—",
                item.action,
                item.entity_type,
                item.details || "—",
              ])}
              empty="Audito įrašų nėra."
            />
          </Card>
        </section>
      ) : null}

      {tab === "inventory" ? (
        <section style={styles.gridTwo}>
          <Card title="Darbuotojams priskiriami daiktai">
            <div style={styles.formGrid}>
              <input value={inventoryForm.name} onChange={(e) => setInventoryForm({ ...inventoryForm, name: e.target.value })} placeholder="Pavadinimas: raktas, kortelė, uniforma" style={styles.input} />
              <input value={inventoryForm.category} onChange={(e) => setInventoryForm({ ...inventoryForm, category: e.target.value })} placeholder="Kategorija" style={styles.input} />
              <input value={inventoryForm.serial_no} onChange={(e) => setInventoryForm({ ...inventoryForm, serial_no: e.target.value })} placeholder="Serija / numeris" style={styles.input} />
              <input value={inventoryForm.size} onChange={(e) => setInventoryForm({ ...inventoryForm, size: e.target.value })} placeholder="Dydis" style={styles.input} />
              <button type="button" style={styles.primaryButton} disabled={saving} onClick={() => void addPersonnelInventoryItem()}>
                <Plus size={16} />
                Pridėti daiktą
              </button>
            </div>

            <DataTable
              columns={["Pavadinimas", "Kategorija", "Serija", "Dydis", "Būsena"]}
              rows={personnelInventory.map((item) => [
                item.name,
                item.category || "—",
                item.serial_no || item.note || "—",
                item.size || "—",
                item.status || (item.employee_id ? "assigned" : "available"),
              ])}
              empty="Daiktų dar nėra."
            />
          </Card>

          <Card title="Priskirti daiktą darbuotojui">
            <div style={styles.formGrid}>
              <EmployeeSelect value={assignmentForm.employee_id} employees={employees} onChange={(value) => setAssignmentForm({ ...assignmentForm, employee_id: value })} />
              <select value={assignmentForm.item_id} onChange={(e) => setAssignmentForm({ ...assignmentForm, item_id: e.target.value })} style={styles.input}>
                <option value="">Pasirinkti daiktą</option>
                {personnelInventory.filter((item) => (item.status || (item.employee_id ? "assigned" : "available")) !== "assigned").map((item) => (
                  <option key={item.id} value={item.id}>{item.name} {item.size || ""}</option>
                ))}
              </select>
              <input value={assignmentForm.condition_out} onChange={(e) => setAssignmentForm({ ...assignmentForm, condition_out: e.target.value })} placeholder="Būklė perduodant" style={styles.input} />
              <input value={assignmentForm.note} onChange={(e) => setAssignmentForm({ ...assignmentForm, note: e.target.value })} placeholder="Pastaba" style={styles.input} />
              <button type="button" style={styles.primaryButton} disabled={saving} onClick={() => void assignPersonnelInventoryItem()}>
                <PackageCheck size={16} />
                Priskirti
              </button>
            </div>

            <DataTable
              columns={["Darbuotojas", "Daiktas", "Nuo", "Būklė", "Pastaba"]}
              rows={personnelAssignments.map((item) => {
                const inv = personnelInventory.find((thing) => thing.id === item.item_id)
                return [
                  employeeName(map.get(item.employee_id)),
                  inv?.name || item.item_id,
                  fmt(item.assigned_at),
                  item.condition_out || "—",
                  item.note || "—",
                ]
              })}
              empty="Priskyrimų dar nėra."
            />
          </Card>
        </section>
      ) : null}

      {tab === "candidates" ? (
        <Card title="Kandidatai">
          <div style={styles.formGrid}>
            <input value={candidateForm.first_name} onChange={(e) => setCandidateForm({ ...candidateForm, first_name: e.target.value })} placeholder="Vardas" style={styles.input} />
            <input value={candidateForm.last_name} onChange={(e) => setCandidateForm({ ...candidateForm, last_name: e.target.value })} placeholder="Pavardė" style={styles.input} />
            <input value={candidateForm.email} onChange={(e) => setCandidateForm({ ...candidateForm, email: e.target.value })} placeholder="El. paštas" style={styles.input} />
            <input value={candidateForm.phone} onChange={(e) => setCandidateForm({ ...candidateForm, phone: e.target.value })} placeholder="Telefonas" style={styles.input} />
            <input value={candidateForm.desired_role} onChange={(e) => setCandidateForm({ ...candidateForm, desired_role: e.target.value })} placeholder="Norimos pareigos" style={styles.input} />
            <input value={candidateForm.experience} onChange={(e) => setCandidateForm({ ...candidateForm, experience: e.target.value })} placeholder="Patirtis" style={styles.input} />
            <label style={styles.checkbox}>
              <input type="checkbox" checked={candidateForm.consent} onChange={(e) => setCandidateForm({ ...candidateForm, consent: e.target.checked })} />
              Kandidatas sutiko dėl duomenų tvarkymo atrankos tikslu
            </label>
            <button type="button" style={styles.primaryButton} disabled={saving} onClick={() => void addCandidate()}>
              <Plus size={16} />
              Pridėti kandidatą
            </button>
          </div>

          <DataTable
            columns={["Kandidatas", "Kontaktai", "Pareigos", "Būsena", "Patirtis"]}
            rows={candidates.map((item) => [
              `${item.first_name} ${item.last_name}`,
              `${item.email || "—"} / ${item.phone || "—"}`,
              item.desired_role || "—",
              item.status || "new",
              item.experience || "—",
            ])}
            empty="Kandidatų dar nėra."
          />
        </Card>
      ) : null}

      {trainingEntryEmployee ? (
        <div style={styles.modalBackdrop}>
          <div style={styles.modal}>
            <div style={styles.modalHeader}>
              <div>
                <h2 style={styles.cardTitle}>Pridėti darbuotojo mokymus</h2>
                <p style={styles.cardMeta}>{employeeName(trainingEntryEmployee)} · mokymai bus išsaugoti darbuotojo kortelėje ir mokymų atitikties bloke</p>
              </div>
              <button type="button" style={styles.iconButton} onClick={() => setTrainingEntryEmployee(null)} aria-label="Uždaryti"><X size={20} /></button>
            </div>
            <div style={styles.notice}>BDAR principas: pažymėjimo kopijos nesaugomos. Fiksuojamas tik mokymų faktas, data, galiojimas ir kas patikrino.</div>
            {message ? <div style={message.toLowerCase().includes("klaid") || message.toLowerCase().includes("nepavyko") || message.toLowerCase().includes("invalid") || message.toLowerCase().includes("violates") || message.toLowerCase().includes("policy") || message.toLowerCase().includes("security") || message.toLowerCase().includes("rls") ? styles.error : styles.message}>{message}</div> : null}
            <div style={styles.formGrid}>
              <label style={styles.fieldLabel}><span>Mokymų pavadinimas</span><input value={trainingForm.title} onChange={(e) => setTrainingForm({ ...trainingForm, employee_id: trainingEntryEmployee.user_id, title: e.target.value })} placeholder="Pvz. Darbų sauga" style={styles.input} /></label>
              <label style={styles.fieldLabel}><span>Teikėjas</span><input value={trainingForm.provider} onChange={(e) => setTrainingForm({ ...trainingForm, employee_id: trainingEntryEmployee.user_id, provider: e.target.value })} placeholder="Kas organizavo mokymus" style={styles.input} /></label>
              <label style={styles.fieldLabel}><span>Valandos</span><input type="number" value={trainingForm.hours} onChange={(e) => setTrainingForm({ ...trainingForm, employee_id: trainingEntryEmployee.user_id, hours: e.target.value })} placeholder="Valandos" style={styles.input} /></label>
              <label style={styles.fieldLabel}><span>Baigta</span><input type="date" value={trainingForm.completed_at} onChange={(e) => { const selected = effectiveTrainingCatalog.find((item) => item.id === trainingForm.training_id); setTrainingForm({ ...trainingForm, employee_id: trainingEntryEmployee.user_id, completed_at: e.target.value, expires_at: selected?.valid_for_months ? calculateTrainingExpiry(e.target.value, selected.valid_for_months) : trainingForm.expires_at }) }} style={styles.input} /></label>
              <label style={styles.fieldLabel}><span>Galioja iki</span><input type="date" value={trainingForm.expires_at} onChange={(e) => setTrainingForm({ ...trainingForm, employee_id: trainingEntryEmployee.user_id, expires_at: e.target.value })} style={styles.input} /></label>
              <label style={styles.fieldLabel}><span>Patikrino</span><input value={trainingForm.verified_by} onChange={(e) => setTrainingForm({ ...trainingForm, employee_id: trainingEntryEmployee.user_id, verified_by: e.target.value })} placeholder="Kas patikrino" style={styles.input} /></label>
              <label style={styles.fieldLabel}><span>Pažymėjimo nr. / neprivaloma</span><input value={trainingForm.certificate_no} onChange={(e) => setTrainingForm({ ...trainingForm, employee_id: trainingEntryEmployee.user_id, certificate_no: e.target.value })} placeholder="Pažymėjimo nr. / neprivaloma" style={styles.input} /></label>
            </div>
            <div style={styles.modalActions}>
              <button type="button" style={styles.secondaryButton} onClick={() => setTrainingEntryEmployee(null)}>Atšaukti</button>
              <button type="button" style={styles.primaryButton} disabled={saving} onClick={async () => { const saved = await addTraining(trainingEntryEmployee.user_id); if (saved) setTrainingEntryEmployee(null) }}><Plus size={16} />{saving ? "Saugoma..." : "Išsaugoti mokymus"}</button>
            </div>
          </div>
        </div>
      ) : null}

      {selectedTrainingDetails ? (
        <div style={styles.modalBackdrop}>
          <div style={styles.modal}>
            <div style={styles.modalHeader}>
              <div>
                <h2 style={styles.cardTitle}>Mokymų informacija</h2>
                <p style={styles.cardMeta}>{employeeName(selectedTrainingDetails.employee)} · visa mokymų atitikties informacija</p>
              </div>
              <button type="button" style={styles.iconButton} onClick={() => setTrainingDetailsEmployeeId(null)} aria-label="Uždaryti">
                <X size={20} />
              </button>
            </div>

            <DataTable
              columns={["Mokymas", "Būsena", "Baigta", "Galioja iki", "Val.", "Patikrino"]}
              rows={selectedTrainingDetails.rows.map((row) => [
                row.training.name,
                <span key={`${row.employee.user_id}-${row.training.id}-modal`} style={trainingStatusStyle(row.status)}>{trainingStatusLabel(row.status)}</span>,
                fmt(row.completed_at),
                fmt(row.expires_at),
                row.hours,
                row.verified_by || "—",
              ])}
              empty="Mokymų informacijos nėra."
            />
          </div>
        </div>
      ) : null}

      {editingEmployee ? (
        <div style={styles.modalBackdrop}>
          <div style={styles.modal}>
            <div style={styles.modalHeader}>
              <div>
                <h2 style={styles.cardTitle}>Redaguoti darbuotoją</h2>
                <p style={styles.cardMeta}>{employeeName(editingEmployee)} · keičiami tik būtini personalo duomenys</p>
              </div>
              <button type="button" style={styles.iconButton} onClick={() => setEditingEmployee(null)}>
                <X size={18} />
              </button>
            </div>

            <div style={styles.notice}>
              Ši forma skirta darbuotojo pareigoms, skyriui ir galiojimų terminams tvarkyti. Pažymėjimų kopijų čia nekeliame — saugome tik faktą, numerį / galiojimą ir kas užregistravo.
            </div>

            <div style={styles.modalSection}>
              <h3 style={styles.sectionTitle}>1. Darbuotojo duomenys</h3>
              <div style={styles.modalGrid}>
                <label style={styles.fieldLabel}>
                  <span>Vardas</span>
                  <input style={styles.input} value={editForm.first_name} onChange={(e) => setEditForm({ ...editForm, first_name: e.target.value })} placeholder="Vardas" />
                </label>

                <label style={styles.fieldLabel}>
                  <span>Pavardė</span>
                  <input style={styles.input} value={editForm.last_name} onChange={(e) => setEditForm({ ...editForm, last_name: e.target.value })} placeholder="Pavardė" />
                </label>

                <label style={styles.fieldLabel}>
                  <span>Rodomas vardas sistemoje</span>
                  <input style={styles.input} value={editForm.full_name} onChange={(e) => setEditForm({ ...editForm, full_name: e.target.value })} placeholder="Vardenė Pavardenė" />
                </label>

                <label style={styles.fieldLabel}>
                  <span>El. paštas</span>
                  <input style={{ ...styles.input, background: "#f8fafc", color: "#64748b" }} value={editForm.email} placeholder="vardas@imone.lt" disabled />
                </label>

                <label style={styles.fieldLabel}>
                  <span>Pareigos</span>
                  <input style={styles.input} value={editForm.position} onChange={(e) => setEditForm({ ...editForm, position: e.target.value })} placeholder="Pvz. slaugytoja, socialinė darbuotoja" />
                </label>

                <label style={styles.fieldLabel}>
                  <span>Skyrius</span>
                  <input style={styles.input} value={editForm.department} onChange={(e) => setEditForm({ ...editForm, department: e.target.value })} placeholder="Pvz. Slauga, Administracija, Virtuvė" />
                </label>
              </div>
            </div>

            <div style={styles.modalSection}>
              <h3 style={styles.sectionTitle}>2. Licencija ir sveikatos pažyma</h3>
              <div style={styles.modalGrid}>
                <label style={styles.fieldLabel}>
                  <span>Profesinės licencijos numeris</span>
                  <input style={styles.input} value={editForm.professional_license_number} onChange={(e) => setEditForm({ ...editForm, professional_license_number: e.target.value })} placeholder="Pvz. SPL-1234" />
                </label>

                <label style={styles.fieldLabel}>
                  <span>Licencija galioja iki</span>
                  <input type="date" style={styles.input} value={editForm.professional_license_valid_until} onChange={(e) => setEditForm({ ...editForm, professional_license_valid_until: e.target.value })} />
                </label>

                <label style={styles.fieldLabel}>
                  <span>Sveikatos pažyma galioja iki</span>
                  <input type="date" style={styles.input} value={editForm.occupational_health_valid_until} onChange={(e) => setEditForm({ ...editForm, occupational_health_valid_until: e.target.value })} />
                </label>
              </div>
            </div>

            <div style={styles.modalSection}>
              <h3 style={styles.sectionTitle}>3. Mokymų atitiktis</h3>
              <p style={styles.sectionHint}>Čia matysi, kiek mokymų darbuotojui trūksta, kas jau galioja ir ką galima iškart papildyti tame pačiame lange.</p>
              <DataTable
                columns={["Mokymas", "Būsena", "Baigta", "Galioja iki", "Val.", "Patikrino", "Veiksmai"]}
                rows={(editingEmployeeTrainingDetails?.rows || []).map((row) => [
                  row.training.name,
                  <span key={`${row.employee.user_id}-${row.training.id}-editor-status`} style={trainingStatusStyle(row.status)}>{trainingStatusLabel(row.status)}</span>,
                  fmt(row.completed_at),
                  fmt(row.expires_at),
                  row.hours,
                  row.verified_by || "—",
                  <div key={`${row.employee.user_id}-${row.training.id}-editor-actions`} style={styles.rowActions}>
                    <button type="button" style={styles.smallAction} onClick={() => openTrainingEntry(editingEmployee, row, { openModal: false })}>
                      Užpildyti žemiau
                    </button>
                  </div>,
                ])}
                empty="Mokymų informacijos nėra."
              />
            </div>

            <div style={styles.modalSection}>
              <h3 style={styles.sectionTitle}>4. Greitai pridėti mokymus</h3>
              <p style={styles.sectionHint}>Pilnas mokymų valdymas yra skiltyje „Mokymai“. Čia galima greitai pridėti mokymus konkrečiam darbuotojui.</p>
              {message ? <div style={message.toLowerCase().includes("klaid") || message.toLowerCase().includes("nepavyko") || message.toLowerCase().includes("invalid") || message.toLowerCase().includes("violates") || message.toLowerCase().includes("policy") || message.toLowerCase().includes("security") || message.toLowerCase().includes("rls") ? styles.error : styles.message}>{message}</div> : null}

              <div style={styles.formGrid}>
                <label style={styles.fieldLabel}>
                  <span>Mokymų pavadinimas</span>
                  <input value={trainingForm.title} onChange={(e) => setTrainingForm({ ...trainingForm, employee_id: editingEmployee.user_id, title: e.target.value })} placeholder="Pvz. Darbų sauga" style={styles.input} />
                </label>

                <label style={styles.fieldLabel}>
                  <span>Teikėjas</span>
                  <input value={trainingForm.provider} onChange={(e) => setTrainingForm({ ...trainingForm, employee_id: editingEmployee.user_id, provider: e.target.value })} placeholder="Kas organizavo mokymus" style={styles.input} />
                </label>

                <label style={styles.fieldLabel}>
                  <span>Valandos</span>
                  <input type="number" min="1" value={trainingForm.hours} onChange={(e) => setTrainingForm({ ...trainingForm, employee_id: editingEmployee.user_id, hours: e.target.value })} placeholder="Pvz. 8" style={styles.input} />
                </label>

                <label style={styles.fieldLabel}>
                  <span>Baigta</span>
                  <input type="date" value={trainingForm.completed_at} onChange={(e) => setTrainingForm({ ...trainingForm, employee_id: editingEmployee.user_id, completed_at: e.target.value })} style={styles.input} />
                </label>

                <label style={styles.fieldLabel}>
                  <span>Galioja iki</span>
                  <input type="date" value={trainingForm.expires_at} onChange={(e) => setTrainingForm({ ...trainingForm, employee_id: editingEmployee.user_id, expires_at: e.target.value })} style={styles.input} />
                </label>

                <label style={styles.fieldLabel}>
                  <span>Patikrino</span>
                  <input value={trainingForm.verified_by} onChange={(e) => setTrainingForm({ ...trainingForm, employee_id: editingEmployee.user_id, verified_by: e.target.value })} placeholder="Kas patikrino" style={styles.input} />
                </label>

                <button type="button" style={styles.primaryButton} onClick={() => void addTraining(editingEmployee.user_id)} disabled={saving}>
                  <Plus size={16} />
                  {saving ? "Saugoma..." : "Išsaugoti mokymus"}
                </button>
              </div>
            </div>

            <div style={styles.modalActions}>
              <button type="button" style={styles.secondaryButton} onClick={() => setEditingEmployee(null)}>
                Atšaukti
              </button>
              <button type="button" style={styles.primaryButton} onClick={() => void saveEmployeeEditor()} disabled={saving}>
                Išsaugoti darbuotoją
              </button>
            </div>
          </div>
        </div>
      ) : null}

    </main>
  )
}

function DocumentStatusPill({ status }: { status: "valid" | "expiring" | "expired" | "missing" }) {
  const style = status === "valid" ? styles.statusGood : status === "expiring" ? styles.statusWarn : status === "expired" ? styles.statusBad : styles.statusMuted
  return <span style={style}>{documentStatusText(status)}</span>
}

function ScheduleStatusPill({ status }: { status?: string | null }) {
  const normalized = String(status || "").toUpperCase()
  const label = scheduleStatusLabel(status)
  const style = normalized === "WORK" ? styles.statusGood : normalized === "VACATION" || normalized === "SICK" || normalized === "ABSENCE" ? styles.statusWarn : styles.statusMuted
  return <span style={style}>{label}</span>
}

function EmployeeSelect({
  value,
  employees,
  onChange,
}: {
  value: string
  employees: Employee[]
  onChange: (value: string) => void
}) {
  return (
    <select value={value} onChange={(event) => onChange(event.target.value)} style={styles.input}>
      <option value="">Pasirinkti darbuotoją</option>
      {employees.map((employee) => (
        <option key={employee.user_id} value={employee.user_id}>
          {employeeName(employee)} — {employeeRole(employee)}
        </option>
      ))}
    </select>
  )
}

function Stat({
  title,
  value,
  icon: Icon,
  danger,
  onClick,
}: {
  title: string
  value: number
  icon: any
  danger?: boolean
  onClick?: () => void
}) {
  const content = (
    <>
      <div style={styles.statIcon}>
        <Icon size={20} />
      </div>
      <div>
        <div style={styles.statValue}>{value}</div>
        <div style={styles.statTitle}>{title}</div>
      </div>
    </>
  )

  if (onClick) {
    return (
      <button type="button" style={danger ? styles.statDangerButton : styles.statButton} onClick={onClick}>
        {content}
      </button>
    )
  }

  return <article style={danger ? styles.statDanger : styles.stat}>{content}</article>
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section style={styles.card}>
      <h2 style={styles.cardTitle}>{title}</h2>
      {children}
    </section>
  )
}

function DataTable({
  columns,
  rows,
  empty,
}: {
  columns: string[]
  rows: Array<Array<React.ReactNode>>
  empty: string
}) {
  if (!rows.length) return <div style={styles.empty}>{empty}</div>

  return (
    <div style={styles.tableWrap}>
      <table style={styles.table}>
        <thead>
          <tr>
            {columns.map((column) => (
              <th key={column} style={styles.th}>
                {column}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, index) => (
            <tr key={index}>
              {row.map((cell, cellIndex) => (
                <td key={cellIndex} style={styles.td}>
                  {cell}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

const styles: Record<string, React.CSSProperties> = {
  page: { minHeight: "100vh", background: "#f8fafc", padding: 22, color: "#0f172a", display: "grid", gap: 16 },
  hero: { background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: 24, padding: 24, display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 18, boxShadow: "0 16px 36px rgba(15,23,42,.06)" },
  kicker: { display: "inline-flex", alignItems: "center", gap: 8, color: "#047857", fontSize: 12, fontWeight: 950, textTransform: "uppercase", letterSpacing: ".06em" },
  title: { margin: "6px 0 0", fontSize: 42, fontWeight: 950, letterSpacing: "-.04em" },
  subtitle: { margin: "8px 0 0", color: "#64748b", fontSize: 15, fontWeight: 700, maxWidth: 900 },
  message: { background: "#ecfdf5", color: "#047857", border: "1px solid #a7f3d0", borderRadius: 16, padding: 12, fontWeight: 850 },
  error: { background: "#fef2f2", color: "#b91c1c", border: "1px solid #fecaca", borderRadius: 16, padding: 12, fontWeight: 850 },
  statsGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(190px, 1fr))", gap: 12 },
  stat: { background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: 20, padding: 16, display: "flex", gap: 12, alignItems: "center", boxShadow: "0 8px 22px rgba(15,23,42,.045)" },
  statDanger: { background: "#fff7ed", border: "1px solid #fed7aa", borderRadius: 20, padding: 16, display: "flex", gap: 12, alignItems: "center", boxShadow: "0 8px 22px rgba(15,23,42,.045)" },
  statButton: { background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: 20, padding: 16, display: "flex", gap: 12, alignItems: "center", boxShadow: "0 8px 22px rgba(15,23,42,.045)", cursor: "pointer", textAlign: "left", transition: "transform .15s ease, box-shadow .15s ease" },
  statDangerButton: { background: "#fff7ed", border: "1px solid #fed7aa", borderRadius: 20, padding: 16, display: "flex", gap: 12, alignItems: "center", boxShadow: "0 8px 22px rgba(15,23,42,.045)", cursor: "pointer", textAlign: "left", transition: "transform .15s ease, box-shadow .15s ease" },
  statIcon: { width: 42, height: 42, borderRadius: 14, background: "#ecfdf5", color: "#047857", display: "flex", alignItems: "center", justifyContent: "center" },
  statValue: { fontSize: 26, fontWeight: 950 },
  statTitle: { color: "#64748b", fontSize: 13, fontWeight: 800 },
  tabs: { background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: 20, padding: 8, display: "flex", flexWrap: "wrap", gap: 8 },
  tab: { border: "none", background: "transparent", color: "#64748b", borderRadius: 14, padding: "10px 13px", display: "inline-flex", gap: 8, alignItems: "center", fontWeight: 900, cursor: "pointer" },
  tabActive: { border: "none", background: "#047857", color: "#ffffff", borderRadius: 14, padding: "10px 13px", display: "inline-flex", gap: 8, alignItems: "center", fontWeight: 950, cursor: "pointer" },
  gridTwo: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(420px, 1fr))", gap: 16 },
  card: { background: "#ffffff", border: "1px solid #e2e8f0", borderRadius: 24, padding: 18, display: "grid", gap: 14, boxShadow: "0 14px 32px rgba(15,23,42,.055)" },
  cardTitle: { margin: 0, fontSize: 20, fontWeight: 950 },
  formGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(190px, 1fr))", gap: 10, alignItems: "center" },
  input: { width: "100%", height: 46, border: "1px solid #cbd5e1", borderRadius: 14, padding: "0 12px", fontSize: 14, boxSizing: "border-box" },
  primaryButton: { border: "none", background: "#047857", color: "#ffffff", borderRadius: 14, height: 46, padding: "0 14px", display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 8, fontWeight: 950, cursor: "pointer" },
  secondaryButton: { border: "1px solid #cbd5e1", background: "#ffffff", color: "#0f172a", borderRadius: 14, height: 44, padding: "0 14px", display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 8, fontWeight: 900, cursor: "pointer" },
  rowActions: { display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" },
  smallActionSecondary: { border: "1px solid #cbd5e1", background: "#ffffff", color: "#0f172a", borderRadius: 12, padding: "8px 10px", fontWeight: 900, cursor: "pointer" },
  smallAction: { border: "none", background: "#047857", color: "#ffffff", borderRadius: 12, padding: "8px 10px", fontWeight: 900, cursor: "pointer" },
  searchBox: { height: 46, border: "1px solid #cbd5e1", borderRadius: 14, padding: "0 12px", display: "flex", alignItems: "center", gap: 8 },
  searchInput: { border: "none", outline: "none", flex: 1, fontSize: 14 },
  employeeGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 12 },
  employeeCard: { border: "1px solid #e2e8f0", borderRadius: 18, padding: 14, display: "grid", gridTemplateColumns: "46px 1fr auto", gap: 12, alignItems: "center", background: "#ffffff" },
  avatar: { width: 46, height: 46, borderRadius: 16, background: "#ecfdf5", color: "#047857", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 950 },
  cardName: { margin: 0, fontSize: 16, fontWeight: 950 },
  cardMeta: { margin: "3px 0 0", color: "#64748b", fontSize: 13, fontWeight: 750 },
  badge: { background: "#ecfdf5", color: "#047857", borderRadius: 999, padding: "5px 9px", fontSize: 12, fontWeight: 900 },

  requirementGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(210px, 1fr))", gap: 10, alignItems: "end" },
  miniStats: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 10 },
  miniStatGood: { background: "#dcfce7", color: "#166534", border: "1px solid #86efac", borderRadius: 14, padding: 12, fontWeight: 950 },
  miniStatWarn: { background: "#fef3c7", color: "#92400e", border: "1px solid #fde68a", borderRadius: 14, padding: 12, fontWeight: 950 },
  miniStatBad: { background: "#fee2e2", color: "#991b1b", border: "1px solid #fecaca", borderRadius: 14, padding: 12, fontWeight: 950 },
  fieldLabel: { display: "grid", gap: 6, color: "#475569", fontSize: 12, fontWeight: 900 },
  helpBox: { background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: 16, padding: 12, display: "grid", gap: 6, color: "#334155", fontSize: 13, fontWeight: 750, lineHeight: 1.45 },
  notice: { background: "#eff6ff", color: "#1e40af", border: "1px solid #bfdbfe", borderRadius: 16, padding: 12, fontWeight: 800, lineHeight: 1.45 },
  checkList: { display: "grid", gap: 8, background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: 16, padding: 12 },
  statusGood: { background: "#dcfce7", color: "#166534", borderRadius: 999, padding: "5px 9px", fontSize: 12, fontWeight: 900, display: "inline-block" },
  statusWarn: { background: "#fef3c7", color: "#92400e", borderRadius: 999, padding: "5px 9px", fontSize: 12, fontWeight: 900, display: "inline-block" },
  statusBad: { background: "#fee2e2", color: "#b91c1c", borderRadius: 999, padding: "5px 9px", fontSize: 12, fontWeight: 900, display: "inline-block" },
  checkbox: { display: "flex", gap: 8, alignItems: "center", color: "#334155", fontSize: 13, fontWeight: 800 },
  docsCenter: { display: "grid", gap: 16 },
  complianceHero: { border: "1px solid #dbeafe", background: "linear-gradient(135deg, #eff6ff, #ffffff)", borderRadius: 20, padding: 18, display: "flex", justifyContent: "space-between", gap: 16, alignItems: "center", flexWrap: "wrap" },
  complianceScore: { margin: "4px 0", fontSize: 44, fontWeight: 950, letterSpacing: "-.04em", color: "#047857" },
  complianceBadges: { display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "flex-end" },
  filterPill: { border: "1px solid #cbd5e1", background: "#ffffff", color: "#334155", borderRadius: 999, padding: "9px 11px", fontSize: 12, fontWeight: 950, cursor: "pointer" },
  filterPillActive: { border: "1px solid #047857", background: "#047857", color: "#ffffff", borderRadius: 999, padding: "9px 11px", fontSize: 12, fontWeight: 950, cursor: "pointer" },
  filterPillActiveWarn: { border: "1px solid #f59e0b", background: "#fef3c7", color: "#92400e", borderRadius: 999, padding: "9px 11px", fontSize: 12, fontWeight: 950, cursor: "pointer" },
  filterPillActiveBad: { border: "1px solid #ef4444", background: "#fee2e2", color: "#991b1b", borderRadius: 999, padding: "9px 11px", fontSize: 12, fontWeight: 950, cursor: "pointer" },
  filterPillActiveMuted: { border: "1px solid #94a3b8", background: "#f1f5f9", color: "#334155", borderRadius: 999, padding: "9px 11px", fontSize: 12, fontWeight: 950, cursor: "pointer" },
  warningBar: { background: "#fff7ed", border: "1px solid #fed7aa", color: "#9a3412", borderRadius: 16, padding: 12, display: "flex", gap: 10, alignItems: "center", fontWeight: 850, lineHeight: 1.4 },
  successBar: { background: "#ecfdf5", border: "1px solid #a7f3d0", color: "#047857", borderRadius: 16, padding: 12, display: "flex", gap: 10, alignItems: "center", fontWeight: 850, lineHeight: 1.4 },
  docsLayout: { display: "grid", gridTemplateColumns: "minmax(320px, .85fr) minmax(480px, 1.45fr)", gap: 16, alignItems: "start" },
  docsFormCard: { border: "1px solid #e2e8f0", background: "#f8fafc", borderRadius: 20, padding: 16, display: "grid", gap: 12, position: "sticky", top: 12 },
  docsListCard: { border: "1px solid #e2e8f0", background: "#ffffff", borderRadius: 20, padding: 16, display: "grid", gap: 12 },
  docsFormGrid: { display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 10 },
  stickySaveRow: { position: "sticky", bottom: 0, background: "linear-gradient(180deg, rgba(248,250,252,.65), #f8fafc)", paddingTop: 8, display: "flex", justifyContent: "flex-end" },
  listHeader: { display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center", flexWrap: "wrap" },
  statusMuted: { background: "#f1f5f9", color: "#475569", borderRadius: 999, padding: "5px 9px", fontSize: 12, fontWeight: 900, display: "inline-block" },
  approvalImpact: { display: "grid", gap: 6, alignItems: "start", minWidth: 180 },
  impactText: { color: "#334155", fontSize: 12, fontWeight: 800 },
  impactWarning: { color: "#b45309", background: "#fffbeb", border: "1px solid #fde68a", borderRadius: 10, padding: "4px 8px", fontSize: 11, fontWeight: 800 },
  overviewStack: { display: "grid", gap: 16 },
  overviewHero: { border: "1px solid #dbeafe", background: "linear-gradient(135deg, #eff6ff, #ffffff)", borderRadius: 24, padding: 18, display: "flex", justifyContent: "space-between", gap: 16, alignItems: "center", flexWrap: "wrap" },
  overviewTitle: { margin: "4px 0", fontSize: 26, fontWeight: 950, letterSpacing: "-.03em" },
  overviewText: { margin: 0, color: "#64748b", fontSize: 14, fontWeight: 750, lineHeight: 1.45, maxWidth: 760 },
  overviewScore: { minWidth: 170, border: "1px solid #bbf7d0", background: "#ecfdf5", color: "#047857", borderRadius: 20, padding: 16, display: "grid", justifyItems: "center" },
  overviewScoreValue: { fontSize: 38, fontWeight: 950, lineHeight: 1 },
  overviewScoreLabel: { fontSize: 12, fontWeight: 900, color: "#047857" },
  attentionGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 12 },
  attentionBad: { border: "1px solid #fecaca", background: "#fef2f2", color: "#991b1b", borderRadius: 18, padding: 14, display: "grid", gap: 5, textAlign: "left", cursor: "pointer" },
  attentionWarn: { border: "1px solid #fed7aa", background: "#fff7ed", color: "#9a3412", borderRadius: 18, padding: 14, display: "grid", gap: 5, textAlign: "left", cursor: "pointer" },
  attentionGood: { border: "1px solid #a7f3d0", background: "#ecfdf5", color: "#047857", borderRadius: 18, padding: 14, display: "grid", gap: 5, textAlign: "left", cursor: "pointer" },
  attentionMuted: { border: "1px solid #e2e8f0", background: "#f8fafc", color: "#334155", borderRadius: 18, padding: 14, display: "grid", gap: 5, textAlign: "left", cursor: "pointer" },
  attentionTitle: { fontSize: 12, fontWeight: 950, textTransform: "uppercase", letterSpacing: ".05em", opacity: .8 },
  attentionValue: { fontSize: 15, fontWeight: 950, lineHeight: 1.35 },
  attentionAction: { fontSize: 12, fontWeight: 950, opacity: .9 },
  miniStatBadButton: { background: "#fee2e2", color: "#991b1b", border: "1px solid #fecaca", borderRadius: 14, padding: 12, fontWeight: 950, cursor: "pointer", textAlign: "left" },
  miniStatWarnButton: { background: "#fef3c7", color: "#92400e", border: "1px solid #fde68a", borderRadius: 14, padding: 12, fontWeight: 950, cursor: "pointer", textAlign: "left" },
  miniStatMutedButton: { background: "#f1f5f9", color: "#334155", border: "1px solid #cbd5e1", borderRadius: 14, padding: 12, fontWeight: 950, cursor: "pointer", textAlign: "left" },
  tableWrap: { overflowX: "auto", border: "1px solid #e2e8f0", borderRadius: 16 },
  table: { width: "100%", borderCollapse: "collapse", fontSize: 13 },
  th: { background: "#f8fafc", textAlign: "left", padding: 11, color: "#475569", borderBottom: "1px solid #e2e8f0", whiteSpace: "nowrap" },
  td: { padding: 11, borderBottom: "1px solid #f1f5f9", color: "#0f172a", verticalAlign: "top" },

  cardActions: { display: "grid", gap: 8, justifyItems: "end" },
  iconButton: { width: 36, height: 36, border: "1px solid #cbd5e1", background: "#ffffff", borderRadius: 12, display: "inline-flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: "#0f172a" },
  modalBackdrop: { position: "fixed", inset: 0, background: "rgba(15,23,42,.55)", display: "flex", alignItems: "center", justifyContent: "center", padding: 18, zIndex: 80 },
  modal: { width: "100%", maxWidth: 1100, maxHeight: "92vh", overflowY: "auto", background: "#ffffff", borderRadius: 24, padding: 20, display: "grid", gap: 14, boxShadow: "0 25px 70px rgba(15,23,42,.25)" },
  modalHeader: { display: "flex", justifyContent: "space-between", gap: 12, alignItems: "flex-start" },
  modalGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(210px, 1fr))", gap: 10 },
  sectionTitle: { margin: 0, fontSize: 18, fontWeight: 950, color: "#0f172a" },
  sectionHint: { margin: "-4px 0 0", color: "#64748b", fontSize: 13, fontWeight: 750, lineHeight: 1.45 },
  modalSection: { border: "1px solid #e2e8f0", background: "#f8fafc", borderRadius: 18, padding: 14, display: "grid", gap: 12 },
  modalActions: { display: "flex", justifyContent: "flex-end", gap: 10 },
  scheduleToolbar: { display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" },
  monthPill: { height: 44, border: "1px solid #e2e8f0", background: "#f8fafc", borderRadius: 14, padding: "0 16px", display: "inline-flex", alignItems: "center", fontWeight: 950, textTransform: "capitalize" },
  scheduleLegend: { display: "flex", gap: 8, flexWrap: "wrap", color: "#64748b", fontSize: 12, fontWeight: 850 },
  excelWrap: { border: "1px solid #e2e8f0", borderRadius: 18, overflow: "hidden" },
  empty: { border: "1px dashed #cbd5e1", borderRadius: 18, padding: 22, textAlign: "center", color: "#64748b", background: "#f8fafc" },
}
