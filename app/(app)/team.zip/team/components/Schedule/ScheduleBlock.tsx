"use client";

import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import {
  AlertTriangle,
  CalendarDays,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Clock,
  Download,
  ShieldAlert,
  Users,
  Undo2,
  Redo2,
  History,
  Send,
  Lock,
  Sparkles,
} from "lucide-react";

type ScheduleEntry = {
  id?: string;
  employee_id: string;
  date: string;
  start_datetime?: string | null;
  end_datetime?: string | null;
  status?: string | null;
  note?: string | null;
};

type Employee = {
  user_id: string;
  email?: string | null;
  first_name?: string | null;
  last_name?: string | null;
  full_name?: string | null;
  role?: string | null;
  legacy_role?: string | null;
  position?: string | null;
  department?: string | null;
  staff_type?: string | null;
};

type ComplianceRow = {
  employee: Employee;
  plannedHours: number;
  maxSevenDayHours: number;
  maxSevenDayWorkDays: number;
  shortestRestHours: number | null;
  minWeeklyRestHours?: number | null;
  averageWeeklyHours?: number;
  status: string;
  errors?: string[];
  warnings: string[];
};

type VacationReservation = {
  employee_id: string;
  date: string;
  type: string;
  code: string;
  label: string;
  note: string | null;
  status: string;
};

type GridChange = [number, number, string, string];

type ChangeHistoryItem = { id: string; label: string; at: string; changes: GridChange[] };

type Props = {
  employees: Employee[];
  schedule: ScheduleEntry[];
  scheduleMonth: Date;
  setScheduleMonth: (updater: Date | ((prev: Date) => Date)) => void;
  scheduleDays: Date[];
  scheduleGridData: unknown[][];
  scheduleComplianceRows: ComplianceRow[];
  scheduleWarningRows: ComplianceRow[];
  vacationReservations?: VacationReservation[];
  saving: boolean;
  addMonths: (date: Date, amount: number) => Date;
  monthLabel: (date: Date) => string;
  toDateInput: (date: Date) => string;
  employeeName: (employee?: Employee | null) => string;
  employeeRole: (employee?: Employee | null) => string;
  onSaveGridChanges: (changes: unknown[]) => Promise<void> | void;
};

type ParsedShift = {
  display: string;
  compact: string;
  startLabel: string;
  endLabel: string;
  detail: string;
  hours: number | null;
  kind: "empty" | "work" | "night" | "off" | "vacation" | "sick" | "unknown";
  normalized: string;
};

function normalizeCell(value: string) {
  return String(value || "").trim().toUpperCase();
}

function pad2(value: number) {
  return String(value).padStart(2, "0");
}

function formatHours(hours: number) {
  return hours.toFixed(hours % 1 === 0 ? 0 : 1);
}

function formatDay(date: Date) {
  return new Intl.DateTimeFormat("lt-LT", { weekday: "short" }).format(date);
}

function isCritical(row: ComplianceRow) {
  return Boolean(row.errors?.length || row.status === "Kritinė klaida");
}

function parseShiftValue(value: string): ParsedShift {
  const raw = String(value || "").trim();
  const normalizedStatus = normalizeCell(raw);

  if (!raw) {
    return {
      display: "",
      compact: "",
      startLabel: "",
      endLabel: "",
      detail: "Tuščia",
      hours: null,
      kind: "empty",
      normalized: "",
    };
  }

  if (["P", "POILSIS"].includes(normalizedStatus)) {
    return {
      display: "P",
      compact: "P",
      startLabel: "P",
      endLabel: "",
      detail: "Poilsis",
      hours: null,
      kind: "off",
      normalized: "P",
    };
  }

  if (["A", "ATOSTOGOS"].includes(normalizedStatus)) {
    return {
      display: "A",
      compact: "A",
      startLabel: "A",
      endLabel: "",
      detail: "Atostogos",
      hours: null,
      kind: "vacation",
      normalized: "A",
    };
  }

  if (["L", "LIGA"].includes(normalizedStatus)) {
    return {
      display: "L",
      compact: "L",
      startLabel: "L",
      endLabel: "",
      detail: "Liga",
      hours: null,
      kind: "sick",
      normalized: "L",
    };
  }

  const absenceLabels: Record<string, string> = {
    MD: "Mamadienis",
    TD: "Tėvadienis",
    NA: "Nemokamos atostogos",
    K: "Komandiruotė / mokymai",
    KT: "Kita neatvykimo priežastis",
  };

  if (absenceLabels[normalizedStatus]) {
    return {
      display: normalizedStatus,
      compact: normalizedStatus,
      startLabel: normalizedStatus,
      endLabel: "",
      detail: absenceLabels[normalizedStatus],
      hours: null,
      kind: "vacation",
      normalized: normalizedStatus,
    };
  }

  const match = raw.match(
    /^(\d{1,2})(?::?(\d{2}))?\s*[-–]\s*(\d{1,2})(?::?(\d{2}))?$/,
  );

  if (!match) {
    return {
      display: raw,
      compact: raw,
      startLabel: raw,
      endLabel: "",
      detail: raw,
      hours: null,
      kind: "unknown",
      normalized: raw,
    };
  }

  const sh = Number(match[1]);
  const sm = Number(match[2] || "00");
  const eh = Number(match[3]);
  const em = Number(match[4] || "00");

  // 24:00 leidžiama tik kaip pabaigos laikas.
  if (sh > 23 || eh > 24 || sm > 59 || em > 59 || (eh === 24 && em !== 0)) {
    return {
      display: raw,
      compact: raw,
      startLabel: raw,
      endLabel: "",
      detail: raw,
      hours: null,
      kind: "unknown",
      normalized: raw,
    };
  }

  const startMinutes = sh * 60 + sm;
  const endMinutes = (eh === 24 ? 24 * 60 : eh * 60) + em;
  let minutes = endMinutes - startMinutes;
  if (minutes <= 0) minutes += 24 * 60;

  const start = `${pad2(sh)}:${pad2(sm)}`;
  const end = eh === 24 ? "24:00" : `${pad2(eh)}:${pad2(em)}`;
  const hours = minutes / 60;
  const crossesMidnight = endMinutes <= startMinutes && end !== "24:00";
  const night = crossesMidnight || sh >= 20 || eh <= 6 || eh === 24;

  return {
    display: `${start}-${end}`,
    compact: `${start}-${end}`,
    startLabel: start,
    endLabel: end,
    detail: `${start}-${end} · ${formatHours(hours)} val.`,
    hours,
    kind: night ? "night" : "work",
    normalized: `${start}-${end}`,
  };
}

function cellClass(parsed: ParsedShift) {
  const classes = ["schedule-shift", `schedule-shift-${parsed.kind}`];
  if (parsed.hours !== null && parsed.hours > 12) classes.push("schedule-shift-danger");
  else if (parsed.hours !== null && parsed.hours > 10) classes.push("schedule-shift-long");
  return classes.join(" ");
}

export default function ScheduleBlock({
  employees,
  scheduleMonth,
  setScheduleMonth,
  scheduleDays,
  scheduleGridData,
  scheduleComplianceRows,
  vacationReservations = [],
  saving,
  addMonths,
  monthLabel,
  toDateInput,
  employeeName,
  employeeRole,
  onSaveGridChanges,
}: Props) {
  const [localSaving, setLocalSaving] = useState(false);
  const [savedMessage, setSavedMessage] = useState("");
  const [activeCell, setActiveCell] = useState<{
    row: number;
    col: number;
    label: string;
    value: string;
  } | null>(null);
  const [editingCell, setEditingCell] = useState<{
    rowIndex: number;
    colIndex: number;
    currentValue: string;
    draft: string;
    label: string;
  } | null>(null);
  const [localGridData, setLocalGridData] = useState<unknown[][]>(() =>
    scheduleGridData.map((row) => [...row]),
  );
  const [dragCopy, setDragCopy] = useState<{
    sourceRow: number;
    sourceCol: number;
    sourceValue: string;
    cells: Array<{ rowIndex: number; colIndex: number; oldValue: string }>;
    moved: boolean;
  } | null>(null);
  const dragCopyRef = useRef<typeof dragCopy>(null);
  const [clipboardValue, setClipboardValue] = useState("");
  const [undoStack, setUndoStack] = useState<ChangeHistoryItem[]>([]);
  const [redoStack, setRedoStack] = useState<ChangeHistoryItem[]>([]);
  const [auditLog, setAuditLog] = useState<ChangeHistoryItem[]>([]);
  const [scheduleStatus, setScheduleStatus] = useState<"draft" | "approved" | "published">("draft");

  useEffect(() => {
    setLocalGridData(scheduleGridData.map((row) => [...row]));
  }, [scheduleGridData]);

  useEffect(() => {
    dragCopyRef.current = dragCopy;
  }, [dragCopy]);

  const gridTemplateColumns = useMemo(
    () => `minmax(150px, 190px) repeat(${scheduleDays.length}, minmax(32px, 1fr)) minmax(74px, 86px)`,
    [scheduleDays.length],
  );


  const reservationMap = useMemo(() => {
    const result = new Map<string, VacationReservation>();
    for (const reservation of vacationReservations) {
      result.set(`${reservation.employee_id}__${reservation.date}`, reservation);
    }
    return result;
  }, [vacationReservations]);

  const monthTotalHours = useMemo(
    () => scheduleComplianceRows.reduce((sum, row) => sum + row.plannedHours, 0),
    [scheduleComplianceRows],
  );

  const shortestRest = useMemo(() => {
    const rests = scheduleComplianceRows
      .map((row) => row.shortestRestHours)
      .filter((value): value is number => value !== null);
    return rests.length ? rests.reduce((min, value) => Math.min(min, value), rests[0]) : null;
  }, [scheduleComplianceRows]);

  const minWeeklyRest = useMemo(() => {
    const rests = scheduleComplianceRows
      .map((row) => row.minWeeklyRestHours)
      .filter((value): value is number => typeof value === "number");
    return rests.length ? rests.reduce((min, value) => Math.min(min, value), rests[0]) : null;
  }, [scheduleComplianceRows]);

  const criticalRows = useMemo(
    () => scheduleComplianceRows.filter(isCritical),
    [scheduleComplianceRows],
  );

  const warningOnlyRows = useMemo(
    () => scheduleComplianceRows.filter((row) => !isCritical(row) && row.warnings.length),
    [scheduleComplianceRows],
  );

  const maxSevenDayHours = useMemo(
    () => Math.max(0, ...scheduleComplianceRows.map((row) => row.maxSevenDayHours)),
    [scheduleComplianceRows],
  );

  const maxSevenDayWorkDays = useMemo(
    () => Math.max(0, ...scheduleComplianceRows.map((row) => row.maxSevenDayWorkDays)),
    [scheduleComplianceRows],
  );

  const updateLocalCell = (rowIndex: number, colIndex: number, value: string) => {
    setLocalGridData((prev) => {
      const next = prev.map((row) => [...row]);
      if (!next[rowIndex]) next[rowIndex] = [];
      next[rowIndex][colIndex] = value;
      return next;
    });
  };

  const applyLocalChanges = (changes: GridChange[], direction: "next" | "previous") => {
    setLocalGridData((prev) => {
      const next = prev.map((row) => [...row]);
      for (const [rowIndex, colIndex, oldValue, nextValue] of changes) {
        if (!next[rowIndex]) next[rowIndex] = [];
        next[rowIndex][colIndex] = direction === "next" ? nextValue : oldValue;
      }
      return next;
    });
  };

  const rememberHistory = (label: string, changes: GridChange[]) => {
    if (!changes.length) return;
    const item: ChangeHistoryItem = {
      id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      label,
      at: new Date().toLocaleString("lt-LT"),
      changes,
    };
    setUndoStack((prev) => [item, ...prev].slice(0, 30));
    setRedoStack([]);
    setAuditLog((prev) => [item, ...prev].slice(0, 60));
  };

  const persistGridChanges = async (changes: GridChange[], label: string, successMessage: string) => {
    if (!changes.length) return;
    applyLocalChanges(changes, "next");
    rememberHistory(label, changes);
    setLocalSaving(true);
    setSavedMessage(successMessage);
    try {
      await onSaveGridChanges(changes);
    } catch (error) {
      applyLocalChanges(changes, "previous");
      setSavedMessage(error instanceof Error ? error.message : "Nepavyko išsaugoti pakeitimų.");
    } finally {
      setLocalSaving(false);
    }
  };

  const undoLastChange = async () => {
    const item = undoStack[0];
    if (!item) return;
    const reverseChanges = item.changes.map(([row, col, oldValue, nextValue]) => [row, col, nextValue, oldValue] as GridChange);
    applyLocalChanges(item.changes, "previous");
    setUndoStack((prev) => prev.slice(1));
    setRedoStack((prev) => [item, ...prev].slice(0, 30));
    setSavedMessage(`Atšaukta: ${item.label}`);
    setLocalSaving(true);
    try {
      await onSaveGridChanges(reverseChanges);
    } catch (error) {
      applyLocalChanges(item.changes, "next");
      setSavedMessage(error instanceof Error ? error.message : "Nepavyko atšaukti pakeitimo.");
    } finally {
      setLocalSaving(false);
    }
  };

  const redoLastChange = async () => {
    const item = redoStack[0];
    if (!item) return;
    applyLocalChanges(item.changes, "next");
    setRedoStack((prev) => prev.slice(1));
    setUndoStack((prev) => [item, ...prev].slice(0, 30));
    setSavedMessage(`Pakartota: ${item.label}`);
    setLocalSaving(true);
    try {
      await onSaveGridChanges(item.changes);
    } catch (error) {
      applyLocalChanges(item.changes, "previous");
      setSavedMessage(error instanceof Error ? error.message : "Nepavyko pakartoti pakeitimo.");
    } finally {
      setLocalSaving(false);
    }
  };

  const commitCell = async (
    rowIndex: number,
    colIndex: number,
    currentValue: string,
    nextValue: string,
  ) => {
    const parsed = parseShiftValue(nextValue);
    const value = parsed.normalized.trim();
    const currentNormalized = parseShiftValue(currentValue).normalized.trim();

    setEditingCell(null);
    setActiveCell((prev) => (prev ? { ...prev, value } : prev));

    if (value === currentNormalized) return;

    await persistGridChanges(
      [[rowIndex, colIndex, currentValue, value]],
      `${activeCell?.label || "Langelis"}: ${currentNormalized || "tuščia"} → ${value || "tuščia"}`,
      value ? `Išsaugota: ${value}` : "Langelyje pamaina išvalyta",
    );
  };

  const startCopyDrag = (rowIndex: number, colIndex: number, value: string) => {
    const normalized = parseShiftValue(value).normalized.trim();
    if (!normalized) return;
    setDragCopy({
      sourceRow: rowIndex,
      sourceCol: colIndex,
      sourceValue: normalized,
      cells: [],
      moved: false,
    });
  };

  const addCopyDragCell = (rowIndex: number, colIndex: number, currentValue: string) => {
    setDragCopy((prev) => {
      if (!prev) return prev;
      if (prev.sourceRow === rowIndex && prev.sourceCol === colIndex) return prev;
      if (prev.cells.some((cell) => cell.rowIndex === rowIndex && cell.colIndex === colIndex)) return prev;

      updateLocalCell(rowIndex, colIndex, prev.sourceValue);
      return {
        ...prev,
        moved: true,
        cells: [...prev.cells, { rowIndex, colIndex, oldValue: currentValue }],
      };
    });
  };

  const finishCopyDrag = async () => {
    const drag = dragCopyRef.current;
    setDragCopy(null);

    if (!drag || !drag.moved || drag.cells.length === 0) return;

    const changes = drag.cells
      .map((cell) => [cell.rowIndex, cell.colIndex, cell.oldValue, drag.sourceValue] as [number, number, string, string])
      .filter(([, , oldValue, nextValue]) => parseShiftValue(oldValue).normalized.trim() !== nextValue);

    if (!changes.length) return;

    await persistGridChanges(
      changes,
      `Drag kopijavimas: ${drag.sourceValue} į ${changes.length} lang.`,
      `Nukopijuota: ${drag.sourceValue} į ${changes.length} lang.`,
    );
  };

  const quickSetActiveCell = async (nextValue: string) => {
    if (!activeCell) return;
    const rowIndex = activeCell.row - 1;
    const colIndex = activeCell.col;
    const currentValue = String(localGridData[rowIndex]?.[colIndex] || "");
    await commitCell(rowIndex, colIndex, currentValue, nextValue);
    setActiveCell((prev) => (prev ? { ...prev, value: parseShiftValue(nextValue).normalized } : prev));
  };

  const copyActiveCell = () => {
    if (!activeCell) return;
    const normalized = parseShiftValue(activeCell.value).normalized.trim();
    if (!normalized) return;
    setClipboardValue(normalized);
    setSavedMessage(`Nukopijuota: ${normalized}`);
  };

  const pasteToActiveCell = async () => {
    if (!activeCell || !clipboardValue) return;
    const rowIndex = activeCell.row - 1;
    const colIndex = activeCell.col;
    const currentValue = String(localGridData[rowIndex]?.[colIndex] || "");
    await commitCell(rowIndex, colIndex, currentValue, clipboardValue);
  };

  const autoFillActiveRow = async () => {
    if (!activeCell) return;
    const source = parseShiftValue(activeCell.value).normalized.trim();
    if (!source) return;
    const rowIndex = activeCell.row - 1;
    const changes: Array<[number, number, string, string]> = [];

    scheduleDays.forEach((_, dayIndex) => {
      const colIndex = dayIndex + 1;
      const currentValue = String(localGridData[rowIndex]?.[colIndex] || "");
      const normalized = parseShiftValue(currentValue).normalized.trim();
      if (!normalized) changes.push([rowIndex, colIndex, currentValue, source]);
    });

    if (!changes.length) {
      setSavedMessage("Šioje eilutėje tuščių langelių nėra.");
      return;
    }

    await persistGridChanges(
      changes,
      `Auto-fill eilutė: ${source} į ${changes.length} lang.`,
      `Auto-fill baigta: ${source} į ${changes.length} lang.`,
    );
  };

  const autoFillEmptyMonthSmart = async () => {
    const changes: GridChange[] = [];
    employees.forEach((employee, rowIndex) => {
      scheduleDays.forEach((day, dayIndex) => {
        const colIndex = dayIndex + 1;
        const currentValue = String(localGridData[rowIndex]?.[colIndex] || "");
        const normalized = parseShiftValue(currentValue).normalized.trim();
        const dayKey = toDateInput(day);
        const reservation = reservationMap.get(`${employee.user_id}__${dayKey}`);
        const isWeekend = day.getDay() === 0 || day.getDay() === 6;
        if (normalized || reservation || isWeekend) return;
        changes.push([rowIndex, colIndex, currentValue, "08:00-20:00"]);
      });
    });
    if (!changes.length) {
      setSavedMessage("Smart auto-fill nerado tuščių darbo dienų be rezervacijų.");
      return;
    }
    await persistGridChanges(changes, `Smart auto-fill: ${changes.length} lang.`, `Smart auto-fill užpildė ${changes.length} lang.`);
  };

  const createTimesheetDraft = () => {
    setSavedMessage("Tabelio juodraštis paruoštas iš grafiko. Kitas žingsnis – prijungti faktinių valandų DB lentelę.");
    const item: ChangeHistoryItem = {
      id: `${Date.now()}-timesheet`,
      label: "Tabelio juodraštis sukurtas iš grafiko",
      at: new Date().toLocaleString("lt-LT"),
      changes: [],
    };
    setAuditLog((prev) => [item, ...prev].slice(0, 60));
  };

  const activeParsed = activeCell ? parseShiftValue(activeCell.value) : null;

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const tagName = target?.tagName?.toLowerCase();
      if (tagName === "input" || tagName === "textarea") return;
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "z") {
        event.preventDefault();
        void undoLastChange();
      }
      if ((event.ctrlKey || event.metaKey) && (event.key.toLowerCase() === "y" || (event.shiftKey && event.key.toLowerCase() === "z"))) {
        event.preventDefault();
        void redoLastChange();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [undoStack, redoStack]);

  return (
    <section className="schedule-shell">
      <style jsx global>{`
        .schedule-shell {
          display: grid;
          gap: 12px;
          padding: 12px;
          border-radius: 24px;
          background: #f8fafc;
          border: 1px solid #dbe4ef;
          box-shadow: 0 22px 60px rgba(15, 23, 42, 0.1);
        }
        .schedule-titlebar {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 12px;
          padding: 14px 16px;
          border-radius: 20px;
          background: linear-gradient(135deg, #0f766e, #0f172a);
          color: #fff;
        }
        .schedule-title {
          margin: 0;
          font-size: 22px;
          line-height: 1.05;
          font-weight: 950;
          letter-spacing: -0.035em;
        }
        .schedule-subtitle {
          margin: 5px 0 0;
          color: rgba(255, 255, 255, 0.78);
          font-size: 13px;
          font-weight: 750;
        }
        .schedule-save {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 9px 12px;
          border-radius: 999px;
          background: rgba(255, 255, 255, 0.13);
          border: 1px solid rgba(255, 255, 255, 0.18);
          color: #d1fae5;
          font-weight: 900;
          white-space: nowrap;
          font-size: 13px;
        }
        .schedule-metrics {
          display: grid;
          grid-template-columns: repeat(6, minmax(116px, 1fr));
          gap: 8px;
        }
        .schedule-metric {
          padding: 11px 12px;
          border-radius: 16px;
          background: #fff;
          border: 1px solid #e2e8f0;
          box-shadow: 0 12px 28px rgba(15, 23, 42, 0.06);
        }
        .schedule-metric-label {
          display: flex;
          align-items: center;
          gap: 7px;
          color: #64748b;
          font-size: 10px;
          font-weight: 950;
          text-transform: uppercase;
          letter-spacing: 0.04em;
        }
        .schedule-metric-value {
          margin-top: 7px;
          color: #0f172a;
          font-size: 22px;
          font-weight: 950;
          letter-spacing: -0.035em;
        }
        .schedule-metric-value.good { color: #059669; }
        .schedule-metric-value.warn { color: #d97706; }
        .schedule-metric-value.bad { color: #dc2626; }
        .schedule-toolbar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 10px;
          flex-wrap: wrap;
          padding: 10px;
          border-radius: 18px;
          background: #fff;
          border: 1px solid #e2e8f0;
        }
        .schedule-toolbar-left,
        .schedule-toolbar-right {
          display: flex;
          align-items: center;
          flex-wrap: wrap;
          gap: 8px;
        }
        .schedule-btn {
          min-height: 38px;
          display: inline-flex;
          align-items: center;
          gap: 7px;
          border: 1px solid #dbe4ef;
          border-radius: 12px;
          background: #fff;
          color: #0f172a;
          padding: 0 12px;
          font-weight: 900;
          cursor: pointer;
        }
        .schedule-btn:hover { background: #f8fafc; transform: translateY(-1px); }
        .schedule-month {
          min-height: 38px;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 0 14px;
          border-radius: 12px;
          background: #0f172a;
          color: #fff;
          font-weight: 950;
          text-transform: capitalize;
        }
        .schedule-chip {
          display: inline-flex;
          gap: 7px;
          align-items: center;
          padding: 7px 9px;
          border-radius: 999px;
          background: #f8fafc;
          border: 1px solid #e2e8f0;
          font-size: 12px;
          color: #334155;
          font-weight: 850;
        }
        .schedule-dot {
          width: 21px;
          height: 21px;
          border-radius: 7px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          font-size: 11px;
          font-weight: 950;
        }
        .schedule-dot-work { background: #bbf7d0; color: #065f46; }
        .schedule-dot-night { background: #fed7aa; color: #9a3412; }
        .schedule-dot-off { background: #ddd6fe; color: #5b21b6; }
        .schedule-dot-vacation { background: #bfdbfe; color: #1e40af; }
        .schedule-dot-sick { background: #fecaca; color: #991b1b; }
        .schedule-formula {
          display: grid;
          grid-template-columns: minmax(180px, 260px) 1fr;
          overflow: hidden;
          border: 1px solid #dbe4ef;
          border-radius: 16px;
          background: #fff;
        }
        .schedule-namebox {
          padding: 10px 12px;
          border-right: 1px solid #e2e8f0;
          color: #475569;
          font-weight: 950;
          background: #f8fafc;
          min-width: 0;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .schedule-formula-value {
          padding: 10px 12px;
          color: #0f172a;
          font-weight: 850;
          min-height: 40px;
        }
        .schedule-formula-value b { color: #047857; }
        .schedule-quick-actions {
          display: inline-flex;
          align-items: center;
          flex-wrap: wrap;
          gap: 6px;
          margin-left: 10px;
          vertical-align: middle;
        }
        .schedule-quick-btn {
          border: 1px solid #dbe4ef;
          border-radius: 999px;
          background: #fff;
          color: #0f172a;
          padding: 5px 9px;
          font-size: 11px;
          font-weight: 950;
          cursor: pointer;
        }
        .schedule-quick-btn:hover { background: #f8fafc; transform: translateY(-1px); }
        .schedule-quick-btn:disabled { opacity: 0.45; cursor: not-allowed; transform: none; }
        .schedule-quick-btn.clear { color: #991b1b; border-color: #fecaca; background: #fff5f5; }
        .schedule-quick-btn.off { color: #5b21b6; background: #f5f3ff; border-color: #ddd6fe; }
        .schedule-quick-btn.vacation { color: #1e40af; background: #eff6ff; border-color: #bfdbfe; }
        .schedule-quick-btn.sick { color: #991b1b; background: #fef2f2; border-color: #fecaca; }
        .schedule-status-strip {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 10px;
          flex-wrap: wrap;
          padding: 10px;
          border-radius: 18px;
          background: #fff;
          border: 1px solid #e2e8f0;
        }
        .schedule-status-pill {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 8px 11px;
          border-radius: 999px;
          font-size: 12px;
          font-weight: 950;
          background: #f1f5f9;
          color: #334155;
          border: 1px solid #dbe4ef;
        }
        .schedule-status-pill.active { background: #dcfce7; color: #166534; border-color: #86efac; }
        .schedule-history-panel {
          display: grid;
          gap: 8px;
          padding: 12px;
          border-radius: 18px;
          border: 1px solid #e2e8f0;
          background: #fff;
        }
        .schedule-history-title {
          display: flex;
          align-items: center;
          gap: 8px;
          font-weight: 950;
          color: #0f172a;
        }
        .schedule-history-list {
          display: grid;
          gap: 6px;
          max-height: 190px;
          overflow: auto;
        }
        .schedule-history-item {
          display: flex;
          justify-content: space-between;
          gap: 10px;
          padding: 8px 10px;
          border-radius: 12px;
          background: #f8fafc;
          color: #334155;
          font-size: 12px;
          font-weight: 800;
        }
        .schedule-history-item time { color: #64748b; white-space: nowrap; }
        .schedule-help,
        .schedule-success,
        .schedule-alert {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
          align-items: center;
          padding: 10px 12px;
          border-radius: 16px;
          font-weight: 850;
          font-size: 13px;
        }
        .schedule-help {
          border: 1px solid #dbeafe;
          background: #eff6ff;
          color: #1e40af;
        }
        .schedule-success {
          border: 1px solid #bbf7d0;
          background: #f0fdf4;
          color: #047857;
          font-weight: 900;
        }
        .schedule-alert {
          border: 1px solid #fed7aa;
          background: #fff7ed;
          color: #9a3412;
        }
        .schedule-alert.bad {
          border-color: #fecaca;
          background: #fef2f2;
          color: #991b1b;
        }
        .schedule-grid-shell {
          width: 100%;
          user-select: none;
          overflow: hidden;
          border: 1px solid #cbd5e1;
          border-radius: 18px;
          background: #fff;
          box-shadow: 0 22px 60px rgba(15, 23, 42, 0.1);
        }
        .schedule-grid {
          display: grid;
          width: 100%;
          min-width: 980px;
        }
        .schedule-grid-cell {
          min-width: 0;
          min-height: 44px;
          border-right: 1px solid #dbe4ef;
          border-bottom: 1px solid #dbe4ef;
          background: #fff;
        }
        .schedule-head {
          min-height: 44px;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          color: #0f172a;
          font-weight: 950;
          background: #f1f5f9;
          line-height: 1.05;
          position: sticky;
          top: 0;
          z-index: 4;
        }
        .schedule-head.weekend { background: #ffedd5; }
        .schedule-head-day { font-size: 15px; letter-spacing: -0.035em; }
        .schedule-head-weekday { margin-top: 3px; font-size: 10px; color: #64748b; }
        .schedule-person-head,
        .schedule-total-head {
          background: #e2e8f0;
          color: #0f172a;
          font-weight: 950;
          padding: 9px 10px;
          display: flex;
          align-items: center;
          position: sticky;
          top: 0;
          z-index: 5;
        }
        .schedule-total-head {
          justify-content: center;
          box-shadow: -10px 0 22px rgba(15, 23, 42, 0.07);
        }
        .schedule-person {
          display: flex;
          flex-direction: column;
          justify-content: center;
          gap: 3px;
          padding: 7px 9px;
          background: linear-gradient(180deg, #fff, #f8fafc);
        }
        .schedule-person-name {
          color: #0f172a;
          font-weight: 950;
          line-height: 1.1;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          font-size: 13px;
        }
        .schedule-person-role {
          color: #64748b;
          font-size: 11px;
          font-weight: 800;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .schedule-day-cell {
          min-height: 58px;
          padding: 2px;
          background: #fff;
        }
        .schedule-day-cell.weekend { background: #fffaf4; }
        .schedule-day-cell.is-drag-target {
          background: #d1fae5;
          box-shadow: inset 0 0 0 2px rgba(5, 150, 105, 0.55);
        }
        .schedule-day-cell.is-editing {
          background: #ecfdf5;
          box-shadow: inset 0 0 0 2px rgba(16, 185, 129, 0.5);
        }
        .schedule-day-cell.has-reservation { background-image: repeating-linear-gradient(135deg, rgba(100, 116, 139, 0.10) 0 6px, transparent 6px 12px); }
        .schedule-day-cell.has-conflict { box-shadow: inset 0 0 0 2px rgba(220, 38, 38, 0.55); }
        .schedule-shift {
          position: relative;
          width: 100%;
          height: 54px;
          border: 0;
          border-radius: 9px;
          display: flex;
          align-items: center;
          justify-content: center;
          text-align: center;
          cursor: pointer;
          font-weight: 900;
          font-size: 9px;
          line-height: 1;
          letter-spacing: -0.08em;
          color: #0f172a;
          box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.8);
          font-variant-numeric: tabular-nums;
        }
        .schedule-shift:hover {
          transform: translateY(-1px);
          box-shadow: 0 8px 18px rgba(15, 23, 42, 0.13);
        }
        .schedule-shift-empty {
          border: 1px dashed #cbd5e1;
          background: #fff;
          color: #cbd5e1;
          font-size: 18px;
          letter-spacing: 0;
        }
        .schedule-shift-work { background: linear-gradient(135deg, #dcfce7, #86efac); color: #065f46; }
        .schedule-shift-night { background: linear-gradient(135deg, #ffedd5, #fdba74); color: #9a3412; }
        .schedule-shift-off { background: linear-gradient(135deg, #ede9fe, #c4b5fd); color: #5b21b6; }
        .schedule-shift-vacation { background: linear-gradient(135deg, #dbeafe, #93c5fd); color: #1e40af; }
        .schedule-shift-sick { background: linear-gradient(135deg, #fee2e2, #fca5a5); color: #991b1b; }
        .schedule-shift-unknown { background: #f8fafc; color: #64748b; border: 1px dashed #cbd5e1; }
        .schedule-shift-long { background: linear-gradient(135deg, #ffedd5, #fdba74); color: #9a3412; }
        .schedule-shift-danger { background: linear-gradient(135deg, #fee2e2, #fca5a5); color: #991b1b; }
        .schedule-shift-time {
          display: grid;
          grid-template-rows: 1fr auto 1fr;
          align-items: center;
          justify-items: center;
          width: 100%;
          min-width: 0;
          overflow: visible;
          line-height: 1;
        }
        .schedule-shift-time-value {
          display: block;
          width: 100%;
          min-width: 0;
          white-space: nowrap;
          overflow: visible;
          text-align: center;
          font-size: 8.7px;
          font-weight: 950;
          letter-spacing: -0.1em;
          transform: scaleX(0.88);
          transform-origin: center;
        }
        .schedule-shift-time-separator {
          display: block;
          height: 1px;
          width: 14px;
          margin: 1px 0;
          border-radius: 999px;
          background: currentColor;
          opacity: 0.35;
        }
        .schedule-shift-status {
          font-size: 14px;
          letter-spacing: 0;
        }
        .schedule-reservation-badge {
          position: absolute;
          right: 2px;
          top: 2px;
          width: 14px;
          height: 14px;
          border-radius: 999px;
          background: #64748b;
          color: #fff;
          display: grid;
          place-items: center;
          font-size: 8px;
          font-weight: 950;
          border: 1px solid rgba(255,255,255,0.8);
        }
        .schedule-edit-input {
          width: 100%;
          height: 52px;
          border-radius: 9px;
          border: 1px solid #10b981;
          outline: none;
          text-align: center;
          font-weight: 950;
          font-size: 10px;
          color: #0f172a;
          background: #fff;
          box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.18);
          font-variant-numeric: tabular-nums;
        }
        .schedule-total {
          min-height: 54px;
          padding: 6px 5px;
          background: #fff;
          text-align: center;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          box-shadow: -10px 0 22px rgba(15, 23, 42, 0.05);
        }
        .schedule-total-hours {
          color: #0f172a;
          font-weight: 950;
          font-size: 12px;
          line-height: 1.05;
        }
        .schedule-total-status {
          display: inline-flex;
          margin-top: 4px;
          padding: 4px 6px;
          border-radius: 999px;
          font-size: 10px;
          font-weight: 950;
          background: #dcfce7;
          color: #166534;
        }
        .schedule-total-status.warn { background: #ffedd5; color: #9a3412; }
        .schedule-total-status.bad { background: #fee2e2; color: #991b1b; }
        .schedule-summary {
          display: grid;
          grid-template-columns: minmax(220px, 0.8fr) repeat(4, minmax(150px, 1fr));
          overflow: hidden;
          border: 1px solid #e2e8f0;
          border-radius: 18px;
          background: #fff;
        }
        .schedule-summary > div {
          padding: 13px 15px;
          border-right: 1px solid #e2e8f0;
        }
        .schedule-summary > div:last-child { border-right: 0; }
        .schedule-summary-title {
          color: #0f172a;
          font-weight: 950;
          margin-bottom: 8px;
        }
        .schedule-summary-row {
          display: flex;
          justify-content: space-between;
          gap: 10px;
          margin-top: 8px;
          color: #475569;
          font-weight: 850;
          font-size: 13px;
        }
        .schedule-summary-value {
          font-size: 22px;
          font-weight: 950;
          color: #0f172a;
          margin-top: 6px;
        }
        @media (max-width: 1250px) {
          .schedule-metrics { grid-template-columns: repeat(3, 1fr); }
          .schedule-summary { grid-template-columns: 1fr; }
          .schedule-summary > div { border-right: 0; border-bottom: 1px solid #e2e8f0; }
          .schedule-grid-shell { overflow-x: auto; }
        }
        @media (max-width: 760px) {
          .schedule-shell { padding: 10px; }
          .schedule-titlebar { display: grid; }
          .schedule-metrics { grid-template-columns: 1fr 1fr; }
          .schedule-formula { grid-template-columns: 1fr; }
          .schedule-namebox { border-right: 0; border-bottom: 1px solid #e2e8f0; }
          .schedule-grid { min-width: 1120px; }
        }
      `}</style>

      <div className="schedule-titlebar">
        <div>
          <h2 className="schedule-title">Darbo grafikas</h2>
          <p className="schedule-subtitle">
            Grid versija: visas mėnuo telpa kompaktiškai, pamainos rodomos kaip blokai, o laikas saugomas pilnu HH:mm-HH:mm formatu.
          </p>
        </div>
        <div className="schedule-save">
          <Clock size={16} />
          {saving || localSaving ? "Saugoma..." : "Automatinis išsaugojimas"}
        </div>
      </div>

      <div className="schedule-metrics">
        <Metric icon={<Users size={16} />} label="Darbuotojai" value={employees.length} />
        <Metric icon={<CalendarDays size={16} />} label="Mėnesio valandos" value={`${monthTotalHours.toFixed(1)} val.`} good />
        <Metric icon={<AlertTriangle size={16} />} label="7 d. valandos" value={`${maxSevenDayHours.toFixed(1)} val.`} warn={maxSevenDayHours > 48} bad={maxSevenDayHours > 52} />
        <Metric icon={<CalendarDays size={16} />} label="Darbo d. / 7 d." value={`${maxSevenDayWorkDays} / 7`} warn={maxSevenDayWorkDays > 5} bad={maxSevenDayWorkDays > 6} />
        <Metric icon={<Clock size={16} />} label="Poilsis tarp pamainų" value={shortestRest === null ? "—" : `${shortestRest.toFixed(1)} val.`} warn={shortestRest !== null && shortestRest < 11} bad={shortestRest !== null && shortestRest < 11} good={shortestRest !== null && shortestRest >= 11} />
        <Metric icon={<ShieldAlert size={16} />} label="35 val. savaitinis poilsis" value={minWeeklyRest === null ? "—" : `${minWeeklyRest.toFixed(1)} val.`} warn={minWeeklyRest !== null && minWeeklyRest < 35} bad={minWeeklyRest !== null && minWeeklyRest < 35} good={minWeeklyRest !== null && minWeeklyRest >= 35} />
      </div>

      <div className="schedule-toolbar">
        <div className="schedule-toolbar-left">
          <button type="button" className="schedule-btn" onClick={() => setScheduleMonth((prev) => addMonths(prev, -1))}>
            <ChevronLeft size={16} /> Ankstesnis
          </button>
          <div className="schedule-month">
            <CalendarDays size={16} /> {monthLabel(scheduleMonth)}
          </div>
          <button type="button" className="schedule-btn" onClick={() => setScheduleMonth((prev) => addMonths(prev, 1))}>
            Kitas <ChevronRight size={16} />
          </button>
        </div>
        <div className="schedule-toolbar-right">
          <span className="schedule-chip"><span className="schedule-dot schedule-dot-work">D</span>Darbas</span>
          <span className="schedule-chip"><span className="schedule-dot schedule-dot-night">N</span>Naktinė / ilga</span>
          <span className="schedule-chip"><span className="schedule-dot schedule-dot-off">P</span>Poilsis</span>
          <span className="schedule-chip"><span className="schedule-dot schedule-dot-vacation">A</span>Atostogos</span>
          <span className="schedule-chip"><span className="schedule-dot schedule-dot-sick">L</span>Liga</span>
          <span className="schedule-chip"><Download size={15} /> Eksportas vėliau</span>
        </div>
      </div>

      <div className="schedule-status-strip">
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <span className={scheduleStatus === "draft" ? "schedule-status-pill active" : "schedule-status-pill"}><History size={14} /> Juodraštis</span>
          <span className={scheduleStatus === "approved" ? "schedule-status-pill active" : "schedule-status-pill"}><Lock size={14} /> Patvirtintas</span>
          <span className={scheduleStatus === "published" ? "schedule-status-pill active" : "schedule-status-pill"}><Send size={14} /> Paskelbtas</span>
        </div>
        <div className="schedule-toolbar-right">
          <button type="button" className="schedule-btn" disabled={!undoStack.length} onClick={() => void undoLastChange()}><Undo2 size={16} /> Undo</button>
          <button type="button" className="schedule-btn" disabled={!redoStack.length} onClick={() => void redoLastChange()}><Redo2 size={16} /> Redo</button>
          <button type="button" className="schedule-btn" onClick={() => void autoFillEmptyMonthSmart()}><Sparkles size={16} /> Smart auto-fill</button>
          <button type="button" className="schedule-btn" onClick={createTimesheetDraft}><CheckCircle2 size={16} /> Tabelio juodraštis</button>
          <button type="button" className="schedule-btn" onClick={() => setScheduleStatus("approved")}><Lock size={16} /> Patvirtinti</button>
          <button type="button" className="schedule-btn" onClick={() => setScheduleStatus("published")}><Send size={16} /> Paskelbti</button>
        </div>
      </div>

      <div className="schedule-formula">
        <div className="schedule-namebox">{activeCell ? activeCell.label : "Pasirinkite langelį"}</div>
        <div className="schedule-formula-value">
          {activeCell ? (
            <>
              Reikšmė: <b>{activeParsed?.detail}</b>
              <span className="schedule-quick-actions">
                <button type="button" className="schedule-quick-btn clear" onClick={() => void quickSetActiveCell("")}>Išvalyti</button>
                <button type="button" className="schedule-quick-btn" onClick={copyActiveCell}>Kopijuoti</button>
                <button type="button" className="schedule-quick-btn" disabled={!clipboardValue} onClick={() => void pasteToActiveCell()}>Įklijuoti</button>
                <button type="button" className="schedule-quick-btn" onClick={() => void autoFillActiveRow()}>Auto-fill eilutę</button>
                <button type="button" className="schedule-quick-btn off" onClick={() => void quickSetActiveCell("P")}>P</button>
                <button type="button" className="schedule-quick-btn vacation" onClick={() => void quickSetActiveCell("A")}>A</button>
                <button type="button" className="schedule-quick-btn sick" onClick={() => void quickSetActiveCell("L")}>L</button>
                <button type="button" className="schedule-quick-btn vacation" onClick={() => void quickSetActiveCell("MD")}>MD</button>
                <button type="button" className="schedule-quick-btn vacation" onClick={() => void quickSetActiveCell("TD")}>TD</button>
                <button type="button" className="schedule-quick-btn vacation" onClick={() => void quickSetActiveCell("NA")}>NA</button>
              </span>
            </>
          ) : (
            "Pvz. 07:00-19:00, 19:00-07:00, 14-24, P, A arba L"
          )}
        </div>
      </div>

      {savedMessage ? (
        <div className="schedule-success"><CheckCircle2 size={18} />{savedMessage}</div>
      ) : null}

      <div className="schedule-help">
        Langeliai rodomi kompaktiškai. Paspaudus langelį jo turinys pažymimas visas, todėl gali iškart rašyti naują reikšmę arba spausti Delete. Klaviatūra: P/A/L, greiti MD/TD/NA mygtukai, Ctrl+C/Ctrl+V ir drag kopijavimas per kelis langelius. Pilnas formatas: <b>07:30-19:15</b>, <b>11:00-23:00</b>, <b>20:00-08:00</b>. Galima įvesti <b>11-23</b> arba <b>14-24</b> – išsaugoma normalizuotai. Pilkai/brūkšniuotai pažymėtas <b>R</b> yra laukiančio neatvykimo prašymo rezervacija.
      </div>

      {criticalRows.length || warningOnlyRows.length ? (
        <div style={{ display: "grid", gap: 8 }}>
          {criticalRows.slice(0, 6).map((row) => (
            <div key={row.employee.user_id} className="schedule-alert bad">
              <ShieldAlert size={18} />
              <div><b>{employeeName(row.employee)}</b>: {(row.errors?.length ? row.errors : row.warnings).slice(0, 3).join("; ")}</div>
            </div>
          ))}
          {warningOnlyRows.slice(0, 4).map((row) => (
            <div key={row.employee.user_id} className="schedule-alert">
              <AlertTriangle size={18} />
              <div><b>{employeeName(row.employee)}</b>: {row.warnings.slice(0, 3).join("; ")}</div>
            </div>
          ))}
        </div>
      ) : (
        <div className="schedule-success"><CheckCircle2 size={18} />Kritinių grafiko įspėjimų šiam mėnesiui nėra.</div>
      )}

      <div className="schedule-grid-shell" onMouseUp={() => void finishCopyDrag()} onMouseLeave={() => void finishCopyDrag()}>
        <div className="schedule-grid" style={{ gridTemplateColumns }}>
          <div className="schedule-grid-cell schedule-person-head">Darbuotojas</div>
          {scheduleDays.map((day) => {
            const weekend = day.getDay() === 0 || day.getDay() === 6;
            return (
              <div key={`head-${toDateInput(day)}`} className={`schedule-grid-cell schedule-head${weekend ? " weekend" : ""}`}>
                <div className="schedule-head-day">{String(day.getDate()).padStart(2, "0")}</div>
                <div className="schedule-head-weekday">{formatDay(day)}</div>
              </div>
            );
          })}
          <div className="schedule-grid-cell schedule-total-head">Iš viso</div>

          {employees.map((employee, rowIndex) => {
            const compliance = scheduleComplianceRows.find((row) => row.employee.user_id === employee.user_id);
            const rowBad = compliance ? isCritical(compliance) : false;
            const rowWarn = compliance ? !rowBad && compliance.warnings.length > 0 : false;

            return (
              <div key={employee.user_id} style={{ display: "contents" }}>
                <div className="schedule-grid-cell schedule-person">
                  <div className="schedule-person-name">{employeeName(employee)}</div>
                  <div className="schedule-person-role">{employeeRole(employee)}</div>
                </div>

                {scheduleDays.map((day, dayIndex) => {
                  const colIndex = dayIndex + 1;
                  const value = String(localGridData[rowIndex]?.[colIndex] || "");
                  const parsed = parseShiftValue(value);
                  const dayKey = toDateInput(day);
                  const reservation = reservationMap.get(`${employee.user_id}__${dayKey}`);
                  const hasConflict = Boolean(reservation && parsed.kind === "work");
                  const label = `${employeeName(employee)} · ${String(day.getDate()).padStart(2, "0")} ${formatDay(day)}`;
                  const isEditing = editingCell?.rowIndex === rowIndex && editingCell?.colIndex === colIndex;
                  const isDragTarget = Boolean(dragCopy?.cells.some((cell) => cell.rowIndex === rowIndex && cell.colIndex === colIndex));
                  const weekend = day.getDay() === 0 || day.getDay() === 6;

                  return (
                    <div key={`${employee.user_id}-${toDateInput(day)}`} className={`schedule-grid-cell schedule-day-cell${weekend ? " weekend" : ""}${isEditing ? " is-editing" : ""}${isDragTarget ? " is-drag-target" : ""}${reservation ? " has-reservation" : ""}${hasConflict ? " has-conflict" : ""}`}>
                      {isEditing ? (
                        <input
                          autoFocus
                          className="schedule-edit-input"
                          value={editingCell.draft}
                          onChange={(event) => {
                            const draft = event.currentTarget.value;
                            setEditingCell((prev) => (prev ? { ...prev, draft } : prev));
                            setActiveCell({ row: rowIndex + 1, col: colIndex, label, value: draft });
                          }}
                          onFocus={(event) => event.currentTarget.select()}
                          onBlur={(event) => void commitCell(rowIndex, colIndex, value, event.currentTarget.value)}
                          onKeyDown={(event) => {
                            if (event.key === "Enter") event.currentTarget.blur();
                            if (event.key === "Escape") {
                              setEditingCell(null);
                              setActiveCell({ row: rowIndex + 1, col: colIndex, label, value });
                            }
                            if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "a") {
                              event.currentTarget.select();
                            }
                          }}
                        />
                      ) : (
                        <button
                          type="button"
                          className={cellClass(parsed)}
                          title={reservation ? `${reservation.label} (${reservation.code}) · Laukia patvirtinimo${hasConflict ? " · Yra pateiktas neatvykimo prašymas" : ""}` : (parsed.detail || "Įrašykite laiką, pvz. 07:30-19:15, arba P / A / L / MD / TD / NA")}
                          onPointerDown={() => startCopyDrag(rowIndex, colIndex, value)}
                          onPointerEnter={() => addCopyDragCell(rowIndex, colIndex, value)}
                          onClick={() => {
                            if (dragCopyRef.current?.moved) return;
                            setEditingCell({ rowIndex, colIndex, currentValue: value, draft: value, label });
                            setActiveCell({ row: rowIndex + 1, col: colIndex, label, value });
                          }}
                          onFocus={() => setActiveCell({ row: rowIndex + 1, col: colIndex, label, value })}
                          onKeyDown={(event) => {
                            if (event.key === "Delete" || event.key === "Backspace") {
                              event.preventDefault();
                              void commitCell(rowIndex, colIndex, value, "");
                            }
                            const key = event.key.toUpperCase();
                            if ((event.ctrlKey || event.metaKey) && key === "C") {
                              event.preventDefault();
                              const normalized = parseShiftValue(value).normalized.trim();
                              if (normalized) {
                                setClipboardValue(normalized);
                                setSavedMessage(`Nukopijuota: ${normalized}`);
                              }
                            }
                            if ((event.ctrlKey || event.metaKey) && key === "V") {
                              event.preventDefault();
                              if (clipboardValue) void commitCell(rowIndex, colIndex, value, clipboardValue);
                            }
                            if (["P", "A", "L"].includes(key)) {
                              event.preventDefault();
                              void commitCell(rowIndex, colIndex, value, key);
                            }
                          }}
                        >
                          {parsed.kind === "empty" ? (
                            <span>{reservation ? "" : "+"}</span>
                          ) : parsed.kind === "off" || parsed.kind === "vacation" || parsed.kind === "sick" ? (
                            <span className="schedule-shift-status">{parsed.compact}</span>
                          ) : parsed.hours !== null ? (
                            <span className="schedule-shift-time" aria-label={parsed.display}>
                              <span className="schedule-shift-time-value">{parsed.startLabel}</span>
                              <span className="schedule-shift-time-separator" aria-hidden="true" />
                              <span className="schedule-shift-time-value">{parsed.endLabel}</span>
                            </span>
                          ) : (
                            <span className="schedule-shift-status">{parsed.compact}</span>
                          )}
                          {reservation ? <span className="schedule-reservation-badge">R</span> : null}
                        </button>
                      )}
                    </div>
                  );
                })}

                <div className="schedule-grid-cell schedule-total">
                  <div className="schedule-total-hours">{compliance ? `${compliance.plannedHours.toFixed(1)} val.` : "0.0 val."}</div>
                  <span className={rowBad ? "schedule-total-status bad" : rowWarn ? "schedule-total-status warn" : "schedule-total-status"}>
                    {rowBad ? "Klaida" : rowWarn ? "Įspėjimas" : "Gerai"}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="schedule-history-panel">
        <div className="schedule-history-title"><History size={17} /> Pakeitimų istorija</div>
        <div className="schedule-history-list">
          {auditLog.length ? auditLog.slice(0, 12).map((item) => (
            <div key={item.id} className="schedule-history-item">
              <span>{item.label}</span>
              <time>{item.at}</time>
            </div>
          )) : (
            <div className="schedule-history-item"><span>Kol kas pakeitimų nėra.</span><time>—</time></div>
          )}
        </div>
      </div>

      <div className="schedule-summary">
        <div>
          <div className="schedule-summary-title">Grafiko teisėtumo suvestinė</div>
          <div className="schedule-summary-row"><span>Kritinės klaidos</span><b>{criticalRows.length}</b></div>
          <div className="schedule-summary-row"><span>Įspėjimai</span><b>{warningOnlyRows.length}</b></div>
          <div className="schedule-summary-row"><span>Be pastabų</span><b>{scheduleComplianceRows.length - criticalRows.length - warningOnlyRows.length}</b></div>
        </div>
        <SummaryBox title="52 val. / 7 d." value={`${maxSevenDayHours.toFixed(1)} val.`} note="Suminėje apskaitoje negali viršyti 52 val. per bet kurias 7 dienas." />
        <SummaryBox title="48 val. vidurkis" value={`${(scheduleComplianceRows.reduce((sum, row) => sum + (row.averageWeeklyHours || 0), 0) / Math.max(1, scheduleComplianceRows.length)).toFixed(1)} val.`} note="Vidutinis savaitinis darbo laikas neturi viršyti 48 val." />
        <SummaryBox title="Kasdienis poilsis" value={shortestRest === null ? "—" : `${shortestRest.toFixed(1)} val.`} note="Tarp pamainų turi būti bent 11 val. nepertraukiamo poilsio." />
        <SummaryBox title="Savaitinis poilsis" value={minWeeklyRest === null ? "—" : `${minWeeklyRest.toFixed(1)} val.`} note="Per kiekvienas 7 paeiliui einančias dienas turi būti bent 35 val. poilsio." />
      </div>
    </section>
  );
}

function Metric({
  icon,
  label,
  value,
  good,
  warn,
  bad,
}: {
  icon: ReactNode;
  label: string;
  value: string | number;
  good?: boolean;
  warn?: boolean;
  bad?: boolean;
}) {
  return (
    <div className="schedule-metric">
      <div className="schedule-metric-label">{icon}{label}</div>
      <div className={bad ? "schedule-metric-value bad" : warn ? "schedule-metric-value warn" : good ? "schedule-metric-value good" : "schedule-metric-value"}>{value}</div>
    </div>
  );
}

function SummaryBox({ title, value, note }: { title: string; value: string; note: string }) {
  return (
    <div>
      <div className="schedule-summary-title">{title}</div>
      <div className="schedule-summary-value">{value}</div>
      <div className="schedule-summary-row"><span>{note}</span></div>
    </div>
  );
}
