"use client";

import { AlertTriangle, CheckCircle2, Clock3, Plus, TrendingDown, XCircle } from "lucide-react";

type Employee = {
  user_id: string;
  email?: string | null;
  first_name?: string | null;
  last_name?: string | null;
  full_name?: string | null;
  role?: string | null;
  legacy_role?: string | null;
  position?: string | null;
};

type VacationRequest = {
  id: string;
  employee_id: string;
  type: string | null;
  start_date: string;
  end_date: string;
  status: string;
  requested_days: number | null;
  note: string | null;
  created_at: string | null;
};

type AbsenceType = { value: string; label: string; code: string };

type VacationForm = {
  employee_id: string;
  type: string;
  start_date: string;
  end_date: string;
  note: string;
};

type Props = {
  employees: Employee[];
  requests: VacationRequest[];
  form: VacationForm;
  saving: boolean;
  absenceTypes: AbsenceType[];
  onFormChange: (form: VacationForm) => void;
  onSubmit: () => void | Promise<void>;
  onApprove: (id: string) => void | Promise<void>;
  onReject: (id: string) => void | Promise<void>;
  employeeName: (employee?: Employee | null) => string;
  employeeRole: (employee?: Employee | null) => string;
  daysBetween: (start: string, end: string) => number;
  fmt: (value?: string | null) => string;
  absenceTypeMeta: (type?: string | null) => AbsenceType;
  absenceStatusLabel: (status?: string | null) => string;
};

function toDateInput(date: Date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function datesBetween(start: string, end: string) {
  const rows: string[] = [];
  const current = new Date(`${start}T00:00:00`);
  const last = new Date(`${end}T00:00:00`);
  while (current <= last) {
    rows.push(toDateInput(current));
    current.setDate(current.getDate() + 1);
  }
  return rows;
}

function requestStatusClass(status: string) {
  if (status === "approved") return "vr-status vr-status-approved";
  if (status === "rejected") return "vr-status vr-status-rejected";
  return "vr-status vr-status-submitted";
}

function requestStatusIcon(status: string) {
  if (status === "approved") return <CheckCircle2 size={16} />;
  if (status === "rejected") return <XCircle size={16} />;
  return <Clock3 size={16} />;
}

export default function VacationRequests({
  employees,
  requests,
  form,
  saving,
  absenceTypes,
  onFormChange,
  onSubmit,
  onApprove,
  onReject,
  employeeName,
  employeeRole,
  daysBetween,
  fmt,
  absenceTypeMeta,
  absenceStatusLabel,
}: Props) {
  const employeeMap = new Map(employees.map((employee) => [employee.user_id, employee]));
  const submitted = requests.filter((request) => request.status === "submitted");
  const decided = requests.filter((request) => request.status !== "submitted");

  function update<K extends keyof VacationForm>(key: K, value: VacationForm[K]) {
    onFormChange({ ...form, [key]: value });
  }

  function impactFor(request: VacationRequest) {
    const days = datesBetween(request.start_date, request.end_date);
    let maxOff = 0;
    let worstDay = days[0] || request.start_date;

    for (const day of days) {
      const off = requests.filter((other) => {
        if (other.status === "rejected" || other.status === "cancelled") return false;
        return datesBetween(other.start_date, other.end_date).includes(day);
      }).length;
      if (off > maxOff) {
        maxOff = off;
        worstDay = day;
      }
    }

    const left = Math.max(0, employees.length - maxOff);
    const risky = left < Math.max(1, Math.ceil(employees.length * 0.5));
    return { left, total: employees.length, maxOff, worstDay, risky };
  }

  const previewRequest: VacationRequest = {
    id: "preview",
    employee_id: form.employee_id,
    type: form.type,
    start_date: form.start_date,
    end_date: form.end_date,
    status: "submitted",
    requested_days: daysBetween(form.start_date, form.end_date),
    note: form.note || null,
    created_at: null,
  };
  const previewImpact = form.employee_id && form.start_date && form.end_date ? impactFor(previewRequest) : null;

  return (
    <section className="vr-card">
      <style>{css}</style>

      <div className="vr-header">
        <div>
          <h2>Atostogų prašymai</h2>
          <p>Pateikti prašymai iš karto atsiranda grafike kaip pilka rezervacija „R“. Patvirtinus jie virsta oficialiu neatvykimu. Prieš patvirtinimą matai poveikį komandai.</p>
        </div>
        <div className="vr-summary">
          <span><b>{submitted.length}</b> laukia</span>
          <span><b>{decided.length}</b> apdorota</span>
        </div>
      </div>

      <div className="vr-form">
        <select value={form.employee_id} onChange={(event) => update("employee_id", event.target.value)}>
          {employees.map((employee) => (
            <option key={employee.user_id} value={employee.user_id}>{employeeName(employee)} — {employeeRole(employee)}</option>
          ))}
        </select>
        <select value={form.type} onChange={(event) => update("type", event.target.value)}>
          {absenceTypes.map((type) => <option key={type.value} value={type.value}>{type.label} ({type.code})</option>)}
        </select>
        <input type="date" value={form.start_date} onChange={(event) => update("start_date", event.target.value)} />
        <input type="date" value={form.end_date} onChange={(event) => update("end_date", event.target.value)} />
        <input value={form.note} onChange={(event) => update("note", event.target.value)} placeholder="Pastaba" />
        <button type="button" disabled={saving} onClick={() => void onSubmit()}><Plus size={16} /> Pateikti</button>
      </div>

      {previewImpact ? (
        <div className={previewImpact.risky ? "vr-impact vr-impact-risk" : "vr-impact"}>
          <TrendingDown size={18} />
          <b>Kas bus jei pateiksiu:</b>
          <span>Liks {previewImpact.left} iš {previewImpact.total} darbuotojų</span>
          <span>Daugiausia nedirbs: {previewImpact.maxOff}</span>
          <span>Kritinė diena: {fmt(previewImpact.worstDay)}</span>
          {previewImpact.risky ? <strong><AlertTriangle size={16} /> Rizika: gali trūkti žmonių</strong> : <strong><CheckCircle2 size={16} /> Saugu</strong>}
        </div>
      ) : null}

      <div className="vr-list">
        {requests.length ? requests.map((request) => {
          const employee = employeeMap.get(request.employee_id);
          const type = absenceTypeMeta(request.type);
          const days = request.requested_days || daysBetween(request.start_date, request.end_date);
          const impact = impactFor(request);

          return (
            <article key={request.id} className={`vr-row ${request.status === "submitted" ? "vr-row-pending" : ""}`}>
              <div className="vr-person"><div className="vr-avatar">{employeeName(employee).slice(0, 2).toUpperCase()}</div><div><strong>{employeeName(employee)}</strong><small>{employeeRole(employee)}</small></div></div>
              <div className="vr-meta"><span className="vr-type">{type.label} <b>{type.code}</b></span><span>{fmt(request.start_date)} – {fmt(request.end_date)}</span><span>{days} d.</span>{request.note ? <span className="vr-note">{request.note}</span> : null}</div>
              <div className={requestStatusClass(request.status)}>{requestStatusIcon(request.status)}{absenceStatusLabel(request.status)}</div>
              <div className={impact.risky ? "vr-decision vr-decision-risk" : "vr-decision"} title={`Blogiausia diena: ${impact.worstDay}`}>
                <b>Liks {impact.left}/{impact.total}</b>
                <small>{impact.risky ? "Rizika" : "Saugu"}</small>
              </div>
              <div className="vr-actions">
                {request.status === "submitted" ? <><button type="button" className="vr-approve" disabled={saving} onClick={() => void onApprove(request.id)}>Patvirtinti</button><button type="button" className="vr-reject" disabled={saving} onClick={() => void onReject(request.id)}>Atmesti</button></> : <span>—</span>}
              </div>
            </article>
          );
        }) : <div className="vr-empty">Atostogų prašymų nėra.</div>}
      </div>
    </section>
  );
}

const css = `
.vr-card { background:#fff; border:1px solid #dbe6f3; border-radius:24px; padding:22px; box-shadow:0 18px 40px rgba(15,23,42,.06); }
.vr-header { display:flex; align-items:flex-start; justify-content:space-between; gap:18px; margin-bottom:18px; }
.vr-header h2 { margin:0 0 6px; font-size:24px; line-height:1.1; color:#07122a; }
.vr-header p { margin:0; color:#5f6f86; font-weight:750; max-width:950px; }
.vr-summary { display:flex; gap:10px; flex-wrap:wrap; justify-content:flex-end; }
.vr-summary span { border:1px solid #dbe6f3; border-radius:999px; padding:10px 14px; color:#334155; font-weight:850; background:#f8fbff; }
.vr-form { display:grid; grid-template-columns:minmax(220px,1.3fr) minmax(210px,1fr) 160px 160px minmax(180px,1fr) 180px; gap:12px; margin-bottom:14px; }
.vr-form select,.vr-form input { width:100%; min-height:48px; border:1px solid #cfdbea; border-radius:14px; padding:0 14px; color:#07122a; font-weight:750; background:#fff; outline:none; }
.vr-form select:focus,.vr-form input:focus { border-color:#0f8b6f; box-shadow:0 0 0 3px rgba(15,139,111,.12); }
.vr-form button { border:0; border-radius:14px; background:#087f63; color:#fff; font-weight:950; display:inline-flex; align-items:center; justify-content:center; gap:8px; cursor:pointer; }
.vr-form button:disabled,.vr-actions button:disabled { opacity:.55; cursor:not-allowed; }
.vr-impact { display:flex; flex-wrap:wrap; align-items:center; gap:10px; border:1px solid #bbf7d0; background:#f0fdf4; color:#065f46; border-radius:16px; padding:12px; margin-bottom:16px; font-weight:850; }
.vr-impact-risk { border-color:#fed7aa; background:#fff7ed; color:#9a3412; } .vr-impact strong{ display:inline-flex; align-items:center; gap:6px; }
.vr-list { display:grid; gap:10px; }
.vr-row { display:grid; grid-template-columns:minmax(220px,1.1fr) minmax(280px,2fr) 150px 120px 180px; gap:12px; align-items:center; border:1px solid #e2eaf5; border-radius:18px; padding:14px; background:#fff; }
.vr-row-pending { background:linear-gradient(90deg,#fffdf5,#fff); border-color:#fde1a2; }
.vr-person { display:flex; align-items:center; gap:12px; } .vr-avatar{ width:42px; height:42px; border-radius:999px; background:#e9fff6; color:#087f63; display:grid; place-items:center; font-weight:950; }
.vr-person strong{ display:block; color:#07122a; font-weight:950; } .vr-person small{ color:#607089; font-weight:800; }
.vr-meta { display:flex; align-items:center; flex-wrap:wrap; gap:8px; color:#334155; font-weight:850; } .vr-meta span{ background:#f4f8fc; border:1px solid #e2eaf5; border-radius:999px; padding:7px 10px; } .vr-type b{ color:#087f63; } .vr-note{ border-radius:12px!important; max-width:280px; }
.vr-status{ display:inline-flex; align-items:center; justify-content:center; gap:7px; border-radius:999px; padding:9px 12px; font-weight:950; } .vr-status-submitted{ background:#fff7e6; color:#9a5a00; } .vr-status-approved{ background:#eafff4; color:#087f63; } .vr-status-rejected{ background:#fff0f0; color:#a11919; }
.vr-decision{ display:grid; gap:2px; border-radius:14px; padding:9px 10px; background:#eafff4; color:#087f63; text-align:center; font-weight:950; } .vr-decision small{ font-weight:850; } .vr-decision-risk{ background:#fff0f0; color:#a11919; }
.vr-actions{ display:flex; gap:8px; justify-content:flex-end; flex-wrap:wrap; } .vr-actions button{ border:0; border-radius:12px; padding:10px 12px; font-weight:950; cursor:pointer; } .vr-approve{ background:#087f63; color:#fff; } .vr-reject{ background:#fff0f0; color:#9f1239; }
.vr-empty{ border:1px dashed #cfdbea; border-radius:18px; padding:28px; text-align:center; color:#607089; font-weight:850; background:#fbfdff; }
@media (max-width:1200px){ .vr-form,.vr-row{ grid-template-columns:1fr; } .vr-actions{ justify-content:flex-start; } .vr-header{ flex-direction:column; } .vr-summary{ justify-content:flex-start; } }
`;
